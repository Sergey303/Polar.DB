#!/usr/bin/env python3
"""Summarize immutable lookup raw CSV by separate coordinator, then across runs."""
import sys,json,csv,statistics
from collections import defaultdict
from pathlib import Path
p=Path(sys.argv[1]);meta=json.loads(p.read_text());d=defaultdict(list)
for r in meta['runs']:
 if r['exitCode'] or not r.get('raw'):continue
 f=Path(r['raw']).parent/'samples.csv'
 by=defaultdict(list)
 with f.open() as h:
  for sample in csv.DictReader(h):
   if sample['metric']!='lookup-batch-average':continue
   key=(sample['engine'],sample['phase']);by[key].append(float(sample['value']))
 for key,values in by.items():
  d[(r['project'],r['rows'],*key)].append(statistics.median(values))
print('SOURCE SHA:',meta['sourceSha'],'MEM GiB:',meta['memoryMax']/2**30,'SWAP:',meta['swapMax'])
print('COMPLETE:',len([v for v in meta['runs'] if not v['exitCode']]),'/',len(meta['runs']))
print('Primary medians in microseconds per query, secondary in milliseconds, across coordinator medians')
for (project,rows,engine,phase),vals in sorted(d.items()):
 scale=1000 if project.startswith('Pk') else 1
 print(f'{project:22} {rows:>8} {engine:16} {phase:35} med={statistics.median(vals)*scale:.4f} n={len(vals)} per_run={[round(x*scale,4) for x in vals]}')
print('MEMORY DIAGNOSTICS (cgroup incl. file cache, sampled peak):')
for r in meta['runs']:
 print(r['runId'],'exit='+str(r['exitCode']),'peakGiB='+str(round(r['memoryPeakSampledBytes']/2**30,2)), 'majorFaults='+str(r['memoryStatDelta'].get('pgmajfault')),'seconds='+str(r['seconds']),'OOM='+str(r['memoryEventsDelta'].get('oom_kill')))

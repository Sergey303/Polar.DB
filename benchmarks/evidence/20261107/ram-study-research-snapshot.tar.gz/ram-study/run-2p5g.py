#!/usr/bin/env python3
"""RAM-limited 8 GiB pilot: one source revision, controlled workloads, immutable raw results."""
from pathlib import Path
import os,sys,signal,subprocess,json,time,datetime,statistics,csv,re
ROOT=Path('/work/Polar.DB')
OUT=Path('/work/ram-study/2p5g')
CG=Path('/sys/fs/cgroup')
GIB=1024**3
OUT.mkdir(parents=True,exist_ok=True)

def num(name):
 try:return int((CG/name).read_text().strip())
 except Exception:return -1

def memstat():
 d={}
 for line in (CG/'memory.stat').read_text().splitlines():
  k,v=line.split();d[k]=int(v)
 return d

def events():
 return dict((a,int(b)) for a,b in (line.split() for line in (CG/'memory.events').read_text().splitlines()))

limit=num('memory.max'); swap=num('memory.swap.max')
if limit!=int(2.5*GIB) or swap!=0:raise SystemExit(f'WRONG LIMIT: memory={limit} swap={swap}')
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert sha=='a49a08316fde4207853c0307fe63de0b84d30bd3',sha
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True).strip()
profile=[('PkIntLookup',50000),('PkIntLookup',5000000)]
plan=OUT/'runs.json'
data={'schema':1,'experiment':'2.5 GiB cgroup memory; swap 0; controlled pilot','sourceSha':sha,'sdk':'10.0.403','runtime':subprocess.check_output(['dotnet','--list-runtimes'],text=True).strip(),'memoryMax':limit,'swapMax':swap,'profile':profile,'note':'Descriptive two independent coordinator runs per workload; do not compute independent-run confidence intervals. Benchmarks use their own fixed warmup plans. No forced OS cache eviction.','runs':[]}
if plan.exists():
 data=json.loads(plan.read_text())
 assert data['sourceSha']==sha
print('STUDY PROFILE:',profile,flush=True)
for rep in range(2):
 for project,rows in profile:
  runid=f'ram2p5g-{project.lower()}-{rows}-r{rep+1:02d}'
  if any(r.get('runId')==runid for r in data['runs']):continue
  path=ROOT/'benchmarks/src'/project/'bin/Release/net10.0'/(project+'.dll')
  assert path.is_file(),path
  logfile=OUT/(runid+'.log')
  order='sqlite-first' if rep==0 else 'polar-first'
  env=os.environ.copy()
  env.update(POLAR_BENCH_RUN_ID=runid,POLAR_BENCH_ENGINE_ORDER=order)
  cmd=['python3',str(ROOT/'benchmarks/scripts/disk_guard.py'),'--min-free-gib','16','--max-growth-gib','12','--timeout-seconds','900','--','dotnet',str(path),f'--rows={rows}']
  s0=memstat();e0=events();started=time.monotonic();peak=num('memory.current'); samples=0;failed_reason=None
  print(f'RUN {runid}, order={order}, baselineRAM={peak/GIB:.2f}GiB',flush=True)
  with logfile.open('w') as log:
   proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   while proc.poll() is None:
    used=num('memory.current');peak=max(peak,used);samples+=1
    if used > int(3.80*GIB):
     failed_reason='Safety cutoff > 3.80 GiB (unreachable at 3 GiB cgroup)'
     try:os.killpg(proc.pid,signal.SIGTERM)
     except ProcessLookupError:pass
     break
    if time.monotonic()-started>920:
     failed_reason='Harness timeout > 920s'
     try:os.killpg(proc.pid,signal.SIGTERM)
     except ProcessLookupError:pass
     break
    time.sleep(.25)
   if failed_reason:
    try:proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
     try:os.killpg(proc.pid,signal.SIGKILL)
     except ProcessLookupError:pass
   code=proc.wait()
  s1=memstat();e1=events()
  outcome={'runId':runid,'project':project,'rows':rows,'order':order,'exitCode':code,'failure':failed_reason,'seconds':round(time.monotonic()-started,2),'memoryStartBytes':s0.get('anon',0)+s0.get('file',0),'memoryPeakSampledBytes':peak,'memoryEndBytes':num('memory.current'),'memoryStatDelta':{k:s1.get(k,0)-v for k,v in s0.items() if k in ['pgmajfault','pgfault','workingset_refault_file','pgscan','pgsteal']},'memoryStatEnd':{k:s1.get(k,0) for k in ('anon','file','inactive_file','active_file','slab_reclaimable')},'memoryEventsDelta':{k:e1.get(k,0)-v for k,v in e0.items()},'log':str(logfile)}
  results=list((ROOT/'benchmarks/results/raw').glob(f'*/{runid}/combined.raw.json'))
  if len(results)==1:
   outcome['raw']=str(results[0])
   try:
    raw=json.loads(results[0].read_text());outcome['manifestRunId']=raw['manifest']['runId']
    csvfile=results[0].parent/'samples.csv'
    if csvfile.is_file():
     r=list(csv.DictReader(csvfile.open()))
     outcome['csvRows']=len(r)
   except Exception as exc:outcome['parseError']=str(exc)
  data['runs'].append(outcome)
  plan.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
  print('FINISH',runid,'code',code,'sec',outcome['seconds'],'peakGiB',round(peak/GIB,3),'majfaults',outcome['memoryStatDelta'].get('pgmajfault'),'raw',outcome.get('raw','NONE'),flush=True)
  if code!=0:
   print('STOP ON FAILURE; see',logfile,'and',plan,flush=True)
   sys.exit(1)
print('COMPLETE',plan,flush=True)

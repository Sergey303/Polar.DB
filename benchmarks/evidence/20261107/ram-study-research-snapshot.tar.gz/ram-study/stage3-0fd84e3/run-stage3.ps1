param(
    [int[]] $Limits = @(2, 3, 4),
    [int[]] $Repeats = @(1)
)
$ErrorActionPreference = 'Stop'

# All containers use the EXACT shared benchmark volume and published source SHA.
# Running this in Windows PowerShell requires Docker Desktop to be active.
function Invoke-Stage([string] $Name, [int] $MemoryGiB, [string] $Action) {
    Write-Host "=== $Name : ${MemoryGiB} GiB ==="
    docker run --rm `
        --name $Name `
        --memory="${MemoryGiB}g" `
        --memory-swap="${MemoryGiB}g" `
        --mount 'type=volume,source=polar-bench-data,target=/work' `
        --workdir /work/Polar.DB `
        mcr.microsoft.com/dotnet/sdk:10.0 `
        bash -lc "apt-get update -qq && apt-get install -y -qq python3 git > /dev/null && $Action"
    if ($LASTEXITCODE -ne 0) { throw "Stage3 stopped; failing container: $Name ($LASTEXITCODE)" }
}

# 20M data/indexes are constructed ONCE at 8 GiB, never in measurement workers.
foreach ($engine in @('sqlite', 'polar-db')) {
    $manifest = "/work/ram-study/stage3-0fd84e3/prepared-20000000/pk-int-lookup/rows-20000000/$engine.ready.json"
    $base = '/work/ram-study/stage3-0fd84e3/prepared-20000000'
    $dll = '/work/Polar.DB/benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'
    $action = "if test -f '$manifest'; then dotnet '$dll' --prepared-stage=verify --prepared-root='$base' --benchmark-engine=$engine --rows=20000000; else python3 -u /work/ram-study/stage3_prepare_guard.py --engine $engine --gib 8; fi"
    Invoke-Stage "polar-s3-prep-$($engine.Replace('-',''))" 8 $action
}

# Negative control: small data, 2 GiB, full-file scan then query-only.
foreach ($engine in @('sqlite','polar-db')) {
    foreach ($rep in $Repeats) {
        Invoke-Stage "polar-s3-5m-2g-$($engine.Replace('-',''))-r$rep" 2 "python3 -u /work/ram-study/stage3_worker.py --gib 2 --engine $engine --rows 5000000 --repeat $rep"
    }
}

# Test both endpoints and 3 GiB in-between; alternate engine order.
foreach ($ram in $Limits) {
    $order = if ($ram -eq 3) { @('polar-db','sqlite') } else { @('sqlite','polar-db') }
    foreach ($rep in $Repeats) {
        foreach ($engine in $order) {
            Invoke-Stage "polar-s3-20m-${ram}g-$($engine.Replace('-',''))-r$rep" $ram "python3 -u /work/ram-study/stage3_worker.py --gib $ram --engine $engine --rows 20000000 --repeat $rep"
        }
    }
}

# Verify the immutable source files ONLY AFTER measured runs (hashing warms cache).
$base = '/work/ram-study/stage3-0fd84e3/prepared-20000000'
$dll = '/work/Polar.DB/benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'
foreach ($engine in @('sqlite','polar-db')) {
    Invoke-Stage "polar-s3-postverify-$($engine.Replace('-',''))" 8 "dotnet '$dll' --prepared-stage=verify --prepared-root='$base' --benchmark-engine=$engine --rows=20000000"
}
Invoke-Stage 'polar-s3-report' 8 'python3 /work/ram-study/stage3_report.py'
Write-Host 'Stage 3 pilot finished. Article was not changed.'

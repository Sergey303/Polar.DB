# Stage 3 pilot: independent audit and publication gate

SHA: `0fd84e3da854aa9f536a75861e7838af41955bdc`. **Not a publication-grade experiment.** All worker and source-database verifications passed; no OOM reported. Never mix the 4-GiB RDC `v1` runs with independently capped `v2` workers.

## Pilot-v2 observations, 20M, primary int

| RAM | Engine | Batch median / lookup, µs | Batch mean / lookup, µs | Batch read_bytes, MB | % sealed pages resident after process | Query process sampled VmHWM, MiB |
|---|---|---:|---:|---:|---:|---:|
| 2 GiB | Polar.DB | 5.892 | 10.040 | 71.38 | 60.0 | 217.1 |
| 2 GiB | SQLite | 33.167 | 51.421 | 75.62 | 52.1 | 66.9 |
| 3 GiB | Polar.DB | 4.164 | 7.056 | 51.66 | 69.3 | 220.5 |
| 3 GiB | SQLite | 33.584 | 40.551 | 52.21 | 63.0 | 66.7 |
| 4 GiB | Polar.DB | 4.020 | 7.688 | 48.01 | 73.1 | 218.4 |
| 4 GiB | SQLite | 22.123 | 25.918 | 16.91 | 81.2 | 66.0 |

Raw stats are in `query-results/pk-int-lookup/pilot-v2-*.json` and `metrics/pilot-v2-*.json`. The batch contains 100 samples × 100 queries; median is the median *across 100 per-sample averages*, whereas mean weights all 10,000 queries uniformly. The batch means show important long-tail stalls; do NOT present batch medians as typical per-query p50.

20M prepared file sizes from SHA-sealed manifests: SQLite **2,053,685,248 bytes** (~2.054 GB, 1 file), Polar.DB **2,300,000,084 bytes** (~2.300 GB, 5 files). These are different physical formats under identical logical row counts.

Before each run, POSIX_FADV_DONTNEED was applied to sealed files and `mincore` verified **0% page residency**. This controls the initial state of the *per-file scan*, but the later explicit sequential file scan is not guaranteed to retain all pages. Linux page cache remains global and container file-page accounting is complex. Page residency is measured *after* the process, not at the start of the measured batch.

## Critical discovered workload defect

`LookupPlanner.Keys` uses `KeyAt` with row index `(i * 1_000_003 + 97) % N`, and contiguous `i+seed` values. For `N=20,000,000`, 10,000 batch keys touch only **20/400 50k-row bins** (around 3% of row-index space). For `N=5,000,000`, they touch only **5/100 bins**. This deterministic modular stride is NOT a uniform random sample of database rows; it clusters access in narrow segments around each million-row boundary.

The hot plan uses warmup indices `71..570` (500 keys), batch indices `97..10096` (10,000 keys), and latency indices `131..2130` (2,000 keys). Therefore **474/500 warmup keys repeat in batch** and **2,000/2,000 latency keys repeat in batch**. In the 20M experiments, the measured `AfterBatch→AfterLatency` physical read-byte delta was 0 for both engines at all 2/3/4 GiB limits. The 'latency p50/p95' is a *previously accessed hot subset* and must not be used as independent random-lookup latency. The batch does incur I/O and remains a valid measurement of this particular structured key sequence, but not of broad random full-table access.

## Interpretation

- Single-run batch median: Polar.DB is ~5.63x, ~8.07x, ~5.50x faster at 2/3/4 GiB respectively. These do **not** establish a consistent relative RAM sensitivity or crossover. Both engines have substantial outliers (per-batch mean far above median).
- 2 GiB vs 4 GiB slowdown, same 20M data: Polar.DB batch median 1.47x, SQLite batch median 1.50x; relative advantages similar at the endpoints. This does not prove a distinct architectural memory knee.
- Prepared query process VmHWM on 20M is ~217–220 MiB Polar.DB versus ~66–67 MiB SQLite, but these are process metrics excluding file cache. During 8-GiB preparation, the process VmHWM peaked at ~1,058 MiB Polar.DB versus ~71 MiB SQLite, and cgroup sampled peaks were 3.23 vs 2.70 GiB. These support further investigation of an explicit memory/build vs lookup-speed compromise, not a causal proof.
- Successful 20M/2GiB query-only runs show both can open and search the prepared databases under this limit. It does NOT show 20M indexes can be built at 2GiB; build was intentionally done at 8GiB.

## Publication gate: next corrected pilot

1. Keep original experiment/manifest results immutable. Do not modify the manuscript yet.
2. Add a **separate opt-in v3 query-plan** using a seed-fixed, deterministic well-mixed PRNG over all N row IDs (report distribution and page coverage) and **nonoverlapping warmup, batch, and independent-latency** key streams. If repeated hot keys are desired, report them as a distinct named workload, not the same as independent latency.
3. Use fixed query count, verified semantics, same logical work and row size; re-seal oracle/plan under a new recorded SHA/protocol. Do not silently alter the existing `LookupPlanner` baseline.
4. Pilot 20M at 2 vs 4 GiB. Capture page residency **immediately before measured batch** in addition to after-query residency and phase-specific read_bytes/refaults. Do not rely on cgroup `pgmajfault` alone for `FileStream` reads.
5. If differences are reproducible and attributable, run independent balanced ABBA order with confidence intervals. Only then consider one figure or table in the manuscript. Otherwise leave the RAM study as supplementary exploratory material.

**Decision:** Stage 3 has accomplished feasibility and discovered necessary methodology fixes. It has NOT yet established a publication-worthy architecture/memory crossover.

# Stage 3 exploratory RAM sensitivity: protocol and current progress

**Pinned source:** `0fd84e3da854aa9f536a75861e7838af41955bdc`.
**Engines:** prepared Polar.DB and SQLite, primary `int`, query-only.
**Article:** unchanged; pilot not a publication series.

## Evidence already collected

- The prepared databases with 5M rows were sealed by SHA256 at
  `/work/ram-study/stage2-release-0fd84e3/prepared/` and reverified after the runs.
- An initial `pilot-v1` at 4 GiB lacked explicit OS-cache control. Retained as
  diagnostic evidence only; do not pool with later runs.
- Improved `pilot-v2`: for each engine, inspected page residency with `mincore`,
  ran `POSIX_FADV_DONTNEED` on only its sealed DB files, and confirmed **0%**
  residency afterward. Then `hot` performed a complete sequential file pass
  and deterministic lookup warmup before measuring the same fixed workload.
- In two pilot-v2 4-GiB runs, **all sealed file pages were resident after
  querying**, and measured batch+latency `read_bytes` deltas were 0 for both
  engines (this counter does not prove the hardware never issued I/O).
- Pilot-v2 warm batch median, per independent query process:

| Engine | 4 GiB r1 | 4 GiB r2 |
|---|---:|---:|
| Polar.DB | 3.134 µs | 3.015 µs |
| SQLite | 8.876 µs | 8.976 µs |

The 4 GiB runs used the RDC controller container, which shares cgroup memory
with its agent. They are exploratory and must not be treated as independent
isolated-container publication measurements. No RAM-performance knee was
identified at 5M/4GiB.

## Attempted scale-up and limit of remote control

SQLite 20M `prepare` was attempted inside the **4-GiB controller**. It was
terminated intentionally by the outer safety guard when cgroup usage reached
3.78 GiB. There was **no observed SQLite OOM**. The failed dataset was deleted;
its failure metadata and log are preserved under
`metrics/prepare-20m-sqlite-controller4g.{json,log}`.

Both RDC devices lack Docker Engine access. Building 20M in a **disposable 8-GiB
Docker container** is the next required action; query-only is then evaluated
in separate 2, 3, and 4-GiB containers, without swap.

## Windows-host run (Docker Desktop)

First copy the reviewed PowerShell launcher out of the existing benchmark
volume. In Windows PowerShell:

```powershell
docker run --rm --mount type=volume,source=polar-bench-data,target=/work `
  mcr.microsoft.com/dotnet/sdk:10.0 `
  cat /work/ram-study/stage3-0fd84e3/run-stage3.ps1 |
  Set-Content -Encoding UTF8 .\polar-stage3.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\polar-stage3.ps1
```

The launcher validates/prepares 20M DBs at 8 GiB, runs the 5M/2GiB negative
control and 20M query-only at 2/3/4 GiB in isolated containers, verifies file
hashes **after** the measurements, and prints an overview. Containers use
`--rm`, but raw reports and sealed DB files persist on `polar-bench-data`.
Every run is bounded by time and disk growth; a failed step stops the script.
Do not reset the Docker VM or globally drop Linux caches during other work.

## Outputs and interpretation

- Standalone worker: `/work/ram-study/stage3_worker.py` (cache-controlled v2).
- Probe: `/work/ram-study/stage3_cache.py` (`mincore` + advisory file-specific
  eviction; fails if >5% sealed data pages remain resident).
- 8 GiB guarded prepare: `/work/ram-study/stage3_prepare_guard.py`.
- Report: `/work/ram-study/stage3_report.py`.
- Raw JSON: `query-results/pk-int-lookup/pilot-v2-*.json`.
- Process/cgroup metadata: `metrics/pilot-v2-*.json`.
- Ready manifests and data: `prepared-20000000/pk-int-lookup/rows-20000000/`.

The queried file sizes and index architectures differ; identical logical rows
and physical RAM limits are the primary comparison, not identical internal
cache layout. Changes to `.NET` or Git source SHA invalidate direct comparison.
Even successful `mincore` checks cannot prevent concurrent cache changes from
another process, and `read_bytes`/cgroup I/O accounting do not necessarily equal
physical SSD activity under Docker Desktop/WSL2.

**Decision gate:** if 20M/2 GiB produces higher timed-query I/O or lower page
residency than 20M/4 GiB, and latency changes in a reproducible way, proceed
to counterbalanced independent repeats. Otherwise do not expand the RAM block
in the manuscript. Require a proposed explanatory hypothesis for any claim.

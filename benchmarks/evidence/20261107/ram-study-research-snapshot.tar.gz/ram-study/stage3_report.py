#!/usr/bin/env python3
"""Summarize Stage 3 experimental measurements; never infer a cold page cache."""
import json
import math
from pathlib import Path
import statistics

BASE=Path('/work/ram-study/stage3-0fd84e3')
GIB=1024**3


def diff(a,b,key):
    return b.get(key,0)-a.get(key,0)


def phases(d):
    s=d['Snapshots']
    for label,from_key,to_key in [('file-scan','BeforeFileWarmup','AfterFileWarmup'),
                                  ('open','AfterFileWarmup','AfterOpen'),
                                  ('key-warmup','AfterOpen','AfterKeyWarmup'),
                                  ('batch','AfterKeyWarmup','AfterBatch'),
                                  ('latency','AfterBatch','AfterLatency')]:
        a,b=s[from_key],s[to_key]
        mem_a,mem_b=a['MemoryCgroup'],b['MemoryCgroup']
        io_a,io_b=a['ProcessIo'],b['ProcessIo']
        yield (label,diff(io_a,io_b,'read_bytes'),diff(io_a,io_b,'rchar'),
               diff(mem_a,mem_b,'workingset_refault_file'),
               diff(mem_a,mem_b,'pgscan'),diff(mem_a,mem_b,'pgmajfault'))


def percentile(x,p):
    x=sorted(x)
    index=math.ceil(len(x)*p)-1
    return x[max(0,min(index,len(x)-1))]


def main():
    rows=[]
    for file in sorted((BASE/'metrics').glob('pilot-v*-*.json')):
        worker=json.loads(file.read_text())
        raw=worker.get('queryJson')
        if not raw or not Path(raw).exists():
            print('SKIP',file.name,'missing query result',worker.get('exitCode'))
            continue
        d=json.loads(Path(raw).read_text())
        assert d['Engine']==worker['engine'] and d['Rows']==worker['rows']
        assert d['SourceSha']==worker['sha']
        assert d['BatchRows']==d['ExpectedBatch']['Rows'] and d['BatchChecksum']==d['ExpectedBatch']['Checksum']
        assert d['LatencyRows']==d['ExpectedLatency']['Rows'] and d['LatencyChecksum']==d['ExpectedLatency']['Checksum']
        stages={item[0]:item for item in phases(d)}
        row={'rows':d['Rows'],'ram':worker['limitGiB'],'engine':d['Engine'],
             'protocol':worker['tag'].split('-')[1],
             'cache_reset':worker.get('cacheAfterAdvice',{}).get('fraction'),
             'cache_after_query':worker.get('cacheAfterQuery',{}).get('fraction'),
             'rep':worker['repeat'],'batch_med_us':round(1000*statistics.median(d['BatchAverageMs']),3),
             'lat_p50_us':round(1000*statistics.median(d['LatencySamplesMs']),3),
             'lat_p95_us':round(1000*percentile(d['LatencySamplesMs'],.95),3),
             'open_ms':round(d['OpenRefreshMs'],1),
             'query_read_bytes':stages['batch'][1]+stages['latency'][1],
             'query_rchar':stages['batch'][2]+stages['latency'][2],
             'query_refault':stages['batch'][3]+stages['latency'][3],
             'cgroup_peak_sample_gib':worker['sampledMemoryCurrentPeakGiB'],
             'oom_kills':worker['cgroupEventsDelta'].get('oom_kill',0)}
        rows.append(row)
    print('RUNS',len(rows))
    print('rows,limit_gib,protocol,engine,rep,batch_med_us,lat_p50_us,lat_p95_us,open_ms,query_read_bytes,query_refault,resident_after_evict,resident_after_query,cgroup_peak_gib,oom_kills')
    for x in rows:
        print(','.join(str(x[k]) for k in ('rows','ram','protocol','engine','rep','batch_med_us','lat_p50_us','lat_p95_us','open_ms','query_read_bytes','query_refault','cache_reset','cache_after_query','cgroup_peak_sample_gib','oom_kills')))
    print('\nNOTE: 4-GiB RDC controller cgroup shares memory/cache with the agent. The page cache is shared across Docker runs. Whole-run cgroup peaks are not per-engine memory footprints, and no statistical conclusion follows from a single run.')
    for n in sorted({x['rows'] for x in rows}):
        for ram in sorted({x['ram'] for x in rows}):
            for protocol in sorted({x['protocol'] for x in rows}):
                candidates=[x for x in rows if x['rows']==n and x['ram']==ram and x['protocol']==protocol]
                for rep in sorted({x['rep'] for x in candidates}):
                    matched=[x for x in candidates if x['rep']==rep]
                    if {x['engine'] for x in matched}=={'sqlite','polar-db'}:
                        p=next(x for x in matched if x['engine']=='polar-db')
                        s=next(x for x in matched if x['engine']=='sqlite')
                        print('PAIR',n,ram,protocol,rep,'SQLite/Polar batch ratio',round(s['batch_med_us']/p['batch_med_us'],3),
                              'query IO bytes',s['query_read_bytes'],p['query_read_bytes'],
                              'NOT publication inference')

if __name__=='__main__': main()

# Stage 3.2 — architecture-specific file-cache intervention

## Goal

Test whether the previously observed **same-query rank reversal** is primarily
caused by partial eviction of Polar.DB's row-data file (`f0.bin`), rather than
loss of its hash index (`f1.bin`), offset index (`f2.bin`) or a nominal RAM cap.
The previous `uniform-v3` pilot showed Polar.DB's f1/f2 files at 100% residency
while f0 was ~50–66% resident, so a selective causal test is warranted.

## Versions (pin both)

- New controlled `uniform-v32` query runner: `b32020fd2786942332fc8f0a2320ee5aee3cb113`.
- Existing, unchanged 20M-row prepared databases: `0fd84e3da854aa9f536a75861e7838af41955bdc`.
- Uniform key-stream fingerprint: `44106a815bb975ddbf956a475c5b6463832ce2bdaa139b59da6c18ffa50daf57`.
- Mappings from `USequence`/`UKeyIndex`: `f0.bin` record payload, `f1.bin` persisted sorted hashes (the hash array is loaded into memory on refresh), `f2.bin` persisted offsets read during lookup. `state.bin` and `f0.state` are small state files. SQLite's `data.sqlite` integrates index and rowid-table data, so do not pretend matching on-disk index layouts.
- Dataset 20M sizes: Polar.DB 2,300,000,084 bytes total (f0 2,060,000,008; f1 80,000,008; f2 160,000,008), SQLite 2,053,685,248 bytes.

## Interventions, identical RAM and query keys

Each *fresh isolated 8-GiB no-swap container* loads/opens prebuilt data, executes the same 500 warmup keys, then **at the pre-batch boundary** applies the chosen `posix_fadvise(DONTNEED)` intervention, outside timed queries, after confirming >=99.5% residency on **every** sealed file.

| Engine | Condition | Expected file pages just before batch |
|---|---|---|
| Polar.DB | none | All >=99.5% resident |
| Polar.DB | payload-half | ~50% `f0.bin`, f1/f2 >=99.5% |
| Polar.DB | payload | <=10% `f0.bin`, f1/f2 >=99.5% |
| Polar.DB | hashes | <=10% `f1.bin`, f0/f2 >=99.5% |
| Polar.DB | offsets | <=10% `f2.bin`, f0/f1 >=99.5% |
| SQLite | none | Database >=99.5% |
| SQLite | data-half | ~50% `data.sqlite` |
| SQLite | data | <=10% `data.sqlite` |

Half eviction is interleaved over 64-MiB stripes, not a single contiguous suffix.
Measured mincore residency can be slightly above 0% after full `DONTNEED`; experiments accept at most 10%. For half treatments, the accepted resident fraction is 35–65%. Runs that violate a condition are rejected before timing.

The 10,000 independent batch keys cover 400/400 bins and are disjoint from the 500 warmup and 2,000 independent latency keys. Query-only does not rebuild indexes. Per-file `mincore` snapshots are captured before treatment, after treatment (pre-batch), and after the batch. Process `read_bytes` and cgroup refaults are compared **after treatment to after batch**; the intervention's own I/O is not counted as timed query I/O. Process-wide read_bytes is not per-path device I/O.

## Execution on Docker Desktop Windows host

```powershell
docker run --rm --mount type=volume,source=polar-bench-data,target=/work `
  mcr.microsoft.com/dotnet/sdk:10.0 `
  cat /work/ram-study/stage3-2/run-host.ps1 |
  Set-Content -Encoding UTF8 .\polar-stage3-2.ps1
if ($LASTEXITCODE -ne 0) { throw 'Cannot extract Stage 3.2 host script' }
powershell -NoProfile -ExecutionPolicy Bypass -File .\polar-stage3-2.ps1
```

Default: two independent repeats, reversed condition order on the second pass,
8 conditions per pass, one fresh container per condition. The script verifies SHA-256 hashes and the v32 sidecar both before and after the series. **Stops at first failure** and preserves all logs/evidence; a prior run is never overwritten. No global page-cache drop or data deletion. The harness will reject runs that reach cgroup `memory.max`, OOM, alter query checksums, or fail the cache-state precondition. Output lives in `metrics/` (worker metadata and logs) and `raw/pk-int-lookup/` (query JSON); analysis: `python3 summarize32.py`.

## Interpret carefully

The designed contrasts are *within Polar.DB*, especially (hashes vs none), (offsets vs none), (payload vs none). Compare SQLite none/data-half/data as a whole-system control; although `f0.bin` and SQLite file are nearly the same size, their indexed/record page layouts are not equivalent. One or two runs are an explanatory pilot only, not a publication confidence interval.

**Success criterion:** index hash-file eviction causes little/no slowdown while payload-file eviction causes a large reproducible slowdown with measured additional query I/O and index files still resident; offset-file eviction can have an independent cost. This would demonstrate which file's cache residency mediates Polar.DB's performance and strengthen the specific architectural interpretation. It is NOT evidence of a universal RAM threshold or a fully isolated causal explanation of the cross-engine ranking.

The academic manuscript and earlier results are unchanged.

## November 6 C1 control rejection and revised **independent C2** protocol

The initial C1 `sqlite:none:r1` 8-GiB host run exited with no engine failure,
correct query checksums and no `memory.events:max` increase. SQLite's sealed
`data.sqlite` was 100% resident immediately before 10,000 timed queries and
99.8957% resident after; the query process accumulated **65,536 bytes** of
`read_bytes` and 9 cgroup file refaults during the batch. C1 rejected it
because C1 demanded *exactly zero* read bytes. This is real small I/O, not
proof of a SQL engine malfunction. The original metadata/raw evidence remain
untouched and C1 continues to count as **REJECTED**.

C2 is a **new, explicitly labeled exploratory protocol**, not a retrospective
reinterpretation of C1: `stage32-c2-nearly-resident-512KiB-v1`.

- C2's no-eviction baseline requires **every sealed file** to be >=99.5%
  resident just before and just after the timed batch, `read_bytes` delta
  <=512 KiB (not necessarily zero), correct result checksums, no OOM, and
  no increase in container `memory.events:max`.
- At 20M rows SQLite's 512-KiB cap is ~0.0255% of its 2.054-GB database.
  This is **near-resident** (not a fully I/O-free measurement), and any
  low-level read bytes, residency loss and file refaults remain explicitly
  reported rather than dropped.
- For Polar index-only interventions, verify that the **unselected `f0.bin`**
  stays >=99.5% resident both before and after the timed batch. For payload
  interventions, the unselected `f1.bin` and `f2.bin` must stay resident.
- Repeat IDs and files use `v32c2-...` and are never pooled automatically
  with rejected C1 data. Two fresh repeat blocks by default; reverse the
  intervention order in repeat 2, with separate no-swap 8-GiB containers.
- Dataset and query code remain pinned to the same published Git SHAs as C1.
  Only the **outside-repo** acceptance harness changes. The files include
  `acceptanceProtocol`, `controllerFingerprint` and all unchanged raw metrics.
- Since the tolerance was chosen after seeing the first failed trial,
  the C2 result remains *exploratory*; stronger claims require a subsequent
  independent precommitted confirmation with this fixed threshold.

Windows Docker host launch:

```powershell
docker run --rm --mount type=volume,source=polar-bench-data,target=/work `
  mcr.microsoft.com/dotnet/sdk:10.0 `
  cat /work/ram-study/stage3-2/run-host-c2.ps1 |
  Set-Content -Encoding UTF8 .\polar-stage3-2-c2.ps1
if ($LASTEXITCODE -ne 0) { throw 'Failed to copy C2 script' }
powershell -NoProfile -ExecutionPolicy Bypass -File .\polar-stage3-2-c2.ps1
```

`test_qualify_c2.py` checks the acceptance boundary against the retained
original C1 raw record *without changing its rejected status*, and checks
that excessive I/O, missing residency and unintended payload eviction are
rejected. Results: `metrics/v32c2-*.json`, `raw/pk-int-lookup/v32c2-*.json`;
report: `python3 summarize_c2.py`.

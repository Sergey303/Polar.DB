#!/usr/bin/env python3
"""Offline regression for C2 qualification; never reclassify original results."""
import copy
import json
from pathlib import Path
from qualify_c2 import PROTOCOL, qualify, NEAR_HOT_READ_CAP_BYTES

raw=Path('/work/ram-study/stage3-2/raw/pk-int-lookup/v32-20m-8g-sqlite-none-r1.json')
meta=Path('/work/ram-study/stage3-2/metrics/v32-20m-8g-sqlite-none-r1.json')
a=json.loads(raw.read_text())
m=json.loads(meta.read_text())
assert m['qualified'] is False and m['rejectReasons']==['unexpected reads in full-cache control']
reasons, details=qualify(a,'none')
assert reasons==[] and details['batchReadBytes']==65536

# A new 512-KiB limit must be strict; >limit is rejected.
case=copy.deepcopy(a)
case['Snapshots']['AfterBatch']['ProcessIo']['read_bytes']+=(NEAR_HOT_READ_CAP_BYTES-65536)+1
assert 'nearly-resident-control-read-more-than-512KiB' in qualify(case,'none')[0]

case=copy.deepcopy(a)
case['ResidencyAfterBatch']['Files'][0]['Fraction']=.9949
assert 'post-batch-residency-below-99.5-percent' in qualify(case,'none')[0]

case=copy.deepcopy(a)
case['ResidencyBeforeBatch']['Files'][0]['Fraction']=.9949
assert 'pre-batch-residency-below-99.5-percent' in qualify(case,'none')[0]

# A hash-only intervention is invalid if row payload is pushed out of memory.
case=copy.deepcopy(a)
case['Engine']='polar-db'
case['ResidencyBeforeTreatment']['Files']=[{'Name':'f0.bin','Fraction':1},
  {'Name':'f1.bin','Fraction':1},{'Name':'f2.bin','Fraction':1}]
case['ResidencyBeforeBatch']['Files']=[{'Name':'f0.bin','Fraction':1},
  {'Name':'f1.bin','Fraction':0},{'Name':'f2.bin','Fraction':1}]
case['ResidencyAfterBatch']['Files']=[{'Name':'f0.bin','Fraction':.994},
  {'Name':'f1.bin','Fraction':0},{'Name':'f2.bin','Fraction':1}]
assert 'unselected-file-not-resident-f0.bin' in qualify(case,'hashes')[0]

print('PASS',PROTOCOL,': 64KiB incidental reads, 512KiB boundary, pre/post mincore, unselected-payload guard')
print('C1 run remains rejected in original metadata; no raw or existing files modified')

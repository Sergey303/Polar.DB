param()
$ErrorActionPreference = 'Stop'

# Resume exactly the missing SQLite r2 baseline, then one prospective r3
# baseline pair. Never retry or relabel rejected Polar.DB none r2.
# Does NOT rebuild databases or change the published runner/acceptance rules.
function Invoke-Stage([string]$Name, [string]$Command, [bool]$AcceptRejection = $false) {
    Write-Host "=== $Name : 8 GiB, no swap ==="
    docker run --rm `
        --name $Name `
        --memory='8g' --memory-swap='8g' `
        --mount type=volume,source=polar-bench-data,target=/work `
        --workdir /work/Polar.DB `
        mcr.microsoft.com/dotnet/sdk:10.0 `
        bash -lc "apt-get update -qq && apt-get install -y -qq python3 git > /dev/null && $Command"
    $code = $LASTEXITCODE
    if ($code -ne 0) {
        if ($AcceptRejection) {
            Write-Warning "Run $Name exited ${code}. It may be rejected or incomplete; inspect metrics and container logs. Continuing the planned independent runs."
        } else {
            throw "Stage $Name failed, exit code $code. Original benchmark data are unchanged."
        }
    }
}

$root='/work/ram-study/stage3-0fd84e3/prepared-20000000'
$dataSha='0fd84e3da854aa9f536a75861e7838af41955bdc'
$dll='/work/Polar.DB/benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'
foreach ($engine in @('sqlite','polar-db')) {
    $verify="dotnet '$dll' --prepared-stage=verify --prepared-plan=uniform-v32 --prepared-root='$root' --prepared-source-sha='$dataSha' --benchmark-engine=$engine --rows=20000000"
    Invoke-Stage "polar-s32c2-finish-preverify-$($engine.Replace('-',''))" $verify
}

# Worker rejects an existing run/report/log, so even a second invocation
# cannot overwrite evidence. Deliberately do not rerun polar-db:none:r2.
$toRun = @(
    @('sqlite','none',2),
    @('polar-db','none',3),
    @('sqlite','none',3)
)
foreach ($case in $toRun) {
    $engine=[string]$case[0]
    $condition=[string]$case[1]
    $rep=[int]$case[2]
    $name="polar-s32c2-finish-$($engine.Replace('-',''))-$condition-r$rep"
    $command="python3 -u /work/ram-study/stage3-2/stage32_worker_c2.py --ram 8 --engine $engine --condition $condition --repeat $rep"
    Invoke-Stage $name $command $true
}

foreach ($engine in @('sqlite','polar-db')) {
    $verify="dotnet '$dll' --prepared-stage=verify --prepared-plan=uniform-v32 --prepared-root='$root' --prepared-source-sha='$dataSha' --benchmark-engine=$engine --rows=20000000"
    Invoke-Stage "polar-s32c2-finish-postverify-$($engine.Replace('-',''))" $verify
}
Invoke-Stage 'polar-s32c2-finish-summary' 'python3 /work/ram-study/stage3-2/summarize_c2.py'
Write-Host 'Stage 3.2 C2 evidence collected. Rejected runs remain excluded; no changes to article or main.'

# Polar.DB Stage 3.2 — C2 final audit (2026-11-06)

## Status and evidence provenance

- **18 attempts** in the revised C2 protocol (`stage32-c2-nearly-resident-512KiB-v1`): **16 qualifying, 2 rejected**, no automatic reclassification of failures.
- Source code SHA **`b32020fd2786942332fc8f0a2320ee5aee3cb113`**; prepared dataset SHA **`0fd84e3da854aa9f536a75861e7838af41955bdc`**; N=20,000,000, primary-int, uniform/independent key stream `44106a815bb975ddbf956a475c5b6463832ce2bdaa139b59da6c18ffa50daf57` (500 warmup + 10,000 batch + 2,000 disjoint independent latency keys).
- Each 8-GiB/no-swap host experiment uses one isolated container. Every qualifying raw JSON was independently checked against SHA metadata, result checksums, per-file cache-state conditions, batch I/O deltas, `memory.events:max` and OOM; no violations found.
- DB SHA256 reverified after series: SQLite 1 file, Polar.DB 5 files. Git `main` clean. No article or repository code edited by this audit.

## Two preserved rejected runs

1. `polar-db:none:r2` — `read_bytes` delta **716,800 B (700 KiB)** despite >=99.5% resident pages, exceeding the **512-KiB** C2 acceptance cap. The query result was correct, but this record is excluded from qualifying fully resident measurements. Its raw mean 12.304 µs is **not** included in the comparisons below.
2. `polar-db:none:r3` — terminated by `System.IO.InvalidDataException` in `PreparedCacheTreatment.AssertApplied`: **`Fully resident control lost pages before batch`**. `exit -6` is .NET unhandled exception/SIGABRT from a benchmark precondition, **not evidence of a Polar.DB search bug or OOM**. It occurred before the timed query JSON was written; no valid latency result. Outer controller priming reached 100%, but global page-cache residency changed before the runner's own pre-batch check. This demonstrates that resident state cannot be guaranteed by a prior warmup; it must be measured at the execution boundary.

## Confirmed accepted results (batch mean, µs/query; smaller is faster)

| Engine | Controlled state | r1 | r2 | r3 | Batch read_bytes, r1/r2 |
|---|---|---:|---:|---:|---|
| Polar.DB | All sealed files >=99.5% resident (`none`) | **6.149** | rejected | rejected | 0 / 0.717 MB (rejected) |
| Polar.DB | `f1.bin` hashes evicted | 8.293 | 8.218 | — | 0.160 / 0 MB |
| Polar.DB | `f2.bin` offsets evicted | 150.949 | 201.578 | — | 93.282 / 93.274 MB |
| Polar.DB | `f0.bin` row data half evicted | 131.752 | 151.398 | — | 55.837 / 55.845 MB |
| Polar.DB | `f0.bin` row data fully evicted | 243.127 | 282.194 | — | 81.142 / 81.142 MB |
| SQLite | all data/index pages resident (`none`) | 12.907 | 15.885 | 30.992 | 0 / 0 / 0 MB |
| SQLite | half of `data.sqlite` evicted | 160.067 | 128.582 | — | 31.367 / 31.367 MB |
| SQLite | entire `data.sqlite` evicted | 262.720 | 198.384 | — | 46.850 / 46.850 MB |

For Polar.DB's accepted `f2.bin` treatments the payload `f0.bin` and hash file `f1.bin` remained fully resident immediately before **and after** the batch; `f2.bin` began essentially 0% resident and rose to ~58.3%. For `f0.bin` half/full eviction, `f1.bin`/`f2.bin` remained resident. `f1.bin`-only eviction left data and offsets resident, and `f1.bin` remained virtually 0% resident after the batch. SQLite's file began at exactly 50% or 0% for its evictions. C2 randomized key lists are deterministic and identical across runs/engines, though physical page distributions and the integrated SQLite B-tree differ.

## Architectural interpretation, supported vs unproven

`src/Polar.DB/UKeyIndex.cs`, `TryGetIndexedValueAndOffsetByKey`, explicitly uses the in-process sorted hash array `hkeys_arr` to find candidate positions, then calls `offsets.GetByIndex(pos)` and `sequence.GetByOffset(candidateOffset)`. Thus:

- *Strong support:* `f1.bin` disk-page loss has modest effect because its hash values have already been loaded into `hkeys_arr` at refresh; the workload does not require fetching its file pages on each lookup.
- *Strong support:* `f2.bin` is a separately cache-sensitive index component. Its selective eviction causes 93 MB of timed-query process I/O and ~151–202 µs mean lookup time **even when `f0.bin` remains resident**. This is a new, separable mechanism missed by merely comparing total cache fractions.
- *Strong support:* partial or complete `f0.bin` eviction, with offsets fully resident, causes similarly large or larger slowdown. `f0.bin` and `f2.bin` are **both** critical for this workload's cold-page performance.
- *Unproven:* precise device-level byte attribution by path, a specific storage block's latency, a universal RAM threshold, and a causal ranking between complete SQLite's on-disk B-tree and Polar.DB architecture when equal *physical bytes* are resident. `ProcessIo.read_bytes` is process-wide and Linux cache charges are global. C2 no-eviction reference for Polar.DB has **only one qualifying run**, so quantitative multiples versus fully resident baseline (e.g. 24.55x and 39.54x from r1) are descriptive, **not stable estimated effect sizes**.
- SQLite three full-resident means (12.907, 15.885, 30.992 µs) vary markedly despite all having 0 incremental `read_bytes`. This also points to system scheduling, CPU, timing and thermal/JIT noise. It rules out treating every latency variation as I/O causality.

## Next Pareto actions

1. **Stop the uncontrolled repetition cycle.** The mechanistic C2 objective is met without forcing more attempts until baseline qualifies. Preserve the two rejected samples in the ledger; do not loosen C2 after inspecting it.
2. If considering a publication result, plan a fresh **precommitted, balanced confirmation** with per-file `mincore` at the batch boundary, post-batch recheck, explicit process/cgroup I/O, CPU-throttling metrics, a fixed allowed page-fault noise threshold and unbiased handling of rejected runs. Use enough independent sessions and disclose rejection counts. Minimize to `none`, `hashes`, `offsets`, `payload`, and optionally `payload-half`, all at the **same 8-GiB cap**; treat SQLite as a separate whole-file control. The first objective is within-engine effect reproducibility, not a RAM knee.
3. Potential follow-on architectural optimization: experiment with **optional RAM-resident offsets** (`long[]` for 20M entries ~160 MB) analogous to `hkeys_arr`, with a switch so the existing on-disk mechanism stays available. Verify correctness and quantify costs: heap/process RSS, startup/load time, page-cache pressure and query speed, using a clean A/B protocol. This is a *design hypothesis*, not an implemented change or guaranteed improvement. Avoid silently changing current baseline implementations.
4. Main article **unchanged**. Only add a concise optional section/figure when the independent confirmation supports the claim; no universal Polar.DB/SQLite winner should be inferred from this exploratory series.

Artifacts: `metrics/v32c2-*.json`, `raw/pk-int-lookup/v32c2-*.json`, `summarize_c2.py`, `finish-c2.ps1`, `README.md`. Rejected records are kept and not overwritten.

"""Immutable stage-3.2 C2 acceptance specification for NEW independent trials.
The original v32-r1 result remains rejected under the old zero-I/O criterion.
"""
MIN_RESIDENCY = 0.995
NEAR_HOT_READ_CAP_BYTES = 512 * 1024
POLAR_INDEX_FILES = ("f1.bin", "f2.bin")
PROTOCOL = "stage32-c2-nearly-resident-512KiB-v1"


def qualify(raw, condition):
    reasons = []
    snapshots = raw["Snapshots"]
    begin = snapshots["AfterCacheTreatment"]
    end = snapshots["AfterBatch"]
    read_bytes = end["ProcessIo"].get("read_bytes", 0) - begin["ProcessIo"].get("read_bytes", 0)
    pre_treat = {f["Name"]: f["Fraction"] for f in raw["ResidencyBeforeTreatment"]["Files"]}
    pre = {f["Name"]: f["Fraction"] for f in raw["ResidencyBeforeBatch"]["Files"]}
    post = {f["Name"]: f["Fraction"] for f in raw["ResidencyAfterBatch"]["Files"]}
    if any(f < MIN_RESIDENCY for f in pre_treat.values()):
        reasons.append("not-all-files-resident-before-intervention")
    if read_bytes < 0:
        reasons.append("negative-read-byte-delta")
    if condition == "none":
        if any(f < MIN_RESIDENCY for f in pre.values()):
            reasons.append("pre-batch-residency-below-99.5-percent")
        if any(f < MIN_RESIDENCY for f in post.values()):
            reasons.append("post-batch-residency-below-99.5-percent")
        if read_bytes > NEAR_HOT_READ_CAP_BYTES:
            reasons.append("nearly-resident-control-read-more-than-512KiB")
    else:
        if raw["Engine"] == "polar-db":
            selected = {"payload": "f0.bin", "payload-half": "f0.bin",
                        "hashes": "f1.bin", "offsets": "f2.bin"}[condition]
            # Crucial: a post-intervention loss of unselected pages would
            # invalidate causal attribution to the selected file.
            for name in ("f0.bin", *POLAR_INDEX_FILES):
                if name == selected:
                    continue
                if pre.get(name, 0) < MIN_RESIDENCY or post.get(name, 0) < MIN_RESIDENCY:
                    reasons.append("unselected-file-not-resident-" + name)
    return reasons, {"batchReadBytes": read_bytes,
                     "before": raw["ResidencyBeforeTreatment"]["Files"],
                     "preBatch": raw["ResidencyBeforeBatch"]["Files"],
                     "postBatch": raw["ResidencyAfterBatch"]["Files"]}

param([int[]]$Repeats = @(1,2))
$ErrorActionPreference = 'Stop'

# Source SHA: b32020f; prepared 20M datasets: 0fd84e3.
# Each treatment runs in a new 8-GiB/no-swap container. Strict failure stop.
function Invoke-Isolated([string]$Name,[string]$Action) {
    Write-Host "=== $Name : 8 GiB, no swap ==="
    docker run --rm `
       --name $Name `
       --memory='8g' --memory-swap='8g' `
       --mount type=volume,source=polar-bench-data,target=/work `
       --workdir /work/Polar.DB `
       mcr.microsoft.com/dotnet/sdk:10.0 `
       bash -lc "apt-get update -qq && apt-get install -y -qq python3 git > /dev/null && $Action"
    if ($LASTEXITCODE -ne 0) {
       throw "FAIL: $Name exit=$LASTEXITCODE. Inspect /work/ram-study/stage3-2/metrics before retry."
    }
}

$root='/work/ram-study/stage3-0fd84e3/prepared-20000000'
$source='0fd84e3da854aa9f536a75861e7838af41955bdc'
$dll='/work/Polar.DB/benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'
foreach ($engine in @('sqlite','polar-db')) {
    $cmd="dotnet '$dll' --prepared-stage=verify --prepared-plan=uniform-v32 --prepared-root='$root' --prepared-source-sha='$source' --benchmark-engine='$engine' --rows=20000000"
    Invoke-Isolated "polar-s32-preverify-$($engine.Replace('-',''))" $cmd
}

$cases = @(
    'sqlite:none', 'polar-db:none',
    'polar-db:hashes', 'polar-db:offsets',
    'sqlite:data-half', 'polar-db:payload-half',
    'sqlite:data', 'polar-db:payload'
)
foreach ($rep in $Repeats) {
    $ordered = @($cases)
    if ($rep % 2 -eq 0) { [array]::Reverse($ordered) }
    foreach ($test in $ordered) {
        $parts = $test.Split(':')
        $engine = $parts[0]
        $condition = $parts[1]
        $name = "polar-s32-$($engine.Replace('-',''))-$condition-r$rep"
        $cmd = "python3 -u /work/ram-study/stage3-2/stage32_worker.py --ram 8 --engine $engine --condition $condition --repeat $rep"
        Invoke-Isolated $name $cmd
    }
}
foreach ($engine in @('sqlite','polar-db')) {
    $cmd="dotnet '$dll' --prepared-stage=verify --prepared-plan=uniform-v32 --prepared-root='$root' --prepared-source-sha='$source' --benchmark-engine='$engine' --rows=20000000"
    Invoke-Isolated "polar-s32-postverify-$($engine.Replace('-',''))" $cmd
}
Invoke-Isolated 'polar-s32-report' 'python3 /work/ram-study/stage3-2/summarize32.py'
Write-Host 'Stage 3.2 host pilot finished. Article unchanged.'

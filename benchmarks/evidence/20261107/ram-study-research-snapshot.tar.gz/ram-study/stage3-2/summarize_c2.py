#!/usr/bin/env python3
"""Audit cache-treatment results, emphasizing within-engine effects."""
from collections import defaultdict
import json,statistics,math
from pathlib import Path

ROOT=Path('/work/ram-study/stage3-2')
SOURCE='0fd84e3da854aa9f536a75861e7838af41955bdc'
RUNNER='b32020fd2786942332fc8f0a2320ee5aee3cb113'
KEYS='44106a815bb975ddbf956a475c5b6463832ce2bdaa139b59da6c18ffa50daf57'


def pct(data,p):
    s=sorted(data)
    return s[max(0,math.ceil(len(s)*p)-1)]


def main():
    rows=[]
    for path in sorted((ROOT/'metrics').glob('v32c2-*.json')):
        m=json.loads(path.read_text())
        if m.get('acceptanceProtocol') != 'stage32-c2-nearly-resident-512KiB-v1':
            print('REJECT',m.get('runId'),'wrong acceptance protocol')
            continue
        if not m['qualified']:
            print('REJECT',m['runId'],','.join(m['rejectReasons']))
            continue
        raw=Path(m['raw']) if m.get('raw') else None
        if not raw or not raw.exists():
            print('REJECT',m['runId'],'raw missing')
            continue
        d=json.loads(raw.read_text())
        assert d['QueryRunnerSha']==RUNNER and d['SourceSha']==SOURCE
        assert d['PlanKeyStreamSha256']==KEYS and d['CacheTreatment']==m['condition']
        assert d['ExpectedBatch']['Checksum']==d['BatchChecksum']
        assert d['ExpectedLatency']['Checksum']==d['LatencyChecksum']
        assert d['ResidencyBeforeTreatment']['Fraction']>=.995
        io=d['Snapshots'];x=io['AfterCacheTreatment'];y=io['AfterBatch']
        read=y['ProcessIo'].get('read_bytes',0)-x['ProcessIo'].get('read_bytes',0)
        refault=y['MemoryCgroup'].get('workingset_refault_file',0)-x['MemoryCgroup'].get('workingset_refault_file',0)
        filecache={v['Name']:v['Fraction'] for v in d['ResidencyBeforeBatch']['Files']}
        postcache={v['Name']:v['Fraction'] for v in d['ResidencyAfterBatch']['Files']}
        row={'engine':m['engine'],'condition':m['condition'],'rep':m['repeat'],
            'mean_us':statistics.mean(d['BatchAverageMs'])*1000,
            'median_batch_us':statistics.median(d['BatchAverageMs'])*1000,
            'lat95_us':pct(d['LatencySamplesMs'],.95)*1000,
            'read_MB':read/1e6,'refault':refault,
            'pre':filecache,'post':postcache,'cgroup_peak':m['cgroupPeakSampledGiB']}
        rows.append(row)
    print('QUALIFIED',len(rows),'v32 C2 runs (near-resident control may include <=512KiB read_bytes)')
    print('rep,engine,condition,batch_mean_us,median_of_batch_means_us,independent_p95_us,batch_read_MB,batch_refault,pre_file_residency,post_file_residency,cgroup_peak_GiB')
    for r in sorted(rows,key=lambda x:(x['rep'],x['engine'],x['condition'])):
        vals=[r['rep'],r['engine'],r['condition'],round(r['mean_us'],3),
              round(r['median_batch_us'],3),round(r['lat95_us'],3),
              round(r['read_MB'],3),r['refault'],
              ';'.join(f'{k}:{v:.3f}' for k,v in r['pre'].items()),
              ';'.join(f'{k}:{v:.3f}' for k,v in r['post'].items()),r['cgroup_peak']]
        print(','.join(map(str,vals)))
    baselines={(r['rep'],r['engine']):r for r in rows if r['condition']=='none'}
    print('\nWITHIN ENGINE treatment slowdown (condition / fully-resident none)')
    for r in sorted(rows,key=lambda x:(x['rep'],x['engine'],x['condition'])):
        if r['condition']=='none':continue
        base=baselines.get((r['rep'],r['engine']))
        if base:
            print('PAIR',r['rep'],r['engine'],r['condition'],
                  'slowdown',round(r['mean_us']/base['mean_us'],3),'x',
                  'additional read MB',round(r['read_MB']-base['read_MB'],3))
    print('\nCAUTION: cgroup + process I/O counters do not identify disk bytes by pathname. A targeted intervention plus per-file mincore provides stronger attribution, but SQLite stores index and records together. No universal RAM threshold inferred.')

if __name__=='__main__':main()

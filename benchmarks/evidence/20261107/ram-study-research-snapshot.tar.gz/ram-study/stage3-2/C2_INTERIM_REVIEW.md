# Stage 3.2 C2 — interim review after interrupted host run (2026-11-06)

**Status:** 15 C2 attempts recorded, 14 accepted, one *rejected*. Last expected case `sqlite:none:r2` was not run because the launcher stopped on rejected `polar-db:none:r2`. Pre-run dataset hashes were verified. Post-interruption SHA-256 re-verification from RDC passed for SQLite's 1 sealed file and Polar.DB's 5 sealed files. Source git `main` clean at `b32020fd2786942332fc8f0a2320ee5aee3cb113`; base prepared data SHA `0fd84e3da854aa9f536a75861e7838af41955bdc`. Main article unchanged.

## Acceptance failure

- `polar-db:none:r2`: all files >=99.5% resident just before/after batch; `read_bytes` delta **716,800 bytes (700 KiB)**, above the preregistered C2 **524,288 bytes (512 KiB)** limit. Zero OOM/`memory.events.max`, checksums correct.
- Raw, *rejected* observed mean 12.304 µs per lookup; **do not pool with accepted zero/near-zero-IO `none` controls**.
- C1 `sqlite:none:r1` (65,536 read bytes) remains separately rejected under C1's original strictly-zero-I/O rule. Do not retroactively reclassify either trial or relax C2 threshold in response to this observed failure.

## Accepted exploratory C2 values, 20M primary int, 8 GiB

Mean microseconds per lookup in fixed 10,000-key uniform batch. All `batchReadBytes` are worker process `read_bytes` deltas after the selected intervention, not per-path physical disk I/O.

| Engine | Intervention | Accepted r1 mean | Accepted r2 mean | Read MB r1 / r2 | Target residency immediately before batch |
|---|---|---:|---:|---|---|
| Polar.DB | none | 6.149 | **rejected** | 0 / 0.717 (rejected) | all files ~100% |
| Polar.DB | hashes `f1.bin` | 8.293 | 8.218 | 0.160 / 0 | f1 effectively 0%, f0/f2 ~100% |
| Polar.DB | offsets `f2.bin` | 150.949 | 201.578 | 93.282 / 93.274 | f2 effectively 0%, f0/f1 ~100% |
| Polar.DB | payload-half `f0.bin` | 131.752 | 151.398 | 55.837 / 55.845 | f0 ~50%, f1/f2 ~100% |
| Polar.DB | payload `f0.bin` | 243.127 | 282.194 | 81.142 / 81.142 | f0 effectively 0%, f1/f2 ~100% |
| SQLite | none | 12.907 | **not yet run** | 0 / — | SQLite file 100% |
| SQLite | data-half | 160.067 | 128.582 | 31.367 / 31.367 | SQLite file ~50% |
| SQLite | data | 262.720 | 198.384 | 46.850 / 46.850 | SQLite file effectively 0% |

The two independent interventions demonstrate a strong cache-dependent slowdown for Polar.DB's **offset file** `f2.bin`, even while its payload `f0.bin` stays resident, not just for the payload itself. Evicting `f1.bin` causes little measured read IO because UKeyIndex's hot primary lookup uses its in-process `hkeys_arr` for binary search; offsets still call `offsets.GetByIndex(pos)` and payload still calls `sequence.GetByOffset(candidateOffset)`. This is grounded in `src/Polar.DB/UKeyIndex.cs` around `TryGetIndexedValueAndOffsetByKey`. It is evidence of selective page-cache sensitivity for those file-backed access paths, not a proof of exact physical SSD reads from a particular file, because `read_bytes` is process-wide and full file layouts differ from SQLite's integrated B-tree.

## Next safe action

Do not rerun `run-host-c2.ps1`: it would attempt already existing IDs and refuse to overwrite them. Instead use **`finish-c2.ps1`** (outside git repo): verify DB SHA, run only `sqlite:none:r2` plus one independently designated new baseline pair `polar-db:none:r3` and `sqlite:none:r3`, re-verify DB SHA, summarize all accepted/rejected observations. The rejected `polar-db:none:r2` stays untouched. If any new run fails qualification, retain it as rejected and proceed with remaining planned runs; do not repeatedly resample until a favorable result is obtained. The script never mutates source code or rebuilds datasets.

Even if r3 controls are successful, the study is an explanatory pilot; a publication claim requires a separately planned independent confirmation at fixed selection rules and sufficient samples. The half/whole treatments with two accepted runs each already provide useful mechanical evidence.

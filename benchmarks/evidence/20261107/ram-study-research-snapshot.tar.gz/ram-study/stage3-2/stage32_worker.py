#!/usr/bin/env python3
"""Guarded v32 query-only per-file cache intervention; one attempt per run."""
import argparse, json, os, shutil, signal, subprocess, sys, time
from pathlib import Path
sys.path.insert(0,'/work/ram-study')
from stage3_cache import dataset_pages

GIB=1024**3
ROOT=Path('/work/Polar.DB');CG=Path('/sys/fs/cgroup')
STUDY=Path('/work/ram-study/stage3-2')
DATA=Path('/work/ram-study/stage3-0fd84e3/prepared-20000000')
DATA_SHA='0fd84e3da854aa9f536a75861e7838af41955bdc'
RUNNER_SHA='b32020fd2786942332fc8f0a2320ee5aee3cb113'


def integer(name):
    try:return int((CG/name).read_text().strip())
    except (OSError,ValueError):return -1


def pairs(name):
    try:return {s[0].rstrip(':'):int(s[1]) for line in (CG/name).read_text().splitlines()
                if len(s:=line.split())==2 and s[1].lstrip('-').isdigit()}
    except OSError:return {}


def hwm(pid):
    try:return max([int(line.split()[1])*1024 for line in
        Path(f'/proc/{pid}/status').read_text().splitlines() if line.startswith('VmHWM:')] or [0])
    except OSError:return 0


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--engine',choices=('sqlite','polar-db'),required=True)
    ap.add_argument('--condition',required=True)
    ap.add_argument('--repeat',type=int,choices=(1,2,3),required=True)
    ap.add_argument('--ram',type=int,choices=(8,),required=True)
    a=ap.parse_args()
    allowed={'sqlite':('none','data-half','data'),
             'polar-db':('none','payload-half','payload','hashes','offsets')}
    if a.condition not in allowed[a.engine]:sys.exit('Invalid engine/condition')
    if integer('memory.max')!=a.ram*GIB or integer('memory.swap.max')!=0:
        sys.exit('Refuse wrong memory or swap limit')
    sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    if sha!=RUNNER_SHA or subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True).strip():
        sys.exit('Refuse wrong/dirty source SHA')
    folder=DATA/'pk-int-lookup/rows-20000000'
    seal=json.loads((folder/(a.engine+'.ready.json')).read_text())
    plan=json.loads((folder/(a.engine+'.uniform-v32.json')).read_text())
    if seal['SourceSha']!=DATA_SHA or seal['Rows']!=20_000_000 or seal['Engine']!=a.engine:
        sys.exit('Prepared data provenance mismatch')
    if plan['RunnerSourceSha']!=RUNNER_SHA or plan['DatasetSourceSha']!=DATA_SHA or plan['ProtocolVersion']!=32:
        sys.exit('Prepared plan provenance mismatch')
    if shutil.disk_usage(ROOT).free<20*GIB:sys.exit('Low disk reserve')
    tag=f'v32-20m-8g-{a.engine}-{a.condition}-r{a.repeat}'
    out=STUDY/'metrics';out.mkdir(parents=True,exist_ok=True)
    report=out/(tag+'.json');log=out/(tag+'.log')
    if report.exists() or log.exists():sys.exit('Refuse to overwrite '+tag)
    datadir=folder/a.engine
    beforePrime=dataset_pages(datadir,seal['Files'])
    afterPrime=beforePrime;passes=0
    while afterPrime['fraction']<.995 and passes<4:
        for f in seal['Files']:
            with (datadir/f['Name']).open('rb',buffering=1048576) as h:
                while h.read(1048576):pass
        passes+=1
        afterPrime=dataset_pages(datadir,seal['Files'])
    print('PRIME',tag,'before',beforePrime['fraction'],'after',afterPrime['fraction'],'passes',passes,flush=True)
    if afterPrime['fraction']<.995:sys.exit('Cannot establish fully resident baseline')
    raw=STUDY/'raw';binary=ROOT/'benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'
    cmd=['dotnet',str(binary),'--prepared-stage=query','--prepared-plan=uniform-v32',
         f'--prepared-root={DATA}',f'--prepared-results-root={raw}',
         f'--prepared-source-sha={DATA_SHA}',f'--benchmark-engine={a.engine}',
         f'--prepared-cache-treatment={a.condition}','--rows=20000000',f'--benchmark-run-id={tag}']
    events=pairs('memory.events');stat=pairs('memory.stat')
    started=time.monotonic();peak=integer('memory.current');maxrss=0;reason=None
    disk=shutil.disk_usage(ROOT).free
    with log.open('x') as output:
        proc=subprocess.Popen(cmd,cwd=ROOT,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
        while proc.poll() is None:
            peak=max(peak,integer('memory.current'));maxrss=max(maxrss,hwm(proc.pid))
            if time.monotonic()-started>120:reason='timeout'
            elif disk-shutil.disk_usage(ROOT).free>GIB or shutil.disk_usage(ROOT).free<16*GIB:
                reason='disk reserve/growth'
            if reason:
                try:os.killpg(proc.pid,signal.SIGTERM)
                except ProcessLookupError:pass
                break
            time.sleep(.05)
        try:code=proc.wait(timeout=4)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL);code=proc.wait()
    endEvents=pairs('memory.events');endStat=pairs('memory.stat')
    rawpath=raw/'pk-int-lookup'/(tag+'.json')
    rejected=[]
    if reason or code:rejected.append(reason or f'exit {code}')
    if endEvents.get('max',0)-events.get('max',0):rejected.append('cgroup memory.max hit')
    if endEvents.get('oom_kill',0)-events.get('oom_kill',0):rejected.append('OOM kill')
    details={}
    if rawpath.exists():
        result=json.loads(rawpath.read_text())
        if result['QueryRunnerSha']!=RUNNER_SHA or result['SourceSha']!=DATA_SHA or result['CacheTreatment']!=a.condition:
            rejected.append('source/condition mismatch')
        if result['BatchChecksum']!=result['ExpectedBatch']['Checksum'] or result['LatencyChecksum']!=result['ExpectedLatency']['Checksum']:
            rejected.append('checksum mismatch')
        if result['ResidencyBeforeTreatment']['Fraction']<.995:rejected.append('pre-treatment lost cache')
        s=result['Snapshots'];begin=s['AfterCacheTreatment']
        reads=s['AfterBatch']['ProcessIo'].get('read_bytes',0)-begin['ProcessIo'].get('read_bytes',0)
        if a.condition=='none' and reads!=0:rejected.append('unexpected reads in full-cache control')
        details={'batchReadBytes':reads,'before':result['ResidencyBeforeTreatment']['Files'],
                 'preBatch':result['ResidencyBeforeBatch']['Files'],'postBatch':result['ResidencyAfterBatch']['Files']}
    else:rejected.append('missing query result')
    record={'runId':tag,'engine':a.engine,'condition':a.condition,'repeat':a.repeat,
       'runnerSha':sha,'dataSha':DATA_SHA,'exitCode':code,'failure':reason,
       'qualified':not rejected,'rejectReasons':rejected,
       'elapsedSeconds':round(time.monotonic()-started,3),'cacheBeforePriming':beforePrime,
       'cacheAfterPriming':afterPrime,'primePasses':passes,
       'cgroupPeakSampledGiB':round(peak/GIB,4),'processHwmSampledMiB':round(maxrss/1048576,2),
       'eventsDelta':{k:endEvents.get(k,0)-v for k,v in events.items()},
       'statDelta':{k:endStat.get(k,0)-stat.get(k,0) for k in ('pgscan','pgsteal','workingset_refault_file','pgmajfault')},
       'details':details,'raw':str(rawpath) if rawpath.exists() else None,'log':str(log)}
    report.write_text(json.dumps(record,indent=2)+'\n')
    print('RESULT',json.dumps({k:record[k] for k in ('runId','qualified','rejectReasons','cgroupPeakSampledGiB','details')}),flush=True)
    if rejected:sys.exit(1)

if __name__=='__main__':main()

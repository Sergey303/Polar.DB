#!/usr/bin/env python3
"""Create a deterministic portable snapshot of available RAM-study research assets."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path

root=Path('/work/ram-study')
output=Path('/work/Polar.DB/benchmarks/evidence/20261107')
output.mkdir(parents=True,exist_ok=True)
archive=output/'ram-study-research-snapshot.tar.gz'
manifest=output/'file-manifest.sha256'
excluded=output/'excluded-large-files.tsv'
if any(p.exists() for p in (archive,manifest,excluded)):
    raise SystemExit('Refuse to overwrite existing preservation material')
exclude_suffix={'.bin','.sqlite','.db','.pac','.so','.dll','.pdb','.exe','.jpg','.png','.dat','.state','.index'}
files=[];missing=[]
for f in root.rglob('*'):
    if not f.is_file() or f.is_symlink():continue
    rel=f.relative_to(root)
    if any(x in rel.parts for x in ('__pycache__','node_modules','.git','bin','obj')):continue
    if f.name=='rdc-agent.log' or f.name.startswith('.env') or f.suffix.lower() in exclude_suffix or f.stat().st_size>5_000_000:
        missing.append((str(rel),f.stat().st_size,'binary/data/agent-log or >5MB'))
        continue
    files.append(f)
files.sort(key=lambda f:f.relative_to(root).as_posix())
manifest_lines=[]
with archive.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0,compresslevel=9) as gz:
        with tarfile.open(fileobj=gz,mode='w') as tar:
            for f in files:
                rel=f.relative_to(root)
                payload=f.read_bytes()
                hashed=hashlib.sha256(payload).hexdigest()
                manifest_lines.append(f'{hashed}  ram-study/{rel.as_posix()}')
                info=tarfile.TarInfo('ram-study/'+rel.as_posix())
                info.size=len(payload);info.mode=0o644;info.uid=0;info.gid=0
                info.uname='';info.gname='';info.mtime=0
                tar.addfile(info,io.BytesIO(payload))
manifest.write_text('\n'.join(manifest_lines)+'\n')
excluded.write_text('relative_path\tbytes\treason\n'+'\n'.join('\t'.join(map(str,v)) for v in sorted(missing))+'\n')
print('SNAPSHOT',archive,archive.stat().st_size,'bytes')
print('SHA256',hashlib.sha256(archive.read_bytes()).hexdigest())
print('files',len(files),'excluded',len(missing))
print('manifest',manifest.stat().st_size,'bytes')
with tarfile.open(archive,'r:gz') as tar:
    names=tar.getnames();assert len(names)==len(files)
    required=['ram-study/stage5-editorial/PREMORTEM_RECHECK_20261107.md',
      'ram-study/stage5-editorial/EDITORIAL_AUDIT.md',
      'ram-study/stage4b-pinned-confirmation/STAGE4B_RESULTS.json',
      'ram-study/stage4b-pinned-confirmation/LOCK.json',
      'ram-study/stage4-confirmation/STAGE4_RESULTS.json',
      'ram-study/stage3-2/C2_FINAL_REVIEW.md']
    for name in required:assert name in names,name
    assert sum('/stage4b-pinned-confirmation/results/s4b-' in n and n.endswith('.json') for n in names)==48
    assert sum('/stage4b-pinned-confirmation/raw/pk-int-lookup/s4b-' in n and n.endswith('.json') for n in names)==48
    print('VERIFIED required material; 48 per-attempt JSON plus 48 raw lookup JSON')

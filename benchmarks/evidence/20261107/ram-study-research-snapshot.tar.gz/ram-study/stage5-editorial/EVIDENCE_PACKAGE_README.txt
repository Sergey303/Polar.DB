Polar.DB stage 5 evidence package (2026-11-07)

Original Stage 4B research evidence resides in:
  /work/ram-study/stage4b-pinned-confirmation/
This archive contains prospectively locked protocol/scripts/schedule,
48 immutable start/result/log files, 48 raw query JSON, and the final
STAGE4B_RESULTS.json with its independent audit and hash. It does not
contain the 20-million-row prepared database files (~4.35 GB across two
engines). To reproduce searches, rebuild those from dataset source Git
commit 0fd84e3da854aa9f536a75861e7838af41955bdc and verify hashes
against stage4b manifests. Runner source Git SHA is
 a11457ce502b416041ea7bde0b53d2dc047db491.

The evidence archive is stored on the original research host and is not
publicly hosted. Do not claim external access until separately published.
Its contents and hash may be referenced in an editorial manuscript to
identify which original files support the claims. Stage 4 original
INCONCLUSIVE results remain separate and are not included in the Stage 4B
confirmatory estimates.

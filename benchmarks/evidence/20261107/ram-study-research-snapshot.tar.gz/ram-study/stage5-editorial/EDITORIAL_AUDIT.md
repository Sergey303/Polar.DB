# Polar.DB — Stage 5 editorial acceptance (2026-11-07)

## Scope and disposition

The Stage 5 manuscript revision integrates the distinct, independently preregistered `uniform-v4` Stage 4B result without mixing it with the existing main-series medians. The engine implementation and measurement code remain unchanged. The research claim is limited to *Polar.DB lookup with cold offset file f2.bin versus cold persisted-hash file f1.bin under pinned-cache intervention*; it is not a database-vs-database win ratio or a generic RAM crossover claim.

## Files to commit

- `benchmarks/docs/POLAR_DB_ARTICLE_DRAFT.md` — adds 3.8 method, 4.7 results (table 10), adjusted discussion, limitations, abstract, conclusion and provenance. Original tables 1–9 remain byte-identical.
- `benchmarks/docs/POLAR_DB_ARTICLE_TECHNICAL_MATERIALS.md` — adds a succinct Appendix Е linking to the detailed evidence study and explaining separation of historical results.
- `benchmarks/docs/PRIMARY_OFFSET_RESIDENCY_20261107.md` — new bounded 60-line research note with all eight paired measurements, experimental controls, exact hashes, and limitations.

## Independent checks

Executed `python3 /work/ram-study/stage5-editorial/verify_stage5.py` against immutable raw data and the pre-editorial original manuscript. PASS: all nine original Markdown result tables identical byte-for-byte; all six Stage 4B condition means match the sealed final JSON; eight block-paired values match individual JSON metadata and derive the reported 23.6216 ratio; article/technical note links resolve; no duplicate table 10, new note <=150 lines; the local evidence archive SHA-256 matches its contents and includes all 48 per-attempt raw query JSON, 48 results JSON and 48 start markers. `git diff --check` PASS.

Stage 4B locked protocol SHA-256: `0173a5e8fa63f9c117a36de52239875c46b7a33a1551f8f21f87bc3dd48a2b0c`. Stage 4B final machine JSON SHA-256: `b47cd3140bca5ea9a9cf9db0bc9ddbac219cb25c73278a047e90e1ef0e96bb82`. The new evidence archive `POLAR_DB_STAGE4B_EVIDENCE_20261107.tar.gz` SHA-256: `4478c831a037c3b935ff2da42f0e1d1d5f373bf3b8b70bc64ad8889fb92d7a20`.

## Publication readiness limitation

The local 421-KB archive is **not yet hosted publicly** and does not contain the approximately 4.35-GB original prepared databases. Its hash and location are documented rather than implying access that has not been provided. External replication requires publication of the package and either prepared data or a documented dataset-generation recipe with hash verification. Prior Stage 4 is historically INCONCLUSIVE; new Stage 4B satisfies its *own* preregistered criterion and cannot retroactively change the earlier outcome.

Code/public API changes: none. Benchmark suite: no new runs for this editorial phase; evidence checked against previously collected, signed results. After publishing the three Markdown files, re-run consistency verification and make sure the public Git tree equals the locally reviewed tree.

#!/usr/bin/env python3
"""Editorial and evidence cross-check; read-only, independent of original runs."""
import hashlib,json,re,statistics,math,tarfile
from pathlib import Path
R=Path('/work/Polar.DB/benchmarks/docs')
B=Path('/work/ram-study/stage5-editorial')
S=Path('/work/ram-study/stage4b-pinned-confirmation')
orig=(B/'ARTICLE_BEFORE_STAGE5.md').read_text()
paper=(R/'POLAR_DB_ARTICLE_DRAFT.md').read_text()
tech=(R/'POLAR_DB_ARTICLE_TECHNICAL_MATERIALS.md').read_text()
note=(R/'PRIMARY_OFFSET_RESIDENCY_20261107.md').read_text()

def table(text,number):
    match=re.search(rf'^Таблица {number} — [^\n]*\n\n((?:\|[^\n]*\n)+)',text,re.M)
    assert match,f'Missing Table {number}'
    return match.group(1)

# Preserve all baseline numeric tables, header, units and row ordering verbatim.
for number in range(1,10):
    assert table(orig,number)==table(paper,number),f'Original table {number} unexpectedly changed'
print('PASS original nine tables all byte-for-byte identical')
assert paper.count('Таблица 10 —')==1
assert len(note.splitlines())<=150
assert len(re.findall(r'^### 4\.\d+\.',paper,re.M))==9
assert [int(x) for x in re.findall(r'^### 4\.(\d+)\.',paper,re.M)]==list(range(1,10))
assert [int(x) for x in re.findall(r'^### 3\.(\d+)\.',paper,re.M)]==list(range(1,9))
assert paper.count('95%-й bootstrap-интервал')>=1
assert 'INCONCLUSIVE' in note and 'INCONCLUSIVE' in tech
assert 'не' in paper and 'общедоступном' in paper

j=json.loads((S/'STAGE4B_RESULTS.json').read_text())
assert j['planned']==j['attempted']==j['accepted']==48
assert j['primaryDecision']=='PRIMARY_REPLICATED'
primary=j['comparisons']['primaryOffsetsVsHashes']
assert primary['pairs']==8 and all(x>1 for x in primary['rawPairRatios'])
assert abs(primary['geometricMeanRatio']-23.62163332686476)<1e-8
assert abs(primary['bootstrap95CI'][0]-20.826837229219098)<1e-8
for statement in ('23,62','20,83–26,31','восьми парах'):
    assert statement in paper,statement
for engine,condition,label in [('polar-db','none','11,793'),('polar-db','hashes','9,017'),
 ('polar-db','offsets','210,689'),('polar-db','payload','230,837'),
 ('sqlite','none','19,167'),('sqlite','data','249,257')]:
    v=j['perCondition'][f'{engine}:{condition}']['meanUs']
    assert abs(v-float(label.replace(',','.')))<.0005,(engine,condition,v)
    assert label in table(paper,10)
print('PASS all six condition means, source provenance and primary paired interval')

for block in range(1,9):
    hashes=json.loads((S/'results'/f's4b-b{block:02d}-polar-db-hashes.json').read_text())['meanBatchLookupUs']
    offsets=json.loads((S/'results'/f's4b-b{block:02d}-polar-db-offsets.json').read_text())['meanBatchLookupUs']
    line=next(x for x in note.splitlines() if x.startswith(f'| {block} |'))
    cells=[x.strip() for x in line.strip('|').split('|')]
    observed=[float(x.replace(',','.')) for x in cells[1:]]
    assert abs(observed[0]-hashes)<.0005
    assert abs(observed[1]-offsets)<.0005
    assert abs(observed[2]-offsets/hashes)<.0005
print('PASS all eight quoted pair rows')

# Check relative links in the two edited manuscript files and new evidence note.
for f,body in [(R/'POLAR_DB_ARTICLE_DRAFT.md',paper),
                (R/'POLAR_DB_ARTICLE_TECHNICAL_MATERIALS.md',tech),
                (R/'PRIMARY_OFFSET_RESIDENCY_20261107.md',note)]:
    for href in re.findall(r'\]\(([^)]*)\)',body):
        if href.startswith(('http:','https:','#','mailto:')):continue
        target=href.split('#',1)[0]
        if target:assert (f.parent/target).exists(),(f.name,href)
print('PASS all local Markdown link destinations')
archive=B/'POLAR_DB_STAGE4B_EVIDENCE_20261107.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='4478c831a037c3b935ff2da42f0e1d1d5f373bf3b8b70bc64ad8889fb92d7a20'
with tarfile.open(archive,'r:gz') as tar:
    names=tar.getnames()
    assert sum(x.startswith('stage4b-pinned-confirmation/results/s4b-') and x.endswith('.json') for x in names)==48
    assert sum(x.startswith('stage4b-pinned-confirmation/raw/pk-int-lookup/s4b-') and x.endswith('.json') for x in names)==48
    assert sum(x.startswith('stage4b-pinned-confirmation/results/s4b-') and x.endswith('.started') for x in names)==48
print('PASS evidence archive SHA256, 48 raw JSON, 48 results and 48 started markers')
print('ALL EDITORIAL CHECKS PASS')

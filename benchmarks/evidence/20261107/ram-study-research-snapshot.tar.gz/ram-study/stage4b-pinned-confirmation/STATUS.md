# Stage 4B status — 2026-11-06, ready for independent Docker host series

**Prepared and frozen; 0/48 trials have been started.** The two accessible RDC machines do not have the Docker daemon or Windows Docker Desktop connectivity, so executing the 48-run series requires the user's connected Windows Docker host, via the same tested `polar-bench-data` volume as earlier experiments.

- Independent, prospectively fixed 8-block/48-attempt schedule, seed `20261107`, with each six-condition block followed by a reversed-order counterpart.
- Fully frozen source `a11457ce502b416041ea7bde0b53d2dc047db491` and 20M prepared databases source `0fd84e3da854aa9f536a75861e7838af41955bdc`, exact DLL SHA `6c726f9e8090130466cdc95e7be4f27c37d89a68ba0ca8759f580a6be8bf1911` and uniform key stream `44106a815bb975ddbf956a475c5b6463832ce2bdaa139b59da6c18ffa50daf57`.
- `uniform-v4` in-process `mmap`/`mlock`; no external scan; 8 GiB RAM, 0 swap, 3 GiB `memlock`; checks mincore before/after treatment, selected page eviction and retained pin bytes, all checksums, I/O, cgroup memory and CPU.
- Primary: paired Polar.DB `offsets` / `hashes` geometric mean ratio; accept independent confirmation only with >=6/8 valid pairs and 10k-replicate paired-bootstrap 95% lower bound >1. All started/failed attempts remain counted; no retries to get preferred numbers.
- Lock SHA256 `0173a5e8fa63f9c117a36de52239875c46b7a33a1551f8f21f87bc3dd48a2b0c`; all 11 sealed files verified. Initial preflight lock with incompatible copied validator is preserved in `preflight-archive/` and was superseded **before any run**; no protocol outcomes or acceptance thresholds changed.
- Python tests, negative eligibility cases, deterministic schedule, PowerShell syntax and fixed Docker image-ID bash expression passed. A deliberately rejected RDC process with incorrect cgroup produced no `.started` or data files. Source DB files and v4 sidecars SHA-256 verified; Git main clean and synchronized.
- Main scientific manuscript, Stage 3.* evidence, original Stage 4 `INCONCLUSIVE` decision and Stage 4.1 engineering evidence are untouched.

**Host launch:** copy `run-host.ps1` from named volume to Windows PowerShell as shown in `README.md`, then execute it. When finished, rerun `python3 analyze.py --finalize` only if the host launcher did not already create `STAGE4B_RESULTS.json`; never rerun any started experiment. Analyze completed JSONs with full rejection ledger and compare to the predefined decision rule.

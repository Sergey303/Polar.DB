param(
    [int[]] $Blocks = @(1,2,3,4,5,6,7,8),
    [switch] $Resume
)
$ErrorActionPreference = 'Stop'
$volume = 'type=volume,source=polar-bench-data,target=/work'
$study = '/work/ram-study/stage4b-pinned-confirmation'
$prepared = '/work/ram-study/stage3-0fd84e3/prepared-20000000'
$sourceSha = '0fd84e3da854aa9f536a75861e7838af41955bdc'
$dll = '/work/Polar.DB/benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'

# Use the existing tested tools image, or build once from the frozen Dockerfile.
$imageTag = 'polar-stage4-local:v1'
docker image inspect $imageTag *> $null
if ($LASTEXITCODE -ne 0) {
    $buildDir = Join-Path $env:TEMP 'polar-stage4b-tools-image'
    New-Item -ItemType Directory -Path $buildDir -Force | Out-Null
    docker run --rm --mount $volume mcr.microsoft.com/dotnet/sdk:10.0 `
        cat "$study/Dockerfile" |
        Set-Content -Encoding ASCII (Join-Path $buildDir 'Dockerfile')
    if ($LASTEXITCODE -ne 0) { throw 'Cannot fetch the frozen Stage4B Dockerfile' }
    docker build -t $imageTag $buildDir
    if ($LASTEXITCODE -ne 0) { throw 'Cannot create the local tools image' }
}
$imageId = (docker image inspect --format '{{.Id}}' $imageTag).Trim()
if ($LASTEXITCODE -ne 0 -or !$imageId.StartsWith('sha256:')) {
    throw 'Cannot establish a fixed Docker image ID'
}
Write-Host "IMAGE ID: $imageId"

# The first invocation writes this once. A subsequent invocation MUST match.
docker run --rm --mount $volume --env "FROZEN_IMAGE_ID=$imageId" $imageId `
    bash -lc 'f=/work/ram-study/stage4b-pinned-confirmation/IMAGE_ID.txt; if test -f $f; then test $(cat $f) = $FROZEN_IMAGE_ID; else echo $FROZEN_IMAGE_ID > $f; fi'
if ($LASTEXITCODE -ne 0) { throw 'The Docker image ID changed after experiment initialization' }

function Invoke-Isolated([string]$Name, [string]$Command, [bool]$AllowTrialRejection=$false) {
    Write-Host "=== $Name : 8 GiB RAM, zero swap, memlock=3 GiB ==="
    docker run --rm `
        --name $Name `
        --memory='8g' --memory-swap='8g' `
        --ulimit 'memlock=3221225472:3221225472' `
        --mount $volume `
        --workdir /work/Polar.DB `
        --env "POLAR_STAGE4B_IMAGE_ID=$imageId" `
        $imageId `
        bash -lc "python3 '$study/verify_lock.py' && $Command"
    $result=$LASTEXITCODE
    if ($result -eq 2 -and $AllowTrialRejection) {
        Write-Warning "A planned trial did not qualify: $Name. The immutable result is retained; continuing."
        return
    }
    if ($result -ne 0) { throw "Infrastructure/verification error in $Name (exit=$result)" }
}

Invoke-Isolated 'polar-s4b-preflight' "python3 '$study/design.py'"
$scheduleLines=docker run --rm --mount $volume $imageId cat "$study/SCHEDULE.json"
if ($LASTEXITCODE -ne 0) { throw 'Unable to read the frozen schedule' }
$schedule=($scheduleLines -join "`n") | ConvertFrom-Json
if (@($schedule.attempts).Count -ne 48) { throw 'Unexpected frozen schedule size' }
if (@($Blocks | Sort-Object -Unique).Count -ne $Blocks.Count -or
    @($Blocks | Where-Object {$_ -lt 1 -or $_ -gt 8}).Count -ne 0) {
    throw 'Blocks must be distinct integers in the interval 1..8'
}

foreach ($engine in @('sqlite','polar-db')) {
    $check="dotnet '$dll' --prepared-plan=uniform-v4 --prepared-stage=verify --prepared-root='$prepared' --prepared-source-sha='$sourceSha' --benchmark-engine=$engine --rows=20000000"
    Invoke-Isolated "polar-s4b-preverify-$($engine.Replace('-',''))" $check
}

foreach ($block in $Blocks) {
    Write-Host "===== STAGE 4B FROZEN BLOCK $block / 8 ====="
    $cases=@($schedule.attempts | Where-Object {$_.block -eq $block} | Sort-Object position)
    if ($cases.Count -ne 6) { throw "Scheduled block $block does not contain six treatments" }
    foreach ($case in $cases) {
        $id=[string]$case.id
        if ($Resume) {
            docker run --rm --mount $volume $imageId bash -lc `
                "test -e '$study/results/$id.started' || test -e '$study/results/$id.json'"
            if ($LASTEXITCODE -eq 0) {
                Write-Host "PRESERVED EXISTING ATTEMPT: $id"
                continue
            }
        }
        Invoke-Isolated "polar-$id" "python3 -u '$study/worker.py' --id='$id'" $true
    }
}

foreach ($engine in @('sqlite','polar-db')) {
    $check="dotnet '$dll' --prepared-plan=uniform-v4 --prepared-stage=verify --prepared-root='$prepared' --prepared-source-sha='$sourceSha' --benchmark-engine=$engine --rows=20000000"
    Invoke-Isolated "polar-s4b-postverify-$($engine.Replace('-',''))" $check
}

# Preliminary analysis is allowed for partial block ranges, but finalization
# requires all 48 scheduled attempts and writes a new result file only once.
if (@($Blocks).Count -eq 8) {
    docker run --rm --mount $volume $imageId test -e "$study/STAGE4B_RESULTS.json"
    $summaryCommand=if ($LASTEXITCODE -eq 0) {
        "python3 '$study/analyze.py'"
    } else {
        "python3 '$study/analyze.py' --finalize"
    }
} else {
    $summaryCommand="python3 '$study/analyze.py'"
}
Invoke-Isolated 'polar-s4b-analysis' $summaryCommand
Write-Host 'STAGE 4B COMPLETE: inspect acceptance ledger and confidence interval before making scientific claims. Stage 4 unchanged.'

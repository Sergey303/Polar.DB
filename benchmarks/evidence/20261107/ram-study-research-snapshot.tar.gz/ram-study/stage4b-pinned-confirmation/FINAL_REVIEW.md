# Polar.DB Stage 4B — independent final acceptance and scientific interpretation

Date: 2026-11-07. **Disposition: PRIMARY_REPLICATED under the prospectively locked Stage 4B protocol.** This review was produced *after* the run; it adds no data, changes no acceptance rules, and does not edit the frozen protocol, code, or paper.

## Provenance and completeness

- Stage 4B protocol lock `0173a5e8fa63f9c117a36de52239875c46b7a33a1551f8f21f87bc3dd48a2b0c`: all 11 sealed files passed verification.
- Source `a11457ce502b416041ea7bde0b53d2dc047db491` with `uniform-v4` in-process `mmap`/`mlock`; prepared 20,000,000-row primary-int database source `0fd84e3da854aa9f536a75861e7838af41955bdc`. Key-stream SHA `44106a815bb975ddbf956a475c5b6463832ce2bdaa139b59da6c18ffa50daf57`. Source Git `main` clean; both SQLite (1 file) and Polar.DB (5 files) passed full prepared-file SHA256 verification after the study.
- All **48 planned attempts** have unique `.started`, `.log`, metadata `.json`, and immutable raw result JSON. All 48 returned exit 0, pass the preregistered cache treatment, locked-byte accounting and checksum conditions, no OOM, memory.max hit or CPU throttling. One fixed image: `sha256:aba1b164c421eaa9df5ae21509375c532027a4009cd16c6ce6b40c837f4d9a99`, 8 GiB no swap and 3 GiB memlock.
- Original Stage 4 stays **INCONCLUSIVE** (48 attempted, 40 qualified, only 4 complete primary pairs). Stage 4.1 was engineering smoke validation (12/12) and was NOT pooled in scientific estimates.
- Write-once final machine report `STAGE4B_RESULTS.json` SHA256 `b47cd3140bca5ea9a9cf9db0bc9ddbac219cb25c73278a047e90e1ef0e96bb82` independently recalculated from all 48 raw records.

## Primary preregistered outcome

Within each of eight randomized/reversed blocks, compare Polar.DB lookup with only `f2.bin` (offset file) cold against only `f1.bin` (persisted hash-file snapshot) cold; keep all *other primary* files pinned in RAM. The 10,000-query arithmetic mean per run is the endpoint.

- **8/8 complete qualifying pairs**, with **8/8 positive directions**. Required minimum was 6/8.
- Pairwise offsets/hashes latency ratios by block: **25.414, 26.105, 19.348, 24.721, 16.873, 29.512, 26.313, 23.314**.
- Geometric mean paired ratio **23.6216×**. Preregistered two-sided block-bootstrap 95% interval (10,000 resamples) **[20.8268, 26.3142]×**, entirely above 1.
- Mean within-block absolute difference **201.6717 µs per lookup**.
- Thus the **predeclared primary replication criterion is satisfied**. This is confirmation of *the specified fixed dataset, key sequence, storage layout, pinned-cache intervention, environment and workload*, not a universal engine benchmark or general IO theorem.

## Descriptive condition summary (mean 10,000-query lookup latency, µs)

| Condition | Qualified / attempted | Mean µs / lookup | Process batch read_bytes mean MB |
|---|---:|---:|---:|
| Polar.DB all five sealed files pinned (`none`) | 8/8 | 11.793 | 0.000 |
| Polar.DB evict hash file `f1.bin` | 8/8 | 9.017 | 0.002 |
| Polar.DB evict offset file `f2.bin` | 8/8 | 210.689 | 93.250 |
| Polar.DB evict row data `f0.bin` | 8/8 | 230.837 | 81.142 |
| SQLite all file pages pinned (`none`) | 8/8 | 19.167 | 0.001 |
| SQLite whole database file evicted (`data`) | 8/8 | 249.257 | 46.850 |

Secondary (preregistered as secondary): Polar.DB `payload/hashes` geometric mean **25.848×**, paired 95% bootstrap interval **[22.351, 29.373]**; SQLite cold/none **13.018×** [11.344, 14.971]. Secondary contrasts are descriptive/secondary, not corrected for multiplicity. Same fixed key stream in all trials (no across-seed generalization).

## Mechanistic interpretation

`UKeyIndex.TryGetIndexedValueAndOffsetByKey` uses in-memory `hkeys_arr` for key hash binary search, but `offsets.GetByIndex(pos)` and `sequence.GetByOffset(candidateOffset)` access file-backed structures. Controlled eviction of `f1.bin` thus adds almost no measured read I/O; evicting `f2.bin` causes approximately 93.25 MB process read_bytes over the batch and much longer query times, while `f0.bin` and `f1.bin` remain resident. Evicting `f0.bin` separately also causes a large slowdown. The new `mlock` fixture prevented the old premeasurement cache race in all 48 host runs, giving a complete balanced estimate.

## Subtleties and boundaries

- In **one** Polar.DB payload run `f0.state` (a 24-byte service metadata file) was 0% resident at both pre- and post-batch snapshots; **two** offset runs recorded its one page missing at post-batch. The preregistered *intervention* eligibility explicitly requires retention of `f0.bin`, `f1.bin`, `f2.bin` (and for `none` it requires every sealed file); these auxiliary metadata observations do **not** violate the primary eligibility rule, but they should be disclosed. Locked-byte accounting alone cannot guarantee path/inode identity if a service metadata file is replaced. This does not establish a defect in lookup or a changed data checksum.
- Filesystem page cache is Linux-kernel global even when processes have independent Docker memory cgroups; `mlock` is an artificial control over page residency that can change the system's working set. `ProcessIo.read_bytes` is process-wide, not precise block-device I/O broken down by file path. Differences in filesystem layout, in-process arrays, syscall overhead, and OS scheduling remain.
- The bootstrap confidence interval is conditional on **eight blocks on one host**, one dataset and one frozen key stream; repeated queries inside a block are not independent experimental replications.
- No universal RAM threshold or causal Polar.DB-vs-SQLite architectural superiority claim can be made from this experiment. The Stage 4B confirmation supersedes the earlier *unresolved evidence question* but **does not retroactively change** Stage 4's INCONCLUSIVE outcome.

## Next editorial phase

Prepare Stage 5 as a distinct, source-faithful manuscript revision and evidence ledger. A narrow paragraph/figure about the role of offset-file residency can be justified from Stage 4B **with the locked environment, selection rules, valid sample size, confidence interval, effect direction and limitations explicitly stated**. Avoid converting this into an advertisement that Polar.DB is '23.6 times slower' in general; the ratio is specifically *cold offsets versus cold persisted hash snapshot inside Polar.DB*. Do not change engine algorithms in that revision. All raw evidence and the original article remain unchanged by this review.

**Repeated Windows launch:** a subsequent `run-host.ps1` invocation without `-Resume` stops on `Refuse duplicate` for the very first run. This is the correct immutability guard, since all 48 experiments are already complete. Do not rerun, overwrite or delete any trial. To inspect results run `python3 /work/ram-study/stage4b-pinned-confirmation/analyze.py` (read-only) or inspect `STAGE4B_RESULTS.json`; it already exists and is finalized.

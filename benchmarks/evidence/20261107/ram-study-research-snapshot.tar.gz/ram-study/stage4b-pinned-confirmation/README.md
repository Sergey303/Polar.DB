# Stage 4B — new scientific confirmation using the repaired pinned cache

**Status before host launch:** independent experimental protocol and controls prepared. No Stage 4B measurements made. This experiment is *not* a continuation or reclassification of the original Stage 4: that 48-attempt experiment remains `INCONCLUSIVE`. Stage 4.1 engineering smoke tests (12/12) are background evidence only and are not counted as Stage 4B observations.

**Question:** Does forcibly evicting Polar.DB's offset file `f2.bin` cause a reproducible lookup slowdown relative to evicting its hash snapshot `f1.bin`, while keeping all other database files pinned in memory? Secondary controls: payload `f0.bin`, all-pinned and SQLite whole-file eviction. Exact frozen preregistration: `PROTOCOL.md` and `SCHEDULE.json`; exact scripts are hashed by `LOCK.json`/`LOCK_SHA256.txt`.

### Windows Docker Desktop execution

Use the original `polar-bench-data` named volume containing unchanged 20M databases, Git source SHA `a11457ce502b416041ea7bde0b53d2dc047db491` and v4 sidecars. Run from Windows PowerShell:

```powershell
docker run --rm `
  --mount type=volume,source=polar-bench-data,target=/work `
  mcr.microsoft.com/dotnet/sdk:10.0 `
  cat /work/ram-study/stage4b-pinned-confirmation/run-host.ps1 |
  Set-Content -Encoding UTF8 .\polar-stage4b.ps1
if ($LASTEXITCODE -ne 0) { throw 'Cannot obtain the frozen Stage 4B launcher' }
powershell -NoProfile -ExecutionPolicy Bypass -File .\polar-stage4b.ps1
```

**Default: exactly 8 blocks × 6 conditions = 48 predefined attempts**, fresh isolated 8-GiB/no-swap container for each, `--ulimit memlock=3221225472:3221225472`, in a new randomized/reversed schedule. The original 3.* and Stage 4 outputs will not be overwritten. A tool image is reused or built once; its exact Docker image ID is written **once** to `IMAGE_ID.txt` and then checked at every stage. No apt/software installation inside measured containers. Source, plan, DLL and data hashes are checked; source DB files are SHA-256 verified before and after all blocks. One container per attempt; never concurrent benchmark runs.

You can split the schedule if needed:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\polar-stage4b.ps1 -Blocks 1,2,3,4
powershell -NoProfile -ExecutionPolicy Bypass -File .\polar-stage4b.ps1 -Blocks 5,6,7,8 -Resume
```

If interrupted, repeat the launcher with `-Resume`: it **skips any attempt that was already started, including a failed one**, avoiding repeated attempts to obtain a favorable result. An attempt that starts but fails before producing JSON is reported as rejected (with its immutable `.started` and `.log` files), never re-run. Preflight mismatches (SHA, image, missing permissions or incorrect cgroup) block the series before a trial is started. Only the predeclared schedule may run; accepted and rejected observations all enter the denominator.

### Audit and statistical output

`results/s4b-*.started` records start events, `results/s4b-*.log` records stdout/stderr, `results/s4b-*.json` holds per-attempt validation, `raw/pk-int-lookup/s4b-*.json` holds precise raw lookup timings and mincore/I/O snapshots where produced. `python3 analyze.py` prints the accounting of valid/invalid sessions, paired geometric mean offsets/hashes ratio and 95% paired bootstrap CI (10k resamples); `analyze.py --finalize` creates immutable `STAGE4B_RESULTS.json` only when all 48 attempts are accounted for.

**Locked success criterion:** at least 6/8 qualifying paired blocks *and* 95% bootstrap CI lower bound of `offsets/hashes` strictly >1. Otherwise `INCONCLUSIVE`. No automatic remeasurement or post-hoc exclusion on I/O, magnitude, CPU throttling or ranking. Preserve prior Stage 4's inconclusive decision regardless of Stage 4B findings. A future manuscript decision belongs to a separate editorial stage.

**Safety:** no engine changes, database rebuilding, writes to existing source files, old result mutation, global cache drop, or parallel stress. `run-host.ps1` stops at integrity/resource errors. Verify lock and review the existing `PROTOCOL.md` before starting, then verify original dataset hashes after the series.

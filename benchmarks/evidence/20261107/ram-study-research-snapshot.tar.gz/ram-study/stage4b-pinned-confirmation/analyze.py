#!/usr/bin/env python3
"""Locked Stage-4b pinned all-attempts audit and paired block-bootstrap confirmation."""
import argparse, json, math, random, statistics
from collections import defaultdict
from pathlib import Path
from accept import PROTOCOL, inspect
from design import PATH, validate as validate_schedule
from verify_lock import verify as verify_lock

HERE=Path(__file__).resolve().parent
ROWS=HERE/'results'
SEED=20261108
B=10000


def percentile(values,p):
    s=sorted(values)
    if not s:return None
    at=p*(len(s)-1)
    lo=int(math.floor(at));hi=int(math.ceil(at))
    return s[lo]*(hi-at)+s[hi]*(at-lo) if lo!=hi else s[lo]


def paired_ci(pairs):
    logratios=[math.log(a/b) for a,b in pairs]
    estimate=math.exp(statistics.mean(logratios))
    rng=random.Random(SEED)
    distributions=[]
    for _ in range(B):
        sample=[logratios[rng.randrange(len(logratios))] for _ in logratios]
        distributions.append(math.exp(statistics.mean(sample)))
    return {'pairs':len(pairs),'geometricMeanRatio':estimate,
            'bootstrap95CI':[percentile(distributions,.025),percentile(distributions,.975)],
            'positivePairs':sum(x>0 for x in logratios),
            'absoluteDifferenceUsMean':statistics.mean(a-b for a,b in pairs),
            'rawPairRatios':[a/b for a,b in pairs],
            'rawPairDifferencesUs':[a-b for a,b in pairs]}


def analyze():
    verify_lock()
    schedule=json.loads(PATH.read_text());validate_schedule(schedule)
    entries=schedule['attempts'];records=[];found=[];missing=[]
    for slot in entries:
        path=ROWS/(slot['id']+'.json')
        if not path.exists():
            marker=ROWS/(slot['id']+'.started')
            if not marker.exists():
                missing.append(slot['id']);continue
            m=json.loads(marker.read_text())
            assert m['id']==slot['id']
            # An explicit abort before JSON write is a rejection, not a free retry.
            # The original marker/log files remain on disk.
            r={**slot,'study':PROTOCOL,'accepted':False,
               'rejectReasons':['attempt-started-no-result'],
               'imageId':m.get('imageId','missing-image-id'),
               'runnerSha':m.get('runnerSha','missing-sha')}
            records.append(r)
            continue
        marker=ROWS/(slot['id']+'.started')
        assert marker.exists(),f'Missing immutable start marker: {slot["id"]}'
        r=json.loads(path.read_text())
        for key in ('id','engine','condition','block','position'):
            assert r[key]==slot[key],f'{path}: unexpected {key}'
        assert r['study']==PROTOCOL
        assert r['imageId']==(HERE/'IMAGE_ID.txt').read_text().strip()
        assert r['runnerSha']=='a11457ce502b416041ea7bde0b53d2dc047db491'
        assert r['dataSha']=='0fd84e3da854aa9f536a75861e7838af41955bdc'
        assert r['keyStreamSha']=='44106a815bb975ddbf956a475c5b6463832ce2bdaa139b59da6c18ffa50daf57'
        assert r['dllSha256']=='6c726f9e8090130466cdc95e7be4f27c37d89a68ba0ca8759f580a6be8bf1911'
        if r['accepted']:
            assert not r['rejectReasons'] and r['exitCode']==0
            assert not r['memoryEventsDelta'].get('max',0) and not r['memoryEventsDelta'].get('oom_kill',0)
            data=json.loads(Path(r['rawJson']).read_text())
            check,obs=inspect(data,r['engine'],r['condition'])
            assert not check,f'{r["id"]}: unexpected cache state {check}'
            assert data['QueryRunnerSha']==r['runnerSha']
            assert data['SourceSha']==r['dataSha']
            assert data['PlanKeyStreamSha256']==r['keyStreamSha']
            assert data['CacheTreatment']==r['condition']
            assert data['Engine']==r['engine']
            assert data['RunId']==r['id']
            assert data['BatchRows']==10000 and data['LatencyRows']==2000
            assert data['ExpectedBatch']['Checksum']==data['BatchChecksum']
            assert data['ExpectedLatency']['Checksum']==data['LatencyChecksum']
            assert len(data['BatchAverageMs'])==100
            assert abs(statistics.mean(data['BatchAverageMs'])*1000-r['meanBatchLookupUs'])<1e-7
            assert obs==r['observations']
            r['observedMeanUs']=statistics.mean(data['BatchAverageMs'])*1000
            r['observedLatencyP95Us']=percentile(data['LatencySamplesMs'],.95)*1000
        records.append(r);found.append(path)
    extra=[str(p) for p in ROWS.glob('s4b-*.json') if p not in found]
    if extra:raise ValueError('Out-of-schedule result files: '+', '.join(extra))
    unknown_started=[str(p) for p in ROWS.glob('s4b-*.started')
                     if p.stem not in {row['id'] for row in entries}]
    if unknown_started:raise ValueError('Out-of-schedule start markers: '+', '.join(unknown_started))
    images={r['imageId'] for r in records}
    if len(images)>1:raise ValueError('Mixed Docker image IDs — cannot pool sessions: '+repr(images))
    pinned_image=HERE/'IMAGE_ID.txt'
    if records and (not pinned_image.exists() or images!={pinned_image.read_text().strip()}):
        raise ValueError('Run images mismatch frozen IMAGE_ID.txt')
    groups=defaultdict(list)
    for r in records:groups[(r['engine'],r['condition'])].append(r)
    stats={}
    print('STAGE4B',len(records),'/',len(entries),'attempts, accepted',sum(r['accepted'] for r in records),
          'rejected',sum(not r['accepted'] for r in records),'missing',len(missing))
    for name in schedule['conditions']:
        eng,cond=name.split(':')
        runs=groups[(eng,cond)];valid=[r for r in runs if r['accepted']]
        values=[r['observedMeanUs'] for r in valid]
        stats[name]={'attempted':len(runs),'accepted':len(valid),
            'rejected':[{'block':r['block'],'reason':r['rejectReasons']} for r in runs if not r['accepted']],
            'meanUs':statistics.mean(values) if values else None,
            'medianUs':statistics.median(values) if values else None,
            'rangeUs':[min(values),max(values)] if values else None,
            'readMBMean':statistics.mean(r['observations']['batchReadBytes']/1e6 for r in valid) if valid else None,
            'maxCpuThrottledCount':max((r.get('cpuDelta',{}).get('nr_throttled',0) for r in runs),default=0),
            'observedPreBatchResidency':[r['observations']['residencyPreBatch'] for r in valid]}
        s=stats[name]
        print(f'{name:20} accepted={s["accepted"]}/{s["attempted"]} '
              f'meanUs={None if s["meanUs"] is None else round(s["meanUs"],3)} '
              f'medianUs={None if s["medianUs"] is None else round(s["medianUs"],3)} '
              f'readMBmean={None if s["readMBMean"] is None else round(s["readMBMean"],3)}')
    def pairs(left,right):
        a={r['block']:r['observedMeanUs'] for r in groups[tuple(left.split(':'))] if r['accepted']}
        b={r['block']:r['observedMeanUs'] for r in groups[tuple(right.split(':'))] if r['accepted']}
        return [(a[k],b[k]) for k in sorted(a.keys()&b.keys())]
    primary=pairs('polar-db:offsets','polar-db:hashes')
    secondary=pairs('polar-db:payload','polar-db:hashes')
    comparisons={}
    for label,arr in [('primaryOffsetsVsHashes',primary),('secondaryPayloadVsHashes',secondary),
                      ('offsetsVsNone',pairs('polar-db:offsets','polar-db:none')),
                      ('sqliteDataVsNone',pairs('sqlite:data','sqlite:none'))]:
        comparisons[label]=paired_ci(arr) if arr else None
        print('PAIR',label,comparisons[label])
    conclusion='INCOMPLETE'
    if not missing:
        qualifies=len(primary)>=6
        significant=bool(primary and comparisons['primaryOffsetsVsHashes']['bootstrap95CI'][0]>1)
        conclusion='PRIMARY_REPLICATED' if qualifies and significant else 'INCONCLUSIVE'
    report={'study':PROTOCOL,'planned':len(entries),'attempted':len(records),
            'accepted':sum(r['accepted'] for r in records),'missing':missing,
            'imageIds':sorted(images),'perCondition':stats,'comparisons':comparisons,
            'primaryDecision':conclusion,
            'notes':'Same pinned uniform-v4 code/data/keys; prospective confirmation distinct from C1/C2/Stage4/Stage4.1. Process-level read_bytes; shared Docker host and page cache. No universal architecture ranking or RAM threshold.'}
    print('DECISION',conclusion,'(requires 6 valid pairs and primary bootstrap CI >1)')
    return report


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--finalize',action='store_true');args=ap.parse_args()
    r=analyze()
    if args.finalize:
        if r['missing']:raise SystemExit('Refuse to finalize incomplete confirmation')
        p=HERE/'STAGE4B_RESULTS.json'
        if p.exists():raise SystemExit('Refuse to overwrite final analysis')
        p.write_text(json.dumps(r,indent=2)+'\n')
        print('WROTE',p)

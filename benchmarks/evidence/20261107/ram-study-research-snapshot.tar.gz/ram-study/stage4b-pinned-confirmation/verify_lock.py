#!/usr/bin/env python3
"""Confirm study scripts, schedule and protocol are identical to frozen copies."""
import hashlib,json
from pathlib import Path
BASE=Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify():
    lockpath=BASE/'LOCK.json'
    seal=BASE/'LOCK_SHA256.txt'
    if not lockpath.is_file() or not seal.is_file():
        raise RuntimeError('Stage4 scripts have not been sealed')
    expected=seal.read_text().strip()
    if sha(lockpath)!=expected:
        raise RuntimeError('LOCK.json content hash mismatch')
    manifest=json.loads(lockpath.read_text())
    assert manifest['protocol']=='stage4b-pinned-confirmation-v1'
    for name,expected in manifest['sha256'].items():
        actual=sha(BASE/name)
        if actual!=expected:
            raise RuntimeError(f'Study file {name} changed: {actual} != {expected}')
    return manifest


if __name__=='__main__':
    r=verify()
    print('STAGE4 LOCK PASS',len(r['sha256']),'files; LOCK SHA256',sha(BASE/'LOCK.json'))

#!/usr/bin/env python3
"""Read-only regression/negative tests using Stage4.1 data as fixtures only.
These old observations NEVER enter Stage4B confirmation estimates.
"""
import copy, json, math
from pathlib import Path
from accept import PROTOCOL, inspect
from design import generate, validate
from analyze import paired_ci

FIXTURES=Path('/work/ram-study/stage4-1-pinned/raw/pk-int-lookup')


def fixture(engine, condition):
    return json.loads((FIXTURES/f'pinv4-20m-8g-{engine}-{condition}-r1.json').read_text())


def test():
    schedule=generate()
    assert validate(schedule)
    assert len(schedule['attempts'])==48
    assert all(row['id'].startswith('s4b-b') for row in schedule['attempts'])
    for pair in range(4):
        first=[r['engine']+':'+r['condition'] for r in schedule['attempts'] if r['block']==2*pair+1]
        reverse=[r['engine']+':'+r['condition'] for r in schedule['attempts'] if r['block']==2*pair+2]
        assert first==list(reversed(reverse))

    for engine,condition in (('sqlite','none'),('sqlite','data'),
                             ('polar-db','none'),('polar-db','hashes'),
                             ('polar-db','offsets'),('polar-db','payload')):
        raw=fixture(engine,condition)
        reasons,obs=inspect(raw,engine,condition)
        assert not reasons,(engine,condition,reasons)
        assert obs['pinnedBeforeBytes']>0
        assert obs['batchReadBytes']>=0

    # Wrong amount of pinned memory is never tolerated.
    raw=fixture('polar-db','offsets')
    raw['PinnedDuringBatchBytes']+=4096
    reasons,_=inspect(raw,'polar-db','offsets')
    assert 'batch-pin-bytes-mismatch' in reasons

    # Target must be evicted and unselected data must stay resident.
    raw=fixture('polar-db','offsets')
    next(p for p in raw['ResidencyBeforeBatch']['Files'] if p['Name']=='f2.bin')['Fraction']=.5
    reasons,_=inspect(raw,'polar-db','offsets')
    assert 'target-not-evicted:f2.bin' in reasons
    raw=fixture('polar-db','hashes')
    next(p for p in raw['ResidencyAfterBatch']['Files'] if p['Name']=='f0.bin')['Fraction']=.994
    reasons,_=inspect(raw,'polar-db','hashes')
    assert 'other-file-evicted-during-batch:f0.bin' in reasons
    raw=fixture('sqlite','none')
    raw['PinnedDuringBatchBytes']=0
    reasons,_=inspect(raw,'sqlite','none')
    assert 'batch-pin-bytes-mismatch' in reasons

    # No censoring by I/O magnitudes or extreme latency: measured outcomes.
    raw=fixture('polar-db','none')
    raw['Snapshots']['AfterBatch']['ProcessIo']['read_bytes']+=10_000_000
    raw['Snapshots']['AfterLatency']['ProcessIo']['read_bytes']+=10_000_000
    reasons,obs=inspect(raw,'polar-db','none')
    assert not reasons and obs['batchReadBytes']==10_000_000

    eight=[(150+i*10,7+i*.2) for i in range(8)]
    assert paired_ci(eight)==paired_ci(eight)
    assert paired_ci(eight)['bootstrap95CI'][0]>1
    print('PASS Stage4B: 48 frozen paired/reversed treatments, v4 pin/evict metadata, '
          'negative cases, I/O non-exclusion and deterministic paired-block bootstrap')


if __name__=='__main__':test()

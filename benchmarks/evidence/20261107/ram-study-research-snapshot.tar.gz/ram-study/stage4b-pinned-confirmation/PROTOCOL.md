# Stage 4B: independent pinned-page confirmation — frozen experimental protocol

Prepared on 2026-11-06 **before the first Stage 4B measurement**. This is a new experiment, not a continuation or reinterpretation of the inconclusive 48-attempt Stage 4. The earlier Stage 3.*, Stage 4 and Stage 4.1 results must not be pooled with Stage 4B, and Stage 4 remains formally INCONCLUSIVE.

## Frozen source and workload

- Published clean Git `main` **`a11457ce502b416041ea7bde0b53d2dc047db491`**, opt-in `uniform-v4`. Actual pinned `PkIntLookup.dll` SHA256 **`6c726f9e8090130466cdc95e7be4f27c37d89a68ba0ca8759f580a6be8bf1911`**. The underlying Polar.DB engine code has not been changed for this study.
- Original sealed 20,000,000-row primary-int databases source commit **`0fd84e3da854aa9f536a75861e7838af41955bdc`**. Each engine's data-file SHA256 validated before and after the entire series. No builds/loads/migrations or changes to DB bytes during query.
- New, source-SHA-sealed `uniform-v4` plans: SQLite sidecar SHA256 **`17398fdebebee637d6a70a7f252e8634bcb8185d60b222b17f7de8b46d33613c`**; Polar.DB **`c536dbf6c74791863809da84d3e30f664330ecf619903e9b8641f6c213dcd67b`**. Same fixed stream SHA256 **`44106a815bb975ddbf956a475c5b6463832ce2bdaa139b59da6c18ffa50daf57`**: 500 warmup, 10,000 measured batch, 2,000 disjoint latency keys, 400/400 50k-row bins covered. Same key stream for every engine/condition and every block; results do *not* generalize across key seeds or different dataset distributions.
- Same Windows Docker Desktop host as stages 3/4, Linux containers with `--memory=8g --memory-swap=8g --ulimit memlock=3221225472:3221225472`. Exactly one fresh container for each scheduled treatment, never parallelized. All runs use one write-once, recorded Docker **image ID**; build from the frozen Dockerfile if the cached local image is absent, do not install packages during measured containers. `IMAGE_ID.txt` is written before the first attempt and cannot silently change on resume.
- Unlike old stage 4, **no external file warming**. The published v4 query runner maps and `mlock`s every sealed file **before opening the engine**, keeps all unselected pages pinned through query and latency, and after checking their residency unlocks/unmaps ONLY the treatment target before applying targeted `posix_fadvise(DONTNEED)`. Pinning cost, treatment eviction, engine open/refresh and key warmup are outside timed query loops. `mincore` is recorded before treatment, immediately before batch and immediately after batch. Memory locking is a precondition, **not** an engine optimization.

## Design and hypotheses

Eight planned independent blocks, each containing six conditions in a new frozen randomized order paired with its reverse (4 schedule pairs). Total **48 attempts**, listed explicitly in immutable `SCHEDULE.json` with `random.Random(20261107)`; no replacement, no dropping blocks or adjusting order after seeing output.

The six conditions are `polar-db:none`, `polar-db:hashes` (evict `f1.bin`), `polar-db:offsets` (evict `f2.bin`), `polar-db:payload` (evict `f0.bin`), `sqlite:none`, `sqlite:data` (evict SQLite's integrated database file). Each condition is repeated once per block. SQLite is a **whole-system contextual control**, not physically equivalent to Polar.DB's split storage.

**Primary hypothesis:** the arithmetic-mean latency of 10,000 uniform lookups in Polar.DB is higher when only the offset file `f2.bin` is cold versus when only the persisted hash file `f1.bin` is cold, with all unselected file pages pinned and the same key stream. Confirm by **paired** log ratios `ln(offsets_mean_us / hashes_mean_us)` within blocks.

**Secondary hypothesis:** Polar.DB's cold payload `f0.bin` is slower than its cold hashes `f1.bin` (paired); characterize `none`, SQLite `none`/`data`, file refaults and process `read_bytes`. No main scientific claim about a universal architecture winner or an RAM threshold is permitted by this design.

## Preregistered eligibility and rejection accounting

A run qualifies only if:

1. Exact source/data/sidecar/DLL SHA values above; source working tree clean; correct schedule ID, Docker image ID, 8 GiB cgroup/no swap, `RLIMIT_MEMLOCK >= 3 GiB`; no timeout or disk-reserve failure; no increase in cgroup `memory.events.max`/OOM kill.
2. `PinnedCacheProtocol == mlock-v1`; `PinnedInitiallyBytes` equals the sum of the sealed file lengths; `PinnedDuringBatchBytes` equals that sum **minus exactly the selected file** (or the full sum for `none`). A locked file is never released during the query batch.
3. Prior to eviction every sealed file >=99.5% resident; for `none`, every file remains >=99.5% resident immediately before AND after the batch. For an eviction treatment, **the selected file is <=10% resident immediately before batch**; all *unselected* Polar.DB files `f0.bin/f1.bin/f2.bin` remain >=99.5% resident before AND after the batch. The selected file may become resident during the batch; that is the intended measured refill.
4. Exactly 10,000 batch and 2,000 independent latency queries with expected checksums, 100 group average samples, unaltered source data and query runner, valid raw results.

**Never exclude on the basis of time measurement magnitude, I/O amount, file refault count, latency outliers, CPU throttling, engine ranking or any desired effect size.** Record process/cgroup I/O, page refaults, CPU throttling and memory metrics as continuous outcomes, not filters. A failed `mlock`, failed eviction, or page-residency check is an *experimental precondition failure*, not a bug of the Polar.DB lookup algorithm. Every attempt gets a unique write-once `.started`, `.log`, `.json` and optional raw query file. An attempt that was started but whose controller died before writing JSON is explicitly counted as rejected (not replaced).

All **48 predefined attempts** are reported, including failures. `-Resume` skips every ID that has a `.started` marker, even if it was rejected/crashed; no automatic resampling. If the host/repository/image globally cannot meet protocol preconditions, stop before the series, correct the environment and do not pretend a partially executed series was complete.

## Locked statistical analysis

1. For each qualifying run, primary endpoint is the **arithmetic mean of 100 group-average batch latencies**, in µs/query, equalling total 10,000-query mean. The median of those groups is **not** a per-query p50. Report independent 2,000-key latency p95 only descriptively.
2. For each block with both qualifying `polar-db:offsets` and `polar-db:hashes` runs, compute paired ratio `offsets_us / hashes_us`. Report count and values of valid pairs, geometric mean ratio, paired arithmetic mean differences in µs, directions of all pairs, and the **two-sided 95% percentile bootstrap CI** on the geometric mean (10,000 independent resamplings of the *paired blocks*, with replacement; Python `random.Random(20261108)`, 2.5%/97.5% linear interpolation of sorted bootstrap estimates). Do not bootstrap 10,000 individual lookups as if they were independent experiment sessions.
3. Primary claim **CONFIRMED** only if (a) all 48 scheduled attempts are accounted for, (b) **at least 6 of 8** primary blocks contain qualifying pairs, and (c) the paired-bootstrap CI lower bound is **strictly greater than 1**. Otherwise decision is **INCONCLUSIVE**. No additional runs under the same preregistered plan to rescue a negative or incomplete result. Count all rejected cases by engine and treatment.
4. Report secondary payload/hashes and SQLite cold/none paired ratios and all accepted condition-level mean/median/range, I/O, cache states and cgroup resources as **secondary/descriptive**, without using them as substitutes for the primary gate. No multiplicity-corrected claims for exploratory comparisons.
5. A strong effect on this fixed dataset/key stream is not proof of general architecture superiority, SSD per-file physical byte attribution, other RAM budgets, production workloads, or reproducibility on different host hardware.

All study scripts, instructions, Dockerfile and schedule are hashed in `LOCK.json` with write-once digest `LOCK_SHA256.txt` **before any Stage 4B host trial**. `verify_lock.py` runs before every containerized action. A complete result is written once to `STAGE4B_RESULTS.json` after all attempts; the original Stage 4 paper and results remain immutable.

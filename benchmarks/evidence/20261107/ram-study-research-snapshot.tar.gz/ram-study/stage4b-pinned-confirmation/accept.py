#!/usr/bin/env python3
"""Predeclared Stage-4b pinned eligibility; NO exclusion by measured I/O magnitude."""
import json
from pathlib import Path

MIN_RESIDENT=.995
MAX_EVICTED=.10
PROTOCOL='stage4b-pinned-confirmation-v1'
SELECTED={'polar-db':{'none':None,'hashes':'f1.bin','offsets':'f2.bin','payload':'f0.bin'},
          'sqlite':{'none':None,'data':'data.sqlite'}}
PERSISTENT=['f0.bin','f1.bin','f2.bin']


def ratios(raw):
    before={p['Name']:p['Fraction'] for p in raw['ResidencyBeforeTreatment']['Files']}
    pre={p['Name']:p['Fraction'] for p in raw['ResidencyBeforeBatch']['Files']}
    post={p['Name']:p['Fraction'] for p in raw['ResidencyAfterBatch']['Files']}
    return before,pre,post


def inspect(raw,engine,treatment):
    """Return (reject reasons, cache + I/O observations). No time-based filtering."""
    assert treatment in SELECTED[engine]
    reasons=[]
    before,pre,post=ratios(raw)
    wanted=SELECTED[engine][treatment]
    if any(f<MIN_RESIDENT for f in before.values()):
        reasons.append('not-fully-resident-before-treatment')
    if wanted is None:
        for fname in before:
            if pre.get(fname,0)<MIN_RESIDENT:
                reasons.append('none-prebatch-eviction:'+fname)
            if post.get(fname,0)<MIN_RESIDENT:
                reasons.append('none-postbatch-eviction:'+fname)
    else:
        if pre.get(wanted,2)>MAX_EVICTED:
            reasons.append('target-not-evicted:'+wanted)
        for fname in (PERSISTENT if engine=='polar-db' else []):
            if fname==wanted:continue
            if pre.get(fname,0)<MIN_RESIDENT:
                reasons.append('other-file-evicted-before-batch:'+fname)
            if post.get(fname,0)<MIN_RESIDENT:
                reasons.append('other-file-evicted-during-batch:'+fname)
    # Explicitly validate lock accounting. The query runner unlocks ONLY the
    # selected target after fully pinning every sealed file.
    if raw.get('PinnedCacheProtocol')!='mlock-v1':
        reasons.append('wrong-pinned-cache-protocol')
    manifest=json.loads(Path(raw['PreparedManifest']).read_text())
    declared_files={f['Name']:f['Bytes'] for f in manifest['Files']}
    total=sum(declared_files.values())
    target_size=declared_files[wanted] if wanted is not None else 0
    if raw.get('PinnedInitiallyBytes')!=total:
        reasons.append('initial-pin-bytes-mismatch')
    if raw.get('PinnedDuringBatchBytes')!=total-target_size:
        reasons.append('batch-pin-bytes-mismatch')
    s=raw['Snapshots']
    start=s['AfterCacheTreatment']
    finish=s['AfterBatch']
    latency=s['AfterLatency']
    io=finish['ProcessIo'].get('read_bytes',0)-start['ProcessIo'].get('read_bytes',0)
    latio=latency['ProcessIo'].get('read_bytes',0)-finish['ProcessIo'].get('read_bytes',0)
    refault=finish['MemoryCgroup'].get('workingset_refault_file',0)-start['MemoryCgroup'].get('workingset_refault_file',0)
    if io<0 or latio<0:reasons.append('negative-io-counter-delta')
    return reasons,{'residencyBefore':before,'residencyPreBatch':pre,
                    'residencyPostBatch':post,'batchReadBytes':io,
                    'independentLatencyReadBytes':latio,'batchRefaults':refault,'pinnedBeforeBytes':raw.get('PinnedInitiallyBytes'),
                    'pinnedDuringBatchBytes':raw.get('PinnedDuringBatchBytes')}

#!/usr/bin/env python3
"""Stage 1: isolated engine build+lookup, limited RAM, immutable run IDs and diagnostics.

Run from a disposable Docker container, one engine per container. Never use an
RDC agent container at 2 or 3 GiB. Files are written on the shared /work volume.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

GIB = 1024**3
ROOT = Path('/work/Polar.DB')
CG = Path('/sys/fs/cgroup')
BASE = Path('/work/ram-study/stage1-3642ecb')
SHA = '3642ecb8d4b84bd75690411eef9815c24293797c'


def count_file(name):
    try:
        return int((CG/name).read_text().strip())
    except (OSError, ValueError):
        return -1


def stats():
    return {k: int(v) for k, v in (line.split() for line in (CG/'memory.stat').read_text().splitlines())}


def events():
    return {k: int(v) for k, v in (line.split() for line in (CG/'memory.events').read_text().splitlines())}


def proc_stats(pid):
    out = {}
    try:
        for line in Path(f'/proc/{pid}/status').read_text().splitlines():
            if line.startswith(('VmRSS:', 'VmHWM:', 'VmData:', 'VmPeak:')):
                key, value = line.split(':', 1)
                out[key] = int(value.strip().split()[0]) * 1024
        for line in Path(f'/proc/{pid}/io').read_text().splitlines():
            if line.startswith(('read_bytes:', 'write_bytes:', 'rchar:', 'wchar:')):
                key, value = line.split(':', 1)
                out[key] = int(value.strip())
    except (OSError, ValueError):
        pass
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gib', required=True, type=int, choices=(2, 3, 4))
    parser.add_argument('--engine', required=True, choices=('sqlite', 'polar-db'))
    parser.add_argument('--rows', type=int, default=5_000_000, choices=(50_000, 5_000_000))
    args = parser.parse_args()

    if count_file('memory.max') != args.gib * GIB or count_file('memory.swap.max') != 0:
        sys.exit('WRONG CGROUP RAM / SWAP: container isolation required')
    sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    if sha != SHA:
        sys.exit(f'WRONG SOURCE SHA: {sha} != {SHA}')
    if subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=ROOT, text=True).strip():
        sys.exit('TRACKED SOURCE NOT CLEAN')
    binary = ROOT/'benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'
    if not binary.is_file():
        sys.exit('MISSING RELEASE BINARY')

    out = BASE/f'{args.gib}g'
    out.mkdir(parents=True, exist_ok=True)
    runid = f's1-3642ecb-{args.gib}g-{args.engine}-{args.rows}'
    path = out/f'{runid}.json'
    if path.exists():
        obj = json.loads(path.read_text())
        if obj.get('exitCode') == 0:
            print('ALREADY COMPLETED', path, flush=True)
            return
        sys.exit(f'Prior run exists: {path}. Investigate before retrying.')

    disk_start = shutil.disk_usage(ROOT).free
    if disk_start < 22*GIB:
        sys.exit('DISK RESERVE: need at least 22 GiB available')
    cmd = ['dotnet', str(binary), f'--rows={args.rows}',
           f'--benchmark-engine={args.engine}', f'--benchmark-run-id={runid}']
    logpath = out/f'{runid}.log'
    start_s = stats()
    start_e = events()
    before = count_file('memory.current')
    peak = before
    max_anon = start_s.get('anon', 0)
    max_file = start_s.get('file', 0)
    max_rss = max_hwm = max_vmdata = 0
    last_io = {}
    reason = None
    start = time.monotonic()
    with logpath.open('w') as output:
        proc = subprocess.Popen(cmd, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        while proc.poll() is None:
            now = time.monotonic()
            mem = count_file('memory.current')
            snap = stats()
            peak = max(peak, mem)
            max_anon = max(max_anon, snap.get('anon', 0))
            max_file = max(max_file, snap.get('file', 0))
            p = proc_stats(proc.pid)
            max_rss = max(max_rss, p.get('VmRSS', 0))
            max_hwm = max(max_hwm, p.get('VmHWM', 0))
            max_vmdata = max(max_vmdata, p.get('VmData', 0))
            last_io = {**last_io, **{k:v for k,v in p.items() if k.endswith('bytes') or k in ('rchar','wchar')}}
            if now-start > 600:
                reason = 'timeout 600s'
            elif shutil.disk_usage(ROOT).free < 16*GIB or disk_start-shutil.disk_usage(ROOT).free > 5*GIB:
                reason = 'disk growth or reserve exceeded'
            elif args.gib == 4 and mem > int(3.25*GIB):
                reason = 'controller safety cutoff 3.25 GiB'
            if reason:
                try:
                    os.killpg(proc.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                break
            time.sleep(0.1)
        try:
            code = proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            code = proc.wait()
    end_s, end_e = stats(), events()
    peak = max(peak, count_file('memory.current'))
    raw = ROOT/'benchmarks/results/raw/pk-int-lookup'/runid/f'{args.engine}.worker.json'
    obj = {
        'sourceSha': sha, 'runId': runid, 'engine': args.engine, 'rows': args.rows,
        'limitGiB': args.gib, 'swapMaxBytes': count_file('memory.swap.max'),
        'dotnetRuntimes': subprocess.check_output(['dotnet','--list-runtimes'], text=True).strip(),
        'exitCode': code, 'failure': reason, 'seconds': round(time.monotonic()-start, 3),
        'memoryStartGiB': round(before/GIB, 4), 'cgroupPeakSampledGiB': round(peak/GIB, 4),
        'cgroupAnonMaxSampledGiB': round(max_anon/GIB, 4), 'cgroupFileMaxSampledGiB': round(max_file/GIB, 4),
        'processVmRSSMaxSampledGiB': round(max_rss/GIB, 4),
        'processVmHWMMaxSampledGiB': round(max_hwm/GIB, 4),
        'processVmDataMaxSampledGiB': round(max_vmdata/GIB, 4),
        'processLastIO': last_io,
        'memoryEventsDelta': {k: end_e.get(k,0)-v for k,v in start_e.items()},
        'memoryStatDelta': {k:end_s.get(k,0)-start_s.get(k,0) for k in ('pgmajfault','workingset_refault_file','pgscan','pgsteal')},
        'fileBytesDelta': end_s.get('file',0)-start_s.get('file',0),
        'anonBytesDelta': end_s.get('anon',0)-start_s.get('anon',0),
        'workerJson': str(raw) if raw.is_file() else None, 'log': str(logpath),
        'diskFreeAtStartGiB': round(disk_start/GIB,2), 'diskFreeAtEndGiB': round(shutil.disk_usage(ROOT).free/GIB,2),
    }
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False)+'\n')
    print('RESULT', json.dumps({k:obj[k] for k in ('runId','exitCode','failure','seconds','cgroupPeakSampledGiB','cgroupAnonMaxSampledGiB','cgroupFileMaxSampledGiB','processVmHWMMaxSampledGiB','memoryEventsDelta','memoryStatDelta','workerJson')},ensure_ascii=False),flush=True)
    if code != 0 or reason:
        sys.exit(1)

if __name__ == '__main__':
    main()

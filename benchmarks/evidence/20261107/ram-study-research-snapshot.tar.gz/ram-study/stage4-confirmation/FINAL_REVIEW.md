# Stage 4 final independent audit — 2026-11-06

## Formal disposition: INCONCLUSIVE

**All 48/48 predefined attempts were executed and recorded; 40 accepted, 8 rejected.** The preregistered primary confirmation threshold was **at least 6/8 complete qualifying paired blocks** comparing Polar.DB offsets (`f2.bin`) versus hashes (`f1.bin`), and a 95% two-sided paired bootstrap lower bound above 1. **Only 4/8 blocks qualified**, so the predeclared confirmation gate did not pass, even though all four valid ratios strongly exceeded 1.

This is a *completed* confirmation **experiment** with an *inconclusive confirmation decision*, not an incomplete data-collection job. No substitutions, extra attempts or post hoc loosening of exclusions.

## Provenance

- Protocol lock: `bb7b2a1355ff67450262d4a0960d02048e69603c92f16eb0e8a40e769d0f37e1`; the locked eleven study files all passed verification.
- Query code Git SHA `b32020fd2786942332fc8f0a2320ee5aee3cb113`, unmodified, `main` clean and in sync with origin.
- Prepared 20M-row dataset source SHA `0fd84e3da854aa9f536a75861e7838af41955bdc`, with 1 SQLite and 5 Polar.DB sealed file hashes successfully reverified after the entire series.
- Key stream SHA-256 `44106a815bb975ddbf956a475c5b6463832ce2bdaa139b59da6c18ffa50daf57` (500 warmup, 10,000 batch, 2,000 independent latency keys, disjoint and full-range).
- All 48 attempts used the same Docker image ID `sha256:aba1b164c421eaa9df5ae21509375c532027a4009cd16c6ce6b40c837f4d9a99`, 8 GiB per container, no swap, one attempt per scheduled condition, alternating orders. No CPU throttling or cgroup memory-limit hits recorded.
- Machine-readable frozen result: `STAGE4_RESULTS.json` SHA-256 `7e703fe01d7851f1f0e53813e4a82d5b001c823578b7d474aa9efdc17316a737`. All 40 qualifying raw observations independently revalidated for keys, checksums, cache-state bounds, cgroup events and I/O deltas. No C1/C2 data pooled.

## All qualifying results

| Condition | Accepted/planned | Arithmetic mean of run batch means (µs/lookup) | Average measured batch read_bytes |
|---|---:|---:|---:|
| Polar.DB all sealed files resident (`none`) | 6/8 | 10.214 | 0 MB |
| Polar.DB hash file `f1.bin` evicted | 6/8 | 9.556 | 0.008 MB |
| Polar.DB offset file `f2.bin` evicted | 5/8 | 181.929 | 93.323 MB |
| Polar.DB row payload `f0.bin` evicted | 7/8 | 226.040 | 81.149 MB |
| SQLite `data.sqlite` resident | 8/8 | 18.327 | 0 MB |
| SQLite entire `data.sqlite` evicted | 8/8 | 209.985 | 46.850 MB |

The condition-level means are **unpaired descriptive statistics** and should not be treated as primary causal effect sizes. The appropriate comparison is paired within the same block, and the primary analysis had four complete pairs.

## Paired outcomes

- Valid blocks: **3, 5, 7, 8**. Offsets / hashes mean-latency ratios: **15.978, 17.138, 25.675, 18.100**.
- Geometric mean primary ratio: **18.887x**; predeclared 10,000-replicate paired-block percentile-bootstrap 95% CI **[16.484, 23.207]**; four of four valid pair directions >1; paired mean difference **173.002 µs**.
- This bootstrap CI is conditional on **only four accepted blocks**, assumes those selected blocks are representative, and does not represent the missing/rejected attempt uncertainty. For context, an exact conditional sign test based on four positive signs gives one-sided p=0.0625 / two-sided p=0.125 under an ideal independent symmetric-null assumption. Neither may override the preregistered gate.
- Secondary payload / hashes valid pairs: **5**, geometric mean ratio **24.390x** with naive paired bootstrap CI **[20.045, 29.678]**. This is secondary exploratory evidence, not a substitute for the failed primary gate.
- SQLite cold file / resident valid pairs: **8**, geometric mean ratio **11.792x** with percentile-bootstrap CI **[9.998, 13.406]**, demonstrating that the experiment detects strong page-cache effects in SQLite too. Do not infer a universally comparable storage-index architecture from those ratios.

## Reasons for the eight failures

Every rejected attempt occurred with Polar.DB and exited `-6` (unhandled .NET exception) **before writing the timed query JSON**. Stack traces show `PreparedCacheTreatment.AssertApplied` raised `InvalidDataException: Fully resident control lost pages before batch`. This is an experimental precondition failure, NOT a demonstrated bug in Polar.DB lookup or an OOM. There were **no wrong result checksums** among qualifying runs. Counts by condition: Polar.DB `none`:2, `hashes`:2, `offsets`:3, `payload`:1; SQLite `none`:0, `data`:0. The disproportionate cache-state rejection is methodologically relevant and may create non-random missingness; bootstrap intervals over accepted pairs are optimistically narrow if interpreted as general evidence.

The C2 pilot in Stage 3.2 already provided repeatable mechanistic evidence: on this workload, the in-process sorted `hkeys_arr` can serve hash lookup without retrieving `f1.bin` pages, while `offsets.GetByIndex` reads `f2.bin` and row fetches read `f0.bin`. Stage 4 *supports the same mechanical interpretation* in qualified runs, but **does not meet the predetermined independent publication-confirmation standard**.

## Stage 5 editorial decision (recommended)

**Do not insert the new RAM/cache experiment as a confirmed scientific result in the main manuscript.** Keep the 3.* pilot and Stage 4 confirmation as separate supplementary/negative-evidence material; if referenced, explicitly label Stage 4 as inconclusive with 8/48 rejected attempts and no claimed universal RAM threshold, no cross-engine winner, and no device-level I/O attribution.

Next high-value work, only if this result is necessary to the scientific contribution, is a **new separate preregistered experiment** (not continuation or replacement of Stage 4) on a quieter/isolate host or with a more robust within-process cache preparation mechanism that reduces losses between initial mincore and intervention. It must lock the code, protocol, and exclusion rules ahead of time, record all attempted results and avoid non-random selection of a convenient subset. Another option is to proceed with Stage 5 editorial revision using only the manuscript's existing validated results. Optimizing `f2.bin` as RAM-resident offsets would be a distinct future engineering experiment and must not be mixed into these frozen evidence sets.

**Do not modify `main`, previous results, or manuscript during this audit.**

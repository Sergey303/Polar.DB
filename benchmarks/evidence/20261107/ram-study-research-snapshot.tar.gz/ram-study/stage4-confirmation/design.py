#!/usr/bin/env python3
"""Locked 8-block randomized-and-reversed confirmation schedule."""
import json, random
from pathlib import Path

SEED=20261106
CONDITIONS=('polar-db:none','polar-db:hashes','polar-db:offsets',
            'polar-db:payload','sqlite:none','sqlite:data')
BLOCKS=8
PATH=Path(__file__).with_name('SCHEDULE.json')


def generate():
    rng=random.Random(SEED)
    rows=[]
    for group in range(1,5):
        order=list(CONDITIONS)
        rng.shuffle(order)
        for rev in (False,True):
            block=2*(group-1)+int(rev)+1
            for seq,item in enumerate(reversed(order) if rev else order,1):
                engine,treatment=item.split(':')
                rows.append({'block':block,'position':seq,'engine':engine,
                             'condition':treatment,
                             'id':f's4-b{block:02d}-{engine}-{treatment}'})
    return {'study':'stage4-cache-confirmation-v1','scheduleSeed':SEED,
            'numberOfBlocks':BLOCKS,'conditions':list(CONDITIONS),'attempts':rows}


def validate(schedule):
    assert schedule['study']=='stage4-cache-confirmation-v1'
    assert schedule==generate()
    assert len(schedule['attempts'])==BLOCKS*len(CONDITIONS)
    assert len({row['id'] for row in schedule['attempts']})==48
    for block in range(1,BLOCKS+1):
        items=[row for row in schedule['attempts'] if row['block']==block]
        assert sorted(f"{r['engine']}:{r['condition']}" for r in items)==sorted(CONDITIONS)
        assert [row['position'] for row in items]==list(range(1,7))
    return True


if __name__=='__main__':
    import sys
    result=generate()
    if len(sys.argv)>1 and sys.argv[1]=='--write':
        if PATH.exists():raise SystemExit('REFUSE schedule overwrite')
        PATH.write_text(json.dumps(result,indent=2)+'\n')
    else:
        assert validate(json.loads(PATH.read_text()))
        print('PASS frozen schedule',len(result['attempts']),'attempts')
        for block in range(1,BLOCKS+1):
            print('block',block,':',', '.join(x['engine']+'/'+x['condition'] for x in result['attempts'] if x['block']==block))

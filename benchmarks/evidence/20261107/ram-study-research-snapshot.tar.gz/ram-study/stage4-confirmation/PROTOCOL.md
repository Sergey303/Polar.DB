# Polar.DB: Stage 4 independent confirmation — preregistered protocol

Date: 2026-11-06. **Confirmatory experiment; no publication result yet.**

## Frozen materials
- Source Git commit `b32020fd2786942332fc8f0a2320ee5aee3cb113` (current published `main`, unmodified).
- Prepared 20,000,000-row primary-int databases source `0fd84e3da854aa9f536a75861e7838af41955bdc` (SHA-256 sealed; independently verify before and after the full series).
- Exactly the same 500 warmup / 10,000 batch / 2,000 independent latency primary-key requests from `uniform-v32`; stream SHA-256 `44106a815bb975ddbf956a475c5b6463832ce2bdaa139b59da6c18ffa50daf57`.
- Release `PkIntLookup.dll` SHA-256 `7f410998b4735df901cc946fdd4a19ba206c36c8b527976b073300a8ec9e02f6`.
- Source and file manifests must match sealed SHA values. Run a separate 8-GiB/no-swap Docker container per treatment, after one-time building a fixed Docker image with git and Python. Save the resulting Docker image ID for every run. No package installation within measured containers.

## Experimental questions and conditions

**Primary hypothesis (one-sided direction, report two-sided 95% CI anyway):** for Polar.DB, cold `f2.bin` (offsets) raises mean batch lookup latency relative to cold `f1.bin` (hash snapshot), with the *other* files remaining >=99.5% resident at the start **and end** of the measured batch. Hypothesis: geometric mean of paired offsets/hashes latency ratios >1.

**Secondary:** Polar.DB cold `f0.bin` (record payload) raises latency versus cold `f1.bin`, with `f1.bin` and `f2.bin` resident. Additional context: Polar.DB `none` (all file pages near-resident), SQLite `none`, SQLite whole `data.sqlite` evicted. Cross-engine ranking is descriptive, not primary. These are system-level file-page-cache interventions, not randomized physical disk I/O by pathname.

**Six conditions per block:** `polar-db:none`, `polar-db:hashes`, `polar-db:offsets`, `polar-db:payload`, `sqlite:none`, `sqlite:data`. Eight independently launched blocks, **48 planned attempts**, no replacement of failed/rejected runs. The frozen schedule pairs randomized six-condition orders with their reverse (ABBA-style counterbalance) using Python `random.Random(20261106)`, recorded in `SCHEDULE.json`. No hindsight reordering.

Every execution uses a new process inside a fresh Docker container with 8 GiB memory and zero swap. Before running the immutable query code, prime each sealed file by read-only sequential passes until every file is >=99.5% resident (`mincore`, at most five complete passes). Run without dropping kernel caches globally. The immutable code opens the index, warms keys, measures per-file pre-treatment residency, applies specified file-scoped `POSIX_FADV_DONTNEED`, captures pre-batch and post-batch residency, times the batch and independent latency keys, and validates oracle checksum.

## Predetermined eligibility (NO I/O-based exclusions)

An attempt is **not qualifying** if: wrong source/data SHA, wrong runner/manifest/binary, code checksum mismatch, incorrect RAM or nonzero swap, missing result or crash, timeout, disk guard, increase in `memory.events.max`, OOM kill; loss of >=99.5% *unselected* file residency at either batch boundary; or selected-treatment pre-batch pages not evicted to <=10% resident. `none` requires **each** file >=99.5% resident immediately before AND after batch.

**Crucial:** Do **not** exclude an otherwise valid run solely because `ProcessIo.read_bytes` or refaults increased. These are measured continuous outcomes. In particular, C2's previously observed 700-KiB baseline read must not motivate condition-dependent replacement, post-hoc numeric cap or selective reporting. Record the exact I/O counts, cgroup PSI and CPU throttling for *all* attempts, including rejected ones when available.

Any previous C1/C2 results must remain separately labeled and must not be pooled into confirmation statistics. If a state fails to establish, log one failed attempt, DO NOT re-run the same block/condition to get a passing value. The next predeclared scheduled attempt may proceed. Disclose all rejection counts by engine and condition, including inability to establish baseline. Infrastructure failures may halt the series only to avoid corrupting data or exhausting resources, never to manipulate effect size.

## Endpoints and analysis (lock before first attempt)

1. For each valid run, use **arithmetic mean across its 100 batch-average samples** in µs per lookup (10,000 total queries). NOT median of group means as per-query p50.
2. For each block with both required valid conditions, compute `log(mean_latency_offsets / mean_latency_hashes)` for the primary pair. Report count of complete paired blocks, geometric-mean ratio, percentile **two-sided 95% bootstrap CI** with 10,000 resamples of blocks (fixed bootstrap seed 20261107), and the paired raw differences in µs. Report paired sign counts. Do not infer generality across alternative key seeds because a single frozen key stream is used.
3. Report secondary payload/hashes ratio similarly but explicitly mark it secondary; report full condition table (n, arithmetic mean/median/range, read_bytes MB, per-file `mincore` values). Show all failed attempts/reasons, not only valid rows; avoid interpreting precondition rejection as a database search failure.
4. Claim primary replication only when **at least six of eight** predetermined blocks yield complete qualifying primary pairs AND the bootstrap 95% CI lower limit exceeds 1. Otherwise report inconclusive, no further unplanned retries.
5. No universal RAM threshold, no controlled physical SSD read-by-file attribution, no random-key generalization, no claim about causal comparisons of the different on-disk layouts of SQLite and Polar.DB.

A locked `LOCK.json` records SHA-256 of this protocol and all scripts **before** host measurements. Use `verify_lock.py` before each run and check file hashes before and after. The main article remains untouched until Stage 5 reviews the completed evidence, any limitations and competing explanations.

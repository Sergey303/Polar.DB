# Stage 4 independent confirmation — ready to run

**Do not edit the paper or repo.** Stage 4 confirms Stage 3.2 mechanics, and only Stage 5 decides about publication.

Pinned: source `b32020fd2786942332fc8f0a2320ee5aee3cb113`, prepared 20M primary-int datasets source `0fd84e3da854aa9f536a75861e7838af41955bdc`; data already sealed and used in Stage 3.2. Eight randomized/reversed blocks, six conditions each, **48 predefined attempts** in independent 8-GiB/no-swap containers using one fixed image ID. No C1/C2 results are pooled. Main contrast is `polar-db:offsets` vs `polar-db:hashes`; other conditions contextualize it. Exact preregistration: `PROTOCOL.md`, `SCHEDULE.json`, and `LOCK.json`.

## Windows Docker Desktop launcher

In Windows PowerShell:

```powershell
docker run --rm --mount type=volume,source=polar-bench-data,target=/work `
  mcr.microsoft.com/dotnet/sdk:10.0 `
  cat /work/ram-study/stage4-confirmation/run-host.ps1 |
  Set-Content -Encoding UTF8 .\polar-stage4.ps1
if ($LASTEXITCODE -ne 0) { throw 'Cannot obtain Stage 4 script' }
powershell -NoProfile -ExecutionPolicy Bypass -File .\polar-stage4.ps1
```

The launcher builds a disposable **local Docker image once** with Python and Git. All benchmark containers use its exact immutable **image ID**, and install no software inside individual runs. It verifies study-file hashes and database SHA-256 before and after the series, then analyzes all 48 scheduled attempts.

If deliberately splitting the series across two sessions, use `-Blocks 1,2,3,4` and later `-Blocks 5,6,7,8 -Resume` (the launcher rebuilds from cache; all measured Docker image IDs must match). After interruption, `-Resume` skips any previously started attempt, including rejected or incomplete ones; it never reruns or overwrites a failure to improve the statistics. The analysis refuses to pool differing image IDs.

## Evidence and decisions

- `results/s4-*.started`: permanent audit record before a query is attempted.
- `results/s4-*.log`: worker stdout/stderr, including failed precondition stack traces.
- `results/s4-*.json`: worker metadata for every completed attempt, including cache fractions, read_bytes, outcome, JVM/.NET process memory, cgroup events and CPU throttling.
- `raw/pk-int-lookup/s4-*.json`: untouched query-only timing and checksums if the engine reached the measured stage.
- `analyze.py`: counts every attempt, performs deterministic block-paired bootstrap (10,000 resamples), rejects out-of-schedule files, prints condition-level effects and transparent exclusions. `--finalize` creates an immutable final JSON only when all 48 result records are present.
- `LOCK_SHA256.txt`: exact preregistered hash of `LOCK.json`, whose entries seal every study script, schedule and protocol. `verify_lock.py` runs before every experiment.

**Confirmatory gate:** At least six of eight paired blocks for `offsets/hashes` must qualify, with the 95% bootstrap CI lower bound above 1. No rescues or ad-hoc repeats. Failure to reach six valid blocks is INCONCLUSIVE. No effect on Polar.DB engine code, schema, article or earlier raw evidence.

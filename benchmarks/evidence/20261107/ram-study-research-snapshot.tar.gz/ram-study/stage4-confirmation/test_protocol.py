#!/usr/bin/env python3
"""Offline tests using previous C2 raw data only as acceptance fixtures."""
import copy,json,math
from pathlib import Path
from accept import inspect
from design import generate,validate
from analyze import paired_ci

STAGE32=Path('/work/ram-study/stage3-2/raw/pk-int-lookup')


def read(engine,treatment,block=1):
    return json.loads((STAGE32/f'v32c2-20m-8g-{engine}-{treatment}-r{block}.json').read_text())


def test():
    schedule=generate()
    assert validate(schedule)
    assert schedule['attempts'][0]['engine']=='polar-db'
    assert schedule['attempts'][0]['condition']=='hashes'
    for engine,condition in (('sqlite','none'),('sqlite','data'),
         ('polar-db','none'),('polar-db','hashes'),('polar-db','offsets'),('polar-db','payload')):
        raw=read(engine,condition)
        reasons,observations=inspect(raw,engine,condition)
        assert not reasons,(engine,condition,reasons)
        assert observations['batchReadBytes']>=0
    # Critically, do not exclude old failed C2 baseline merely for 700KiB I/O.
    raw=read('polar-db','none',2)
    reasons,obs=inspect(raw,'polar-db','none')
    assert obs['batchReadBytes']==716800
    assert not reasons,'Stage4 has no read_bytes-based rejection threshold'
    altered=copy.deepcopy(read('polar-db','offsets'))
    altered['ResidencyAfterBatch']['Files'][0]['Fraction']=.992
    rejected,_=inspect(altered,'polar-db','offsets')
    assert any('other-file-evicted-during-batch:f0.bin' in r for r in rejected)
    altered=copy.deepcopy(read('polar-db','hashes'))
    altered['ResidencyBeforeBatch']['Files'][2]['Fraction']=.22
    rejected,_=inspect(altered,'polar-db','hashes')
    assert any('target-not-evicted:f1.bin' in r for r in rejected)
    paired=[(150+i,8+i*.1) for i in range(8)]
    a=paired_ci(paired);b=paired_ci(paired)
    assert a==b and a['pairs']==8 and a['bootstrap95CI'][0]>1
    print('PASS 48 frozen scheduled attempts, C2 fixtures, read_bytes non-exclusion, cache-causality negative tests, deterministic bootstrap')

if __name__=='__main__':test()

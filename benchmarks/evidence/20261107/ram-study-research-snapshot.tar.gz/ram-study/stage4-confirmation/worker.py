#!/usr/bin/env python3
"""One locked Stage-4 intervention in an independent 8-GiB/no-swap container."""
import argparse, hashlib, json, os, shutil, signal, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path
from accept import PROTOCOL, SELECTED, inspect
from design import PATH as SCHEDULE, validate as validate_schedule
from verify_lock import verify as verify_lock
sys.path.insert(0,'/work/ram-study')
from stage3_cache import dataset_pages

DIR=Path(__file__).resolve().parent
ROOT=Path('/work/Polar.DB')
DATA=Path('/work/ram-study/stage3-0fd84e3/prepared-20000000')
SHA_SOURCE='b32020fd2786942332fc8f0a2320ee5aee3cb113'
SHA_DATA='0fd84e3da854aa9f536a75861e7838af41955bdc'
SHA_KEYS='44106a815bb975ddbf956a475c5b6463832ce2bdaa139b59da6c18ffa50daf57'
SHA_DLL='7f410998b4735df901cc946fdd4a19ba206c36c8b527976b073300a8ec9e02f6'
SHA_PLAN={'sqlite':'217ed5833a2d2765458973e07601f28e42d8ce65a0a52ce154c5c03ffecdda7d',
          'polar-db':'0d84d1f8c2466c12cee5206e9786e40b468c91f233ac58226171d27efc8df508'}
CG=Path('/sys/fs/cgroup');GIB=1024**3


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
    return h.hexdigest()


def count(path):
    try:return int((CG/path).read_text())
    except (OSError,ValueError):return -1


def counters(path):
    try:
        return {z[0].rstrip(':'):int(z[1]) for line in (CG/path).read_text().splitlines()
                if len(z:=line.split())==2 and z[1].lstrip('-').isdigit()}
    except OSError:return {}


def proc_hwm(pid):
    try:
        values=[int(line.split()[1])*1024 for line in
            Path(f'/proc/{pid}/status').read_text().splitlines() if line.startswith('VmHWM:')]
        return max(values,default=0)
    except OSError:return 0


def diff(a,b):return {key:b.get(key,0)-v for key,v in a.items()}


def run():
    ap=argparse.ArgumentParser()
    ap.add_argument('--id',required=True)
    a=ap.parse_args()
    verify_lock()
    schedule=json.loads(SCHEDULE.read_text());validate_schedule(schedule)
    entries=[x for x in schedule['attempts'] if x['id']==a.id]
    if len(entries)!=1:sys.exit('Refuse attempt not on frozen schedule')
    entry=entries[0];engine=entry['engine'];condition=entry['condition']
    assert condition in SELECTED[engine]
    if count('memory.max')!=8*GIB or count('memory.swap.max')!=0:
        sys.exit('Refuse wrong 8-GiB memory/no-swap container')
    sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    dirty=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True).strip()
    if sha!=SHA_SOURCE or dirty:sys.exit('Refuse wrong/dirty source SHA')
    dll=ROOT/'benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'
    if digest(dll)!=SHA_DLL:sys.exit('Refuse mismatched Release binary SHA-256')
    folder=DATA/'pk-int-lookup/rows-20000000'
    sealpath=folder/(engine+'.ready.json')
    planpath=folder/(engine+'.uniform-v32.json')
    if digest(planpath)!=SHA_PLAN[engine]:sys.exit('Refuse different v32 plan manifest')
    seal=json.loads(sealpath.read_text());plan=json.loads(planpath.read_text())
    if (seal['SourceSha']!=SHA_DATA or seal['Engine']!=engine or seal['Rows']!=20_000_000 or
        plan['DatasetSourceSha']!=SHA_DATA or plan['RunnerSourceSha']!=SHA_SOURCE or
        plan['KeyStreamSha256']!=SHA_KEYS or plan['ProtocolVersion']!=32):
        sys.exit('Refuse wrong prepared file or plan provenance')
    folder=folder/engine
    for f in seal['Files']:
        path=folder/f['Name']
        if not path.is_file() or path.stat().st_size!=f['Bytes']:
            sys.exit('Refuse wrong file size for '+f['Name'])
    if shutil.disk_usage(ROOT).free<20*GIB:sys.exit('Refuse disk reserve under 20 GiB')
    out=DIR/'results';out.mkdir(exist_ok=True)
    name=entry['id'];jsonpath=out/(name+'.json');logpath=out/(name+'.log')
    started=out/(name+'.started')
    if jsonpath.exists() or logpath.exists() or started.exists():
        sys.exit('Refuse duplicate, never replace a scheduled attempt: '+name)
    started.write_text(json.dumps({'id':name,'startedUtc':datetime.now(timezone.utc).isoformat(),
                                   'condition':condition,'runnerSha':SHA_SOURCE})+'\n')
    r={'study':PROTOCOL,'id':name,'block':entry['block'],'position':entry['position'],
       'engine':engine,'condition':condition,'runnerSha':SHA_SOURCE,'dataSha':SHA_DATA,
       'keyStreamSha':SHA_KEYS,'dllSha256':SHA_DLL,
       'imageId':os.getenv('POLAR_STAGE4_IMAGE_ID','not-reported'),
       'startedUtc':datetime.now(timezone.utc).isoformat(),
       'accepted':False,'rejectReasons':[]}
    why=r['rejectReasons'];raw=None
    # Every invalid precondition is recorded, not silently retried.
    try:
        start=dataset_pages(folder,seal['Files']);s=start;passes=0
        while min(f['fraction'] for f in s['files'].values())<.995 and passes<5:
            for f in seal['Files']:
                with (folder/f['Name']).open('rb',buffering=1048576) as source:
                    while source.read(1048576):pass
            passes+=1;s=dataset_pages(folder,seal['Files'])
        r['primePasses']=passes
        r['beforePrime']=start;r['afterPrime']=s
        with logpath.open('x') as log:
            if min(f['fraction'] for f in s['files'].values())<.995:
                why.append('precondition-prime-residency-failed')
                log.write('File residency below 99.5% after five warm passes\n')
            else:
                before_events=counters('memory.events');before_stat=counters('memory.stat')
                before_cpu=counters('cpu.stat');before_mem=count('memory.current')
                r['cpuStart']=before_cpu
                started_at=time.monotonic();peak=before_mem;hwm=0;failure=None
                initial_free=shutil.disk_usage(ROOT).free
                raw=DIR/'raw'/'pk-int-lookup'/(name+'.json')
                cmd=['dotnet',str(dll),'--prepared-stage=query','--prepared-plan=uniform-v32',
                    f'--prepared-root={DATA}',f'--prepared-results-root={DIR / "raw"}',
                    f'--prepared-source-sha={SHA_DATA}',f'--benchmark-engine={engine}',
                    f'--prepared-cache-treatment={condition}','--rows=20000000',
                    f'--benchmark-run-id={name}']
                p=subprocess.Popen(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                while p.poll() is None:
                    peak=max(peak,count('memory.current'));hwm=max(hwm,proc_hwm(p.pid))
                    if time.monotonic()-started_at>120:failure='120s timeout'
                    elif initial_free-shutil.disk_usage(ROOT).free>GIB:failure='>1GiB temporary disk growth'
                    elif shutil.disk_usage(ROOT).free<16*GIB:failure='disk free <16GiB'
                    if failure:
                        try:os.killpg(p.pid,signal.SIGTERM)
                        except ProcessLookupError:pass
                        break
                    time.sleep(.06)
                try:code=p.wait(timeout=4)
                except subprocess.TimeoutExpired:
                    os.killpg(p.pid,signal.SIGKILL);code=p.wait()
                r.update(exitCode=code,processFailure=failure,
                    elapsedSeconds=round(time.monotonic()-started_at,4),
                    memoryCurrentSampledPeakGiB=round(peak/GIB,4),
                    processHwmSampledMiB=round(hwm/1048576,3),
                    cpuDelta=diff(before_cpu,counters('cpu.stat')),
                    memoryEventsDelta=diff(before_events,counters('memory.events')),
                    memoryStatDelta=diff(before_stat,counters('memory.stat')))
                if failure or code:why.append(failure or f'query-exit:{code}')
                if r['memoryEventsDelta'].get('max',0):why.append('hit-memory.max')
                if r['memoryEventsDelta'].get('oom_kill',0):why.append('OOM-kill')
                if raw.exists():
                    d=json.loads(raw.read_text())
                    if (d['QueryRunnerSha']!=SHA_SOURCE or d['SourceSha']!=SHA_DATA or
                        d['PlanKeyStreamSha256']!=SHA_KEYS or d['CacheTreatment']!=condition or
                        d['Engine']!=engine or d['RunId']!=name):
                        why.append('query-provenance-mismatch')
                    if (d['BatchRows']!=10000 or d['LatencyRows']!=2000 or
                        d['ExpectedBatch']['Checksum']!=d['BatchChecksum'] or
                        d['ExpectedLatency']['Checksum']!=d['LatencyChecksum']):
                        why.append('incorrect-lookup-checksum-or-rowcount')
                    failures,obs=inspect(d,engine,condition)
                    why.extend(failures);r['observations']=obs
                    r['meanBatchLookupUs']=sum(d['BatchAverageMs'])*1000/len(d['BatchAverageMs'])
                    r['sampleCount']=len(d['BatchAverageMs'])
                    if r['sampleCount']!=100:why.append('wrong-batch-sample-count')
                    r['rawJson']=str(raw)
                else:why.append('missing-raw-query-json')
    except Exception as ex:
        why.append('controller-exception:'+type(ex).__name__+':'+str(ex)[:250])
    r['accepted']=not bool(why)
    r['finishedUtc']=datetime.now(timezone.utc).isoformat()
    with jsonpath.open('x') as out_file:
        json.dump(r,out_file,indent=2);out_file.write('\n')
    print('STAGE4 RESULT',json.dumps({k:r.get(k) for k in ('id','accepted','rejectReasons','meanBatchLookupUs',
        'memoryCurrentSampledPeakGiB','imageId')}),flush=True)
    return 0 if r['accepted'] else 2

if __name__=='__main__':sys.exit(run())

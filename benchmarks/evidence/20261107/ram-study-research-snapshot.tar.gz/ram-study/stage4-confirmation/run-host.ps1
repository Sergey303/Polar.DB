param(
  [int[]] $Blocks = @(1,2,3,4,5,6,7,8),
  [switch] $Resume
)
$ErrorActionPreference = 'Stop'
$volume = 'type=volume,source=polar-bench-data,target=/work'
$study='/work/ram-study/stage4-confirmation'
$source='/work/ram-study/stage3-0fd84e3/prepared-20000000'
$sha='0fd84e3da854aa9f536a75861e7838af41955bdc'
$dll='/work/Polar.DB/benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'

# Install Python/Git ONCE into a local fixed image. Never run apt during trials.
$buildDir=Join-Path $env:TEMP 'polar-stage4-image-v1'
New-Item -ItemType Directory -Path $buildDir -Force | Out-Null
$dockerfile = docker run --rm --mount $volume mcr.microsoft.com/dotnet/sdk:10.0 `
   cat "$study/Dockerfile"
if ($LASTEXITCODE -ne 0) { throw 'Cannot read frozen Stage4 Dockerfile' }
$dockerfile | Set-Content -Encoding ASCII (Join-Path $buildDir 'Dockerfile')
docker build -t polar-stage4-local:v1 $buildDir
if ($LASTEXITCODE -ne 0) { throw 'Cannot build local benchmark image' }
$imageId = (docker image inspect --format '{{.Id}}' polar-stage4-local:v1).Trim()
if ($LASTEXITCODE -ne 0 -or !$imageId.StartsWith('sha256:')) { throw 'Cannot determine image ID' }
Write-Host "FROZEN IMAGE ID $imageId"

function Invoke-Container([string]$Name,[string]$Command,[bool]$AcceptTrialRejection=$false) {
    Write-Host "=== $Name (8 GiB, zero swap) ==="
    docker run --rm `
       --name $Name `
       --memory='8g' --memory-swap='8g' `
       --mount $volume `
       --workdir /work/Polar.DB `
       --env "POLAR_STAGE4_IMAGE_ID=$imageId" `
       $imageId `
       bash -lc "python3 '$study/verify_lock.py' && $Command"
    $exit = $LASTEXITCODE
    if ($exit -eq 2 -and $AcceptTrialRejection) {
        Write-Warning "Trial $Name did not meet the locked conditions; retained as a rejected attempt. Continuing."
        return
    }
    if ($exit -ne 0) { throw "Infrastructure or verification failure in $Name; exit=$exit" }
}

Invoke-Container 'polar-s4-precheck' "python3 '$study/design.py'"
$lines=docker run --rm --mount $volume $imageId cat "$study/SCHEDULE.json"
if ($LASTEXITCODE -ne 0) { throw 'Cannot read frozen schedule' }
$schedule = ($lines -join "`n") | ConvertFrom-Json
if (@($schedule.attempts).Count -ne 48) { throw 'Unexpected schedule size' }
if (@($Blocks | Sort-Object -Unique).Count -ne $Blocks.Count -or @($Blocks | Where-Object {$_ -lt 1 -or $_ -gt 8}).Count -gt 0) {
    throw 'Blocks must be distinct integers from 1 to 8'
}

foreach ($engine in @('sqlite','polar-db')) {
    $verify="dotnet '$dll' --prepared-plan=uniform-v32 --prepared-stage=verify --prepared-root='$source' --prepared-source-sha='$sha' --benchmark-engine=$engine --rows=20000000"
    Invoke-Container "polar-s4-preverify-$($engine.Replace('-',''))" $verify
}

foreach ($block in $Blocks) {
    Write-Host "===== PRECOMMITTED BLOCK $block / 8 ====="
    $toRun=@($schedule.attempts | Where-Object {$_.block -eq $block} | Sort-Object position)
    if ($toRun.Count -ne 6) { throw "Missing scheduled condition in block $block" }
    foreach ($entry in $toRun) {
        $id=[string]$entry.id
        # A resume always SKIPS completed/started attempts, never re-runs them.
        $check="test -e '$study/results/$id.started' || test -e '$study/results/$id.json'"
        if ($Resume) {
            docker run --rm --mount $volume $imageId bash -lc $check
            if ($LASTEXITCODE -eq 0) { Write-Host "PRESERVED: $id"; continue }
        }
        Invoke-Container "polar-$id" "python3 '$study/worker.py' --id='$id'" $true
    }
}
foreach ($engine in @('sqlite','polar-db')) {
    $verify="dotnet '$dll' --prepared-plan=uniform-v32 --prepared-stage=verify --prepared-root='$source' --prepared-source-sha='$sha' --benchmark-engine=$engine --rows=20000000"
    Invoke-Container "polar-s4-postverify-$($engine.Replace('-',''))" $verify
}
Invoke-Container 'polar-s4-analyze' "python3 '$study/analyze.py'"
Write-Host 'Stage 4 series done. No manuscript or engine code was modified. Inspect the acceptance ledger before claiming confirmation.'

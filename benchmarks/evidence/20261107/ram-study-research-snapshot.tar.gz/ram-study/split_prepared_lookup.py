from pathlib import Path
root = Path('/work/Polar.DB/benchmarks/src/BenchSupport')
source = root / 'PreparedLookupRunner.cs'
lines = source.read_text().splitlines(keepends=True)
assert len(lines) == 381, len(lines)
assert lines[9].strip() == 'internal static class PreparedLookupRunner'
assert lines[109].strip().startswith('private static void Query(')
assert lines[222].strip().startswith('private static DatasetSeal ReadSeal(')
assert lines[294].strip().startswith('private sealed record MetricSnapshot(')
assert lines[-1].strip() == '}'

head = ''.join(lines[:109]).replace('internal static class PreparedLookupRunner',
    'internal static partial class PreparedLookupRunner') + '}\n'
query = ('using System.Diagnostics;\nusing Microsoft.Data.Sqlite;\n\nnamespace PolarDbBenchmarks;\n\n'
         'internal static partial class PreparedLookupRunner\n{\n' + ''.join(lines[109:222]) + '}\n')
seal = ('using System.Security.Cryptography;\nusing System.Text.Json;\n\nnamespace PolarDbBenchmarks;\n\n'
        'internal static partial class PreparedLookupRunner\n{\n' + ''.join(lines[222:294]) + '}\n')
infrastructure = ('using System.Diagnostics;\nusing System.Text.Json;\n\nnamespace PolarDbBenchmarks;\n\n'
                  'internal static partial class PreparedLookupRunner\n{\n' + ''.join(lines[294:-1]) + '}\n')
files = {
    'PreparedLookupRunner.cs': head,
    'PreparedLookupRunner.Query.cs': query,
    'PreparedLookupRunner.Seal.cs': seal,
    'PreparedLookupRunner.Infrastructure.cs': infrastructure,
}
for name, text in files.items():
    n = len(text.splitlines())
    assert n <= 150, (name,n)
    (root / name).write_text(text)
    print(name,n)

project = root / 'BenchSupport.csproj'
text = project.read_text()
old = '    <Compile Include="PreparedLookupRunner.cs" />\n'
assert text.count(old) == 1
new = old + ''.join('    <Compile Include="' + name + '" />\n' for name in (
    'PreparedLookupRunner.Query.cs', 'PreparedLookupRunner.Seal.cs',
    'PreparedLookupRunner.Infrastructure.cs'))
project.write_text(text.replace(old,new))

#!/usr/bin/env python3
"""Linux mincore residency probe + advisory eviction of sealed benchmark files.

No reads of data pages; mmap is private and never written. posix_fadvise
DONTNEED is advisory: assess the actual result, not merely the return code.
"""
import ctypes
import mmap
import os
from pathlib import Path

LIBC=ctypes.CDLL(None,use_errno=True)
LIBC.mincore.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p]
LIBC.mincore.restype=ctypes.c_int
PAGE=os.sysconf('SC_PAGESIZE')


def file_pages(path):
    fd=os.open(path,os.O_RDONLY)
    try:
        size=os.fstat(fd).st_size
        if not size:return {'bytes':0,'pages':0,'residentPages':0,'fraction':0.0}
        pages=(size+PAGE-1)//PAGE
        mapping=mmap.mmap(fd,size,flags=mmap.MAP_PRIVATE,
                          prot=mmap.PROT_READ|mmap.PROT_WRITE)
        try:
            addr=ctypes.addressof(ctypes.c_char.from_buffer(mapping))
            mask=(ctypes.c_ubyte*pages)()
            if LIBC.mincore(ctypes.c_void_p(addr),ctypes.c_size_t(size),mask)!=0:
                err=ctypes.get_errno()
                raise OSError(err,os.strerror(err),str(path))
            count=sum(v&1 for v in mask)
            return {'bytes':size,'pages':pages,'residentPages':count,
                    'fraction':round(count/pages,6)}
        finally: mapping.close()
    finally:os.close(fd)


def dataset_pages(directory,files):
    values={f['Name']:file_pages(Path(directory)/f['Name']) for f in files}
    total=sum(v['pages'] for v in values.values())
    resident=sum(v['residentPages'] for v in values.values())
    return {'files':values,'pages':total,'residentPages':resident,
            'fraction':round(resident/total,6) if total else 0.0}


def advise_drop(directory,files):
    for f in files:
        path=Path(directory)/f['Name']
        fd=os.open(path,os.O_RDONLY)
        try:
            if os.fstat(fd).st_size != f['Bytes']:
                raise ValueError('size mismatch: '+str(path))
            os.posix_fadvise(fd,0,0,os.POSIX_FADV_DONTNEED)
        finally:os.close(fd)


if __name__=='__main__':
    import tempfile
    with tempfile.TemporaryDirectory() as t:
        p=Path(t)/'test.bin'
        p.write_bytes(b'x'*2_000_000)
        files=[{'Name':p.name,'Bytes':p.stat().st_size}]
        a=dataset_pages(t,files)
        advise_drop(t,files)
        b=dataset_pages(t,files)
        print('MINCORE SELFTEST',a['fraction'],b['fraction'])
        assert a['fraction']>=b['fraction']

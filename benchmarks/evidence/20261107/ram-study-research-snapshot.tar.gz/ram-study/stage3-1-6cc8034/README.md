# Polar.DB RAM study — stage 3.1, uniform-independent query plan

## State (2026-11-06)

Code and tests published at `6cc803414f9c88e42e728faf5efbf5ba40cf26db`.
The source databases are exactly those prepared by `0fd84e3da854aa9f536a75861e7838af41955bdc` and verified by SHA256 before/after the diagnostic 4-GiB run.
The manuscript and legacy benchmark results are unchanged.

**Do not mix v2 and v3 results as though they use identical requests.**

## What is different from the previous benchmark?

- SplitMix64, fixed seed `0x6A09E667F3BCC909`, uniform keys over the whole row-ID domain without replacement. Python reference test verifies deterministic stream and SHA-256.
- 500 warmup, 10,000 batch, and 2,000 independent latency keys with no repeated keys across these groups. Latency set can still have cache-page overlaps with batch by coincidence; this is independent keys, not guaranteed cold pages.
- 20M sample covers all 400 bins of 50k logical rows, versus 20/400 in previous arithmetic-stride sample.
- The original primary-int benchmark, old key plan and sealed source data were NOT changed.
- v3 plan sidecar records both old prepared-dataset SHA and new code SHA, stable key-stream fingerprint, per-engine prepared-manifest fingerprint and expected checksums.
- Linux `mincore` resident-page fractions are sampled immediately before and after measured batch. The outer worker also uses `posix_fadvise(POSIX_FADV_DONTNEED)` on only sealed files, refusing to run if >5% remain resident before its initial *full file scan*.
- Phase-specific `read_bytes` and cgroup refaults accompany latency distribution. Cross-container cache interference, host memory and timing variance are still potential confounders.

## Diagnostic 4-GiB controller run (NOT a publication comparison)

One run per engine in the shared RDC 4-GiB cgroup; all query checksums and post-run SHA256 file hashes passed.

| Measure | SQLite | Polar.DB |
|---|---:|---:|
| 20M, batch mean µs/query | 48.562 | 86.292 |
| Batch median of 100-query averages, µs/query | 45.257 | 81.331 |
| Independent latency p95, µs | 179.8 | 233.9 |
| Residency before batch | 79.69% | 63.16% |
| Read_bytes in batch, MB | 9.007 | 33.436 |
| Read_bytes in independent latency, MB | 1.778 | 7.078 |
| OOM | no | no |

At this one point **SQLite was faster**, reversing the previous v2/4GiB structured-key result. This is a testable observation, not a proven new architecture/memory crossover. File layouts differ (SQLite ~2.054 GB, Polar.DB ~2.300 GB), resident fractions differ, and the RDC agent was active in the 4-GiB cgroup.

## Isolated host pilot — still required

From **Windows PowerShell on the Docker Desktop host**, obtain the already saved launcher from the volume and run it:

```powershell
docker run --rm --mount type=volume,source=polar-bench-data,target=/work `
  mcr.microsoft.com/dotnet/sdk:10.0 `
  cat /work/ram-study/stage3-1-6cc8034/run-host.ps1 |
  Set-Content -Encoding UTF8 .\polar-stage3-1.ps1
if ($LASTEXITCODE -ne 0) { throw 'Cannot extract Stage 3.1 host script' }
powershell -NoProfile -ExecutionPolicy Bypass -File .\polar-stage3-1.ps1
```

Runs r2/r3 at 2 and 4 GiB with alternate order, separate no-swap containers, and file hash verification before/after. The source DBs are never rebuilt. No global cache flush, Docker Desktop restart, or deletion of prior data is performed.

Check results in this directory:
- `stage3_1_worker.py` query/cgroup/cache instrumenter
- `run-host.ps1` safe isolated host launcher
- `summarize.py` raw-aware reporting
- `metrics/pilot-v3-*.json` cgroup and source metadata
- `query-results/pk-int-lookup/pilot-v3-*.json` phase samples and raw read bytes

## Decision gate for inclusion in article

Only consider a RAM paragraph or plot after the independent container series yields a reproducible effect with comparable pre-batch residency and sufficient repeats. Prefer explainable mechanisms, show both absolute and relative performance, include independent-key latency, query-stage I/O, and avoid interpreting early cache warmth or processor-cache effects as architecture without evidence. If the reversal is not reproducible, keep this as an exploratory study outside the manuscript.

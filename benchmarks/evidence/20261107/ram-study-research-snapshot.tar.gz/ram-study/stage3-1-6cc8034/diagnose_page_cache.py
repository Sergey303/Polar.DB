#!/usr/bin/env python3
"""Read-only diagnosis of per-file page-cache retention after full sequential scan.
Does not modify prepared databases, use FADV_DONTNEED, or alter the article.
"""
from pathlib import Path
import json
import os
import sys
import time
sys.path.insert(0,'/work/ram-study')
from stage3_cache import dataset_pages
BASE=Path('/work/ram-study/stage3-0fd84e3/prepared-20000000/pk-int-lookup/rows-20000000')
CG=Path('/sys/fs/cgroup')

def memory():
    d={k:int(v) for k,v in (line.split() for line in (CG/'memory.stat').read_text().splitlines())}
    return {'currentGiB':round(int((CG/'memory.current').read_text())/(1024**3),3),
            'fileGiB':round(d['file']/(1024**3),3),'anonGiB':round(d['anon']/(1024**3),3),
            'scan':d['pgscan'],'steal':d['pgsteal'],'refault':d['workingset_refault_file']}


def show(engine,seal,tag):
    d=dataset_pages(BASE/engine,seal['Files'])
    print(tag,engine,'fraction',d['fraction'],'mem',memory(),flush=True)
    for name,r in d['files'].items():
        print('FILE',name,'pages',r['pages'],'resident',r['residentPages'],'fraction',r['fraction'],flush=True)


def scan(engine,seal):
    start=time.monotonic()
    for entry in seal['Files']:
        p=BASE/engine/entry['Name']
        with p.open('rb',buffering=1024*1024) as f:
            while f.read(1024*1024):pass
    print('SCAN SECONDS',engine,round(time.monotonic()-start,3),flush=True)

if __name__=='__main__':
    for engine in ('polar-db','sqlite'):
        seal=json.loads((BASE/(engine+'.ready.json')).read_text())
        show(engine,seal,'before')
        scan(engine,seal)
        show(engine,seal,'after one full scan')
        scan(engine,seal)
        show(engine,seal,'after two full scans')

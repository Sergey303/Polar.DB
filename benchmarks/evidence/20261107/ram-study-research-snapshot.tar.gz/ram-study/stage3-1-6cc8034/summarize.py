#!/usr/bin/env python3
"""Report independent uniform-v3 results without mixing with legacy key plans."""
import json
import math
from pathlib import Path
import statistics

BASE=Path('/work/ram-study/stage3-1-6cc8034')
SOURCE='0fd84e3da854aa9f536a75861e7838af41955bdc'
RUNNER='6cc803414f9c88e42e728faf5efbf5ba40cf26db'


def pct(v,p):
    v=sorted(v)
    return v[min(len(v)-1,max(0,math.ceil(p*len(v))-1))]


def delta(d,first,last,kind='read_bytes'):
    s=d['Snapshots']
    return s[last]['ProcessIo'].get(kind,0)-s[first]['ProcessIo'].get(kind,0)


def main():
    records=[]
    for meta in sorted((BASE/'metrics').glob('pilot-v3-*.json')):
        a=json.loads(meta.read_text());p=a.get('queryJson')
        if not p or not Path(p).exists():
            print('INCOMPLETE',meta,a.get('failure'));continue
        d=json.loads(Path(p).read_text())
        assert d['PlanProtocol']=='uniform-independent-v3'
        assert d['SourceSha']==SOURCE and d['QueryRunnerSha']==RUNNER
        assert d['PlanCoverage']['UniqueKeys']==12500
        assert d['PlanCoverage']['BinsTouched']==400
        assert d['PlanKeyStreamSha256']=='44106a815bb975ddbf956a475c5b6463832ce2bdaa139b59da6c18ffa50daf57'
        assert d['BatchRows']==10000 and d['LatencyRows']==2000
        assert d['ExpectedBatch']['Checksum']==d['BatchChecksum']
        assert d['ExpectedLatency']['Checksum']==d['LatencyChecksum']
        b=d['BatchAverageMs'];l=d['LatencySamplesMs']
        r={'gib':a['limitGiB'],'rep':a['repeat'],'engine':a['engine'],
           'batch_mean_us':statistics.mean(b)*1000,
           'batch_median_us':statistics.median(b)*1000,
           'batch_p95_us':pct(b,.95)*1000,
           'lat_p50_us':statistics.median(l)*1000,
           'lat_p95_us':pct(l,.95)*1000,
           'lat_p99_us':pct(l,.99)*1000,
           'batch_IO_MB':delta(d,'AfterKeyWarmup','AfterBatch')/1e6,
           'latency_IO_MB':delta(d,'AfterBatch','AfterLatency')/1e6,
           'before_resident':d['ResidencyBeforeBatch']['Fraction'],
           'after_resident':d['ResidencyAfterBatch']['Fraction'],
           'hwm_mib':a['sampledProcessVmHWMMaxMiB'],
           'oom_kill':a['cgroupEventsDelta'].get('oom_kill')}
        records.append(r)
    print('READY',len(records),'query-only independent uniform-v3 runs')
    print('GiB,rep,engine,batch_mean_us,batch_med_us,batch_p95_us,lat_p50_us,lat_p95_us,lat_p99_us,batch_IO_MB,latency_IO_MB,preBatch_resident,postBatch_resident,HWM_MiB,OOM')
    for r in sorted(records,key=lambda a:(a['gib'],a['rep'],a['engine'])):
        print(','.join(str(round(r[k],4) if isinstance(r[k],float) else r[k]) for k in (
          'gib','rep','engine','batch_mean_us','batch_median_us','batch_p95_us',
          'lat_p50_us','lat_p95_us','lat_p99_us','batch_IO_MB','latency_IO_MB',
          'before_resident','after_resident','hwm_mib','oom_kill')))
    print('\nPair ratios: SQLite time / Polar.DB time (above 1 means Polar.DB faster).')
    for ram in sorted({a['gib'] for a in records}):
        for rep in sorted({a['rep'] for a in records}):
            v={a['engine']:a for a in records if a['gib']==ram and a['rep']==rep}
            if set(v)=={'sqlite','polar-db'}:
                s,p=v['sqlite'],v['polar-db']
                print('PAIR',ram,'GiB',rep,'batch_mean_ratio',round(s['batch_mean_us']/p['batch_mean_us'],3),
                      'median_ratio',round(s['batch_median_us']/p['batch_median_us'],3),
                      'independent_p95_ratio',round(s['lat_p95_us']/p['lat_p95_us'],3))
    print('WARNING: exploratory samples. File cache is kernel-global; do not claim causal architecture or infer a crossover without independent replication, controlled residency, and a coherent mechanism.')

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Stage 3: RAM-capped, single-engine, query-only exploratory worker.

Launch one invocation per disposable Docker container; do not run build/setup.
Never claim that 'hot' guarantees complete page-cache residency.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
sys.path.insert(0, "/work/ram-study")
from stage3_cache import dataset_pages, advise_drop

GIB = 1024**3
SHA = '6cc803414f9c88e42e728faf5efbf5ba40cf26db'
DATA_SHA = '0fd84e3da854aa9f536a75861e7838af41955bdc'
ROOT = Path('/work/Polar.DB')
STUDY = Path('/work/ram-study')
CG = Path('/sys/fs/cgroup')


def integer(name):
    try:
        return int((CG/name).read_text().strip())
    except (OSError, ValueError):
        return -1


def pairs(path):
    try:
        return {line.split()[0].rstrip(':'): int(line.split()[1]) for line in
                Path(path).read_text().splitlines() if len(line.split()) == 2 and line.split()[1].lstrip('-').isdigit()}
    except OSError:
        return {}


def get_rss(pid):
    try:
        return {k: int(v.strip().split()[0])*1024 for k,v in (line.split(':',1)
                for line in Path(f'/proc/{pid}/status').read_text().splitlines() if ':' in line)
                if k in ('VmHWM','VmRSS','VmData')}
    except (OSError, ValueError):
        return {}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--gib', type=int, choices=(2,3,4,8), required=True)
    ap.add_argument('--engine', choices=('sqlite','polar-db'), required=True)
    ap.add_argument('--rows', type=int, choices=(20_000_000,), default=20_000_000)
    ap.add_argument('--repeat', type=int, choices=(1,2,3), required=True)
    args = ap.parse_args()
    if integer('memory.max') != args.gib*GIB or integer('memory.swap.max') != 0:
        sys.exit('REFUSE: wrong cgroup memory or swap limit')
    sha = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    if sha != SHA or subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True).strip():
        sys.exit('REFUSE: source SHA mismatch or dirty tracked source')
    base = STUDY/'stage3-1-6cc8034'
    prepared = STUDY/'stage3-0fd84e3/prepared-20000000'
    manifest = prepared/'pk-int-lookup'/f'rows-{args.rows}'/(args.engine+'.ready.json')
    if not manifest.is_file():
        sys.exit('REFUSE: prepared database manifest missing: '+str(manifest))
    seal = json.loads(manifest.read_text())
    if seal.get('SourceSha') != DATA_SHA or seal.get('Rows') != args.rows or seal.get('Engine') != args.engine:
        sys.exit('REFUSE: wrong prepared DB version/engine/rows')
    plan_path = manifest.parent/(args.engine+'.uniform-v3.json')
    if not plan_path.is_file():sys.exit('REFUSE: v3 plan not prepared')
    plan = json.loads(plan_path.read_text())
    if plan.get('RunnerSourceSha') != SHA or plan.get('DatasetSourceSha') != DATA_SHA:
        sys.exit('REFUSE: v3 plan mismatched runner/data SHA')
    binary = ROOT/'benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'
    if not binary.is_file() or shutil.disk_usage(ROOT).free < 20*GIB:
        sys.exit('REFUSE: Release binary missing or disk below 20 GiB free')
    tag = f'pilot-v3-{args.rows}-{args.gib}g-{args.engine}-r{args.repeat}'
    out = base/'metrics'
    out.mkdir(parents=True,exist_ok=True)
    report = out/(tag+'.json')
    logfile = out/(tag+'.log')
    if report.exists() or logfile.exists():
        sys.exit('REFUSE: run already started or completed: '+tag)
    # Isolate the beginning of the file-scan warmup from other tests' page cache.
    # mincore checks whether advisory DONTNEED actually released clean pages.
    dataset_dir = manifest.parent/args.engine
    cache_before = dataset_pages(dataset_dir, seal['Files'])
    advise_drop(dataset_dir, seal['Files'])
    cache_after_advice = dataset_pages(dataset_dir, seal['Files'])
    print('CACHE', tag, 'before=',cache_before['fraction'],
          'after_advice=',cache_after_advice['fraction'],flush=True)
    if cache_after_advice['fraction'] > 0.05:
        sys.exit('REFUSE: advisory eviction left >5% of sealed file pages resident')
    raw_dir = base/'query-results'
    command = ['dotnet', str(binary),'--prepared-stage=query',
               '--prepared-plan=uniform-v3',f'--prepared-source-sha={DATA_SHA}',
               f'--prepared-root={prepared}',f'--prepared-results-root={raw_dir}',
               f'--benchmark-engine={args.engine}',f'--rows={args.rows}',
               '--prepared-phase=hot',f'--benchmark-run-id={tag}']
    start_events = pairs(CG/'memory.events')
    start_stat = pairs(CG/'memory.stat')
    start_io = (CG/'io.stat').read_text() if (CG/'io.stat').exists() else ''
    start_pressure = (CG/'memory.pressure').read_text() if (CG/'memory.pressure').exists() else ''
    free = shutil.disk_usage(ROOT).free
    started = time.monotonic()
    peak_mem = integer('memory.current')
    max_anon = start_stat.get('anon',-1)
    max_file = start_stat.get('file',-1)
    max_rss = max_hwm = 0
    reason = None
    with logfile.open('x') as log:
        process = subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        while process.poll() is None:
            current = integer('memory.current')
            stat = pairs(CG/'memory.stat')
            proc = get_rss(process.pid)
            peak_mem = max(peak_mem,current)
            max_anon = max(max_anon,stat.get('anon',-1))
            max_file = max(max_file,stat.get('file',-1))
            max_rss = max(max_rss,proc.get('VmRSS',0))
            max_hwm = max(max_hwm,proc.get('VmHWM',0))
            if time.monotonic()-started > 180: reason='timeout 180s'
            elif free-shutil.disk_usage(ROOT).free > GIB or shutil.disk_usage(ROOT).free < 16*GIB:
                reason='disk safety limit'
            if reason:
                try: os.killpg(process.pid,signal.SIGTERM)
                except ProcessLookupError: pass
                break
            time.sleep(.08)
        try: exit_code=process.wait(timeout=4)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL)
            exit_code=process.wait()
    final_stat=pairs(CG/'memory.stat')
    final_events=pairs(CG/'memory.events')
    cache_after_query = dataset_pages(dataset_dir,seal['Files'])
    qpath=raw_dir/'pk-int-lookup'/(tag+'.json')
    result = {
        'sha':SHA,'datasetSha':DATA_SHA,'planSha256':plan['KeyStreamSha256'],'engine':args.engine,'rows':args.rows,'limitGiB':args.gib,
        'repeat':args.repeat,'swapLimit':integer('memory.swap.max'),'tag':tag,
        'elapsedSeconds':round(time.monotonic()-started,4),'exitCode':exit_code,
        'failure':reason,'sampledMemoryCurrentPeakGiB':round(peak_mem/GIB,4),
        'sampledAnonMaxGiB':round(max_anon/GIB,4),'sampledFileMaxGiB':round(max_file/GIB,4),
        'sampledProcessVmRSSMaxMiB':round(max_rss/1048576,2),
        'sampledProcessVmHWMMaxMiB':round(max_hwm/1048576,2),
        'cgroupEventsDelta':{k:final_events.get(k,0)-v for k,v in start_events.items()},
        'cgroupStatDelta':{k:final_stat.get(k,0)-start_stat.get(k,0)
            for k in ('pgscan','pgsteal','workingset_refault_file','pgmajfault')},
        'ioStatStart':start_io,'ioStatEnd':(CG/'io.stat').read_text() if (CG/'io.stat').exists() else '',
        'memoryPressureStart':start_pressure,
        'memoryPressureEnd':(CG/'memory.pressure').read_text() if (CG/'memory.pressure').exists() else '',
        'queryJson':str(qpath) if qpath.is_file() else None,'log':str(logfile),
        'cacheBeforeAdvice':cache_before,'cacheAfterAdvice':cache_after_advice,
        'cacheAfterQuery':cache_after_query,
        'notice':'Uniform-v3 independently sampled keys, with no overlaps. Before query, targeted POSIX_FADV_DONTNEED attempted and mincore verified eviction. hot = explicit sequential file scan + deterministic key warmup. Page cache is global and can still change between probes. Container-lifetime cgroup metrics include installer and runtime.'
    }
    report.write_text(json.dumps(result,indent=2)+'\n')
    print('RESULT',json.dumps({k:result[k] for k in (
        'tag','exitCode','failure','elapsedSeconds','sampledMemoryCurrentPeakGiB',
        'sampledProcessVmHWMMaxMiB','cgroupEventsDelta','cgroupStatDelta','queryJson')}),flush=True)
    if exit_code or reason: sys.exit(1)

if __name__=='__main__':main()

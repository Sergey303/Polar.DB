#!/usr/bin/env python3
"""Audit FULL-RESIDENT v3 controls and compare to old partially resident runs.
No benchmarks executed. Only validated saved JSON results are included.
"""
import json
import math
from pathlib import Path
import statistics

BASE=Path('/work/ram-study/stage3-1-6cc8034')
EXPECTED_RUNNER='6cc803414f9c88e42e728faf5efbf5ba40cf26db'
EXPECTED_DATA='0fd84e3da854aa9f536a75861e7838af41955bdc'

def pct(a,q):
    a=sorted(a)
    return a[max(0,math.ceil(len(a)*q)-1)]

def main():
    rows=[]
    for path in sorted((BASE/'metrics').glob('resident-v3-*.json')):
        m=json.loads(path.read_text())
        raw=Path(m['queryJson']) if m['queryJson'] else None
        if raw is None or not raw.exists():
            print('INCOMPLETE',path.name);continue
        d=json.loads(raw.read_text())
        assert d['PlanProtocol']=='uniform-independent-v3'
        assert d['QueryRunnerSha']==EXPECTED_RUNNER and d['SourceSha']==EXPECTED_DATA
        assert d['PlanCoverage']['BinsTouched']==400
        assert d['ExpectedBatch']['Checksum']==d['BatchChecksum']
        assert d['ExpectedLatency']['Checksum']==d['LatencyChecksum']
        phases=d['Snapshots']
        read_bytes=phases['AfterBatch']['ProcessIo'].get('read_bytes',0)-phases['AfterKeyWarmup']['ProcessIo'].get('read_bytes',0)
        qualifiers=(d['ResidencyBeforeBatch']['Fraction']>=.995 and
                    d['ResidencyAfterBatch']['Fraction']>=.995 and
                    read_bytes==0 and m['cgroupEventsDelta'].get('max',0)==0 and
                    m['cgroupEventsDelta'].get('oom_kill',0)==0)
        if m.get('isQualifyingFullyResidentControl') is not None:
            assert qualifiers==m['isQualifyingFullyResidentControl']
        mean=statistics.mean(d['BatchAverageMs'])*1000
        lat95=pct(d['LatencySamplesMs'],.95)*1000
        rows.append((m['limitGiB'],m['repeat'],m['engine'],qualifiers,mean,lat95,
                     round(d['ResidencyBeforeBatch']['Fraction'],5),
                     round(d['ResidencyAfterBatch']['Fraction'],5),read_bytes,
                     m['cgroupEventsDelta'].get('max',0)))
    print('FULL RESIDENT CONTROLS',len(rows),'runs')
    print('GiB,rep,engine,QUALIFIES,batch_mean_us,independent_latency_p95_us,pre_residency,post_residency,batch_read_bytes,cgroup_max_events')
    for row in rows:
        print(','.join(map(str,[*row[:4],round(row[4],3),round(row[5],3),*row[6:]])))
    for ram in sorted({r[0] for r in rows}):
        for rep in sorted({r[1] for r in rows}):
            p={r[2]:r for r in rows if r[0]==ram and r[1]==rep and r[3]}
            if set(p)=={'sqlite','polar-db'}:
                s,t=p['sqlite'],p['polar-db']
                print('QUALIFIED_PAIR',ram,'GiB',rep,'SQLite/Polar mean ratio',round(s[4]/t[4],3),'SQLite/Polar p95 ratio',round(s[5]/t[5],3))
    print('CONTROL: 100% page residency is a measured state, not a property guaranteed by the nominal RAM limit. Comparisons to partly resident experiments only support system-level cache sensitivity, not a specific causal architecture mechanism.')

if __name__=='__main__':main()

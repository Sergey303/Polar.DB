# Stage 3.1 — cache residency control, 2026-11-06

## New finding

The initial 8-GiB `uniform-v3` pilot did **not** attain the ≥95% fully resident threshold for Polar.DB: `mincore` reported 56.0% and 56.2% immediately before measuring the batch. SQLite reported 95.0% and 84.4%. All 8-GiB results under that protocol describe **partially resident** workloads, not an in-memory control.

A check of `stat` allocated disk blocks vs logical file sizes ruled out material sparsity of the sealed files. A read-only page-cache diagnostic confirmed all sealed file pages of both databases **can** reside at the same time (`mincore=100%` for each). The RDC controller itself charged only ~0.16 GiB of file pages because file-cache charges may belong to other cgroups; cgroup `memory.current` is not a direct host-wide file-residency measurement.

A targeted `POSIX_FADV_DONTNEED` followed by read-only sequential warming reproduced the key flaw in the original control:

| Database | Immediately after targeted eviction | After one complete sequential scan | After two complete sequential scans |
|---|---:|---:|---:|
| Polar.DB | 0% | 88.56% | 100% |
| SQLite | 0% | 58.16% | 100% |

These are observations under current shared-host conditions, not guaranteed deterministic behavior of any Linux version. **One sequential scan is not proof of full residency.** Use repeated warming conditioned on measured `mincore` instead of relying on 8-GiB nominal RAM or a single read.

## Diagnostic fully resident 4-GiB run, shared RDC controller

With both databases individually mincore-verified at 100% before and after the measured 10k-key batch:

| Engine | Mean batch latency / key | Independent latency p95 | Measured batch read_bytes | memory.events.max increase |
|---|---:|---:|---:|---:|
| Polar.DB | 6.291 µs | 7.5 µs | 0 | 687 |
| SQLite | 13.069 µs | 16.5 µs | 0 | 45 |

The Polar.DB advantage is **2.08x** for the same uniform key stream and fully resident files, opposite to the mostly SQLite-faster partially resident v3 data. But both 4-GiB controller processes **hit the hard cgroup memory limit** (`memory.events.max` increased); these data are INVALID as an unpressured fully-resident baseline and should not enter the paper. Do not run more 4-GiB, full-resident experiments in the RDC controller.

## Decisive next experiment

Existing published runner SHA: `6cc803414f9c88e42e728faf5efbf5ba40cf26db`.
Prepared datasets SHA: `0fd84e3da854aa9f536a75861e7838af41955bdc`.

A new **outside-repository**, independently guarded worker `resident_control_worker.py` and PowerShell launcher `run-resident-8g.ps1` run at 8 GiB in independent containers **without file-cache eviction**. They repeat a full file scan until file residency is ≥99.5% before launching the unchanged published query runner; the query runner performs its standard warm scan, opens the DB, and measures mincore immediately before and after its batch. The controller accepts a run only if BOTH batch snapshots have ≥99.5% resident pages, batch `read_bytes==0`, `memory.events.max` did not increase, no OOM, and checksums match. Immutable DB hashes are verified before and after all runs. Alternate engine order across three runs. The article is unchanged.

The runner keeps metadata in `metrics/resident-v3-*.json`, raw timing in `query-results/pk-int-lookup/resident-v3-*.json` and produces summaries with `summarize_resident.py`. Reject any run with `isQualifyingFullyResidentControl=false`. The previous 4-GiB diagnostic run is correctly REJECTED by the validator due to hard-limit events despite 100% page residency.

If fully resident 8-GiB runs consistently show Polar.DB faster while partially resident same-RAM runs show SQLite faster, we have a **credible experimental crossover in cache state** for this precise workload. This would still not prove a universal cross-engine RAM threshold or a causal mechanism for the two distinct storage architectures; further confirmation and workload-specific analysis is required.

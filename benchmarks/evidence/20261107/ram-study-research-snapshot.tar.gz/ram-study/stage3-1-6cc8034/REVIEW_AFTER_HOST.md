# Stage 3.1 independent audit after r2/r3 host series — 2026-11-06

**Status:** completed exploratory 2/4 GiB pilot, not an accepted publication result. Published runner SHA `6cc803414f9c88e42e728faf5efbf5ba40cf26db`, sealed datasets SHA `0fd84e3da854aa9f536a75861e7838af41955bdc`. All 10 independent uniform-v3 query processes completed, no OOM; dataset hashes verified before and after. Original manuscript untouched.

## Mean timed batch latency (µs per query; 10,000 independent PK keys)

| RAM | Rep | Polar.DB | SQLite | SQLite/Polar |
|---|---:|---:|---:|---:|
| 2 GiB | 2 | 99.125 | 35.213 | 0.355 |
| 2 GiB | 3 | 110.109 | 44.024 | 0.400 |
| 4 GiB | 1 (RDC agent cgroup) | 86.292 | 48.562 | 0.563 |
| 4 GiB | 2 | 100.278 | 61.114 | 0.609 |
| 4 GiB | 3 | 65.984 | 68.291 | 1.035 |

Measured batch consists of 100 groups of 100 queries. Mean across group averages is overall 10,000-query mean; median of the 100 means is **not** an estimate of per-query p50. The independent 2,000-query latency p95 is 258.5/280.4 µs Polar.DB vs 188.6/166.9 µs SQLite for 2GiB r2/r3. At 4GiB p95 is 233.9/250.6/308.6 vs 179.8/226.9/244.3 µs. The latency keys do NOT overlap batch keys, though they can share disk pages.

## Cache and I/O evidence

| RAM | Rep | Engine | Pre-batch residency | Batch read_bytes | Batch refault_file |
|---|---:|---|---:|---:|---:|
| 2 | 2 | Polar.DB | 53.52% | 42.22 MB | 10307 |
| 2 | 2 | SQLite | 88.74% | 4.87 MB | 1188 |
| 2 | 3 | Polar.DB | 56.93% | 39.29 MB | 9463 |
| 2 | 3 | SQLite | 85.12% | 6.50 MB | 1561 |
| 4 | 1 | Polar.DB | 63.16% | 33.44 MB | 8163 |
| 4 | 1 | SQLite | 79.69% | 9.01 MB | 2199 |
| 4 | 2 | Polar.DB | 56.07% | 39.94 MB | 9752 |
| 4 | 2 | SQLite | 78.21% | 9.74 MB | 2330 |
| 4 | 3 | Polar.DB | 68.12% | 28.99 MB | 7077 |
| 4 | 3 | SQLite | 76.80% | 10.46 MB | 2554 |

The targeted fadvise+mincore protocol achieved 0% sealed-file residency **before** the explicit complete file scan in every test. Every scan read the full file from the storage stack (`read_bytes` ~2.054 GB SQLite, ~2.300 GB Polar.DB). The scan did NOT result in 100% resident pages before batch; that fraction varied strongly by run/engine. Resident fractions are whole-database pages, not the same logical subset or the same index/data pages. This is a major confound for algorithm-only attribution.

Across the 5 samples per engine, Pearson correlation of pre-batch resident fraction vs mean batch latency was about -0.936 SQLite, -0.896 Polar.DB (exploratory correlations only, not independent causal evidence).

## Key limitations and rejection risks

1. **An explicit cgroup RAM ceiling is not evidence that the ceiling was binding.** The 2 GiB workers peaked at 1.46–1.81 GiB sampled cgroup usage, the isolated 4 GiB workers at ~1.50–1.75 GiB. All `memory.events:max=0` and OOM=0. No evidence that the 2/4 GiB thresholds were directly hit; global Docker/WSL page-cache competition or file charges shared with other cgroups may drive resident fractions. The 4-GiB `r1` workers ran inside the RDC agent cgroup and must be kept separate from isolated host r2/r3 for inferential calculations.
2. **Nonmonotone SQLite effect:** the 2 GiB runs were *faster* (35–44 µs) than 4 GiB (49–68 µs), with higher file page residency at 2 GiB (85–89% vs 77–80%). This invalidates a simple claim that reducing configured RAM slowed SQLite; it suggests observed cache state matters more than nominal memory limits in these runs.
3. Source physical sizes differ: SQLite 2,053,685,248 bytes vs Polar.DB 2,300,000,084 bytes, and query process RSS differed (~78 vs ~231 MiB); these are legitimate **system-level** resource footprints but do not by themselves prove how much RAM a particular index design trades for lower CPU cost.
4. Strong SQLite advantage appears reproducible under 2-GiB, partially resident, uniformly distributed key workloads. At 4 GiB the winner is not robust across repeats; there is NO established architecture crossover or reproducible relative RAM-sensitivity knee.
5. Comparisons to old structured-key results are hypothesis-generating; old v2 key-set distribution is not equivalent. The major change in results is consistent with locality sensitivity but cannot alone isolate page cache, CPU caches, record layouts, hash/equality implementation or query path.

## Most economical decisive next control

Run the **identical v3 uniform keys** at 8 GiB in isolated, otherwise identical containers, explicitly requiring `ResidencyBeforeBatch >= 0.95` for **both engines** as a qualification for a 'fully resident' control, while recording per-stage I/O and independent latency. A tested script is `run-8g-control.ps1` (default two repeats, alternating engine order). If the criterion fails, diagnose host-wide file cache pressure/configuration instead of claiming RAM is sufficient. If it succeeds, compare hot/resident 8GiB to partially resident 2GiB as a *system-level* memory/performance tradeoff, not as proof of a specific internal cause. Then, and only if the difference is compelling, expand to confirmation-quality randomized repeats with balanced order/host pressure.

Reference files: `query-results/pk-int-lookup/pilot-v3-*.json`, `metrics/pilot-v3-*.json`, `summarize.py`, `run-8g-control.ps1`. Main and paper unchanged.

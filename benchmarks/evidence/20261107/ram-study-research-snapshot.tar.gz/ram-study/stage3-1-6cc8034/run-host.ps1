param([int[]] $Repeats = @(2, 3))
$ErrorActionPreference = 'Stop'

# Tested benchmark data are immutable: 20M prepared by source 0fd84e3.
# Query runner is published source 6cc8034. Never rebuild databases here.
function Run-Isolated([string]$Name, [int]$Ram, [string]$Cmd) {
    Write-Host "=== $Name : $Ram GiB (no swap) ==="
    docker run --rm `
      --name $Name `
      --memory="${Ram}g" `
      --memory-swap="${Ram}g" `
      --mount type=volume,source=polar-bench-data,target=/work `
      --workdir /work/Polar.DB `
      mcr.microsoft.com/dotnet/sdk:10.0 `
      bash -lc "apt-get update -qq && apt-get install -y -qq python3 git > /dev/null && $Cmd"
    if ($LASTEXITCODE -ne 0) {
        throw "Experiment failed: $Name exit=$LASTEXITCODE. Inspect /work/ram-study/stage3-1-6cc8034/metrics/"
    }
}

$root='/work/ram-study/stage3-0fd84e3/prepared-20000000'
$src='0fd84e3da854aa9f536a75861e7838af41955bdc'
$exe='/work/Polar.DB/benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'

# Hash all prepared files before any measurement. The worker subsequently
# attempts file-specific eviction and checks mincore == ~0% before file scan.
foreach ($engine in @('sqlite', 'polar-db')) {
    $command="dotnet '$exe' --prepared-plan=uniform-v3 --prepared-stage=verify --prepared-root='$root' --prepared-source-sha='$src' --benchmark-engine='$engine' --rows=20000000"
    Run-Isolated "polar-s31-preverify-$($engine.Replace('-',''))" 8 $command
}

# Counterbalance configuration order (2G, 4G, 4G, 2G) and engine order.
foreach ($rep in $Repeats) {
    $limits=if ($rep % 2 -eq 0) { @(2,4) } else { @(4,2) }
    foreach ($ram in $limits) {
        $engines=if (($ram+$rep) % 2 -eq 0) { @('sqlite','polar-db') } else { @('polar-db','sqlite') }
        foreach ($engine in $engines) {
            $tag="polar-s31-${ram}g-$($engine.Replace('-',''))-r$rep"
            $cmd="python3 -u /work/ram-study/stage3-1-6cc8034/stage3_1_worker.py --gib $ram --engine $engine --rows 20000000 --repeat $rep"
            Run-Isolated $tag $ram $cmd
        }
    }
}

foreach ($engine in @('sqlite', 'polar-db')) {
    $command="dotnet '$exe' --prepared-plan=uniform-v3 --prepared-stage=verify --prepared-root='$root' --prepared-source-sha='$src' --benchmark-engine='$engine' --rows=20000000"
    Run-Isolated "polar-s31-postverify-$($engine.Replace('-',''))" 8 $command
}
Run-Isolated 'polar-s31-summary' 8 'python3 /work/ram-study/stage3-1-6cc8034/summarize.py'
Write-Host 'Stage 3.1 host pilots completed. Main manuscript unchanged.'

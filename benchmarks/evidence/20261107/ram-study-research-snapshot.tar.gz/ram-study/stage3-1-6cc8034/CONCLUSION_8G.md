# Stage 3.1 conclusion — fully resident vs partially resident, 20M rows

Source DB SHA: `0fd84e3da854aa9f536a75861e7838af41955bdc`. Uniform-v3 query runner SHA: `6cc803414f9c88e42e728faf5efbf5ba40cf26db`. Same 12,500 unique pseudorandom keys in all runs (500 warmup / 10,000 batch / 2,000 disjoint latency). Original article unchanged.

## Successfully qualified 8-GiB fully resident controls

Three independent no-swap container process runs per engine. Every one passed: >=99.5% resident sealed files immediately before/after batch (actual 100%), zero additional process read_bytes during batch, no increase in cgroup memory.events:max, no OOM, correct batch/latency checksums. SHA-256 verification of source DB files passed before and after host series.

| Repeat | Polar.DB batch mean, µs/lookup | SQLite batch mean, µs/lookup | SQLite / Polar ratio | Polar p95 independent latency | SQLite p95 |
|---|---:|---:|---:|---:|---:|
| 1 | 8.005 | 12.609 | 1.575 | 9.4 µs | 17.3 µs |
| 2 | 6.741 | 11.470 | 1.701 | 6.8 µs | 15.9 µs |
| 3 | 6.629 | 16.111 | 2.431 | 8.3 µs | 19.1 µs |

The *mean of the three run means* is approximately 7.125 µs/query Polar.DB vs 13.397 µs/query SQLite. Polar.DB was faster in all three runs. This is a workload-specific empirical observation, not a confidence interval or proof of a universal advantage.

## Same RAM cap, partially resident observations

The earlier protocol at the **same nominal 8 GiB** used targeted fadvise eviction followed by ONE complete sequential file scan, and had incomplete file residency before the measured batch.

| Repeat | Polar.DB batch mean, µs/lookup | SQLite batch mean, µs/lookup | Polar resident | SQLite resident | Polar batch read_bytes | SQLite batch read_bytes |
|---|---:|---:|---:|---:|---:|---:|
| 1 | 109.366 | 21.553 | 56.0% | 95.0% | 40.08 MB | 2.20 MB |
| 2 | 93.930 | 42.323 | 56.2% | 84.4% | 39.83 MB | 6.88 MB |

SQLite was faster in both partial-residency runs, whereas Polar.DB was faster in all three fully resident runs. Relative advantage reversed **across cache states at a fixed 8-GiB container limit**. This satisfies a *preliminary system-level locality/cache-state crossover observation*, not a RAM-limit crossover.

Naive run-mean aggregation across the two partial and three full controls: Polar.DB ~101.648 / 7.125 = **14.3x** slower with incomplete residency; SQLite ~31.938 / 13.397 = **2.38x** slower. These ratios are descriptive only: the two cache regimes differ in page residency differently for each engine, had different warmup procedures and only n=2/3 independent runs. Do not treat them as causal per-engine RAM sensitivity estimates.

## Methodological explanation and remaining work

- The new diagnostic confirmed `mincore` can report 100% of *both* sealed DBs resident. After targeted `POSIX_FADV_DONTNEED`, **one sequential scan did not guarantee 100% retention**. A second scan achieved 100% for both databases in the diagnostic; the final full-resident protocol repeatedly scanned until >=99.5% and then verified before/after the timed batch.
- The fully resident 4-GiB RDC-controller diagnostic also showed Polar.DB faster (6.291 vs SQLite 13.069 µs/query), but its cgroup `memory.events:max` increased by 687/45 respectively, so **both 4-GiB results are rejected as clean baselines**.
- Identical logical data and keys do not imply identical page-cache states. SQLite's 20M DB was 2,053,685,248 B; Polar.DB files together were 2,300,000,084 B. The second engine's internal indexes occupy RAM; their file access patterns, query plans and CPU cost differ. Differences in file size and per-file residency require investigation before crediting a specific implementation mechanism.
- The fully resident/no-I/O observation is **not trivial in isolation**; its scientific interest is the *reversal of relative ranking* for the identical uniform keys when compared with the partially resident state. But repeatability of the exact crossover and its mechanism requires balanced independent confirmation and explicit per-file residency, not just more parameter-grid measurements.
- Inadequate inference: "At 8 GiB everything fits by definition", "lower RAM causes crossover", "Polar.DB algorithm uses more RAM to gain speed", "SQLite universally wins under memory pressure". None is proven.

## Decision

The RAM study now has a promising, experimentally grounded **cache-state conditional rank reversal**, but **do not alter the main article yet**. Next highest-value action: pin each engine's per-file page residency at batch start/end and model actual file traffic at selected random key positions; confirm ranking with independently balanced runs under the two defined states at the *same RAM limit* (8 GiB), distinguishing forced-cold/warmup artifacts from steady state. If the mechanism becomes explainable and robust, introduce at most one compact figure/table; otherwise keep in supplementary analysis.

Evidence: `metrics/resident-v3-20000000-8g-*.json`, `query-results/pk-int-lookup/resident-v3-20000000-8g-*.json`, `summarize_resident.py`, `FULL_RESIDENCY_CONTROL.md`. The repository `main` and existing paper remain unchanged.

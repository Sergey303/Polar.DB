param([int[]] $Repeats = @(1,2))
$ErrorActionPreference = 'Stop'

function Run-Isolated([string]$Name, [string]$Command) {
    Write-Host "=== $Name : 8 GiB, no swap ==="
    docker run --rm `
        --name $Name `
        --memory='8g' --memory-swap='8g' `
        --mount type=volume,source=polar-bench-data,target=/work `
        --workdir /work/Polar.DB `
        mcr.microsoft.com/dotnet/sdk:10.0 `
        bash -lc "apt-get update -qq && apt-get install -y -qq python3 git > /dev/null && $Command"
    if ($LASTEXITCODE -ne 0) { throw "Stopped after $Name exit=$LASTEXITCODE" }
}

$root='/work/ram-study/stage3-0fd84e3/prepared-20000000'
$src='0fd84e3da854aa9f536a75861e7838af41955bdc'
$exe='/work/Polar.DB/benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'
foreach ($engine in @('sqlite','polar-db')) {
    $verify="dotnet '$exe' --prepared-plan=uniform-v3 --prepared-stage=verify --prepared-root='$root' --prepared-source-sha='$src' --benchmark-engine='$engine' --rows=20000000"
    Run-Isolated "polar-s31-8g-preverify-$($engine.Replace('-',''))" $verify
}
foreach ($rep in $Repeats) {
    $engines = if ($rep % 2 -eq 0) { @('polar-db','sqlite') } else { @('sqlite','polar-db') }
    foreach ($engine in $engines) {
        $name="polar-s31-8g-$($engine.Replace('-',''))-r$rep"
        $command="python3 -u /work/ram-study/stage3-1-6cc8034/stage3_1_worker.py --gib 8 --engine $engine --rows 20000000 --repeat $rep"
        Run-Isolated $name $command
    }
}
foreach ($engine in @('sqlite','polar-db')) {
    $verify="dotnet '$exe' --prepared-plan=uniform-v3 --prepared-stage=verify --prepared-root='$root' --prepared-source-sha='$src' --benchmark-engine='$engine' --rows=20000000"
    Run-Isolated "polar-s31-8g-postverify-$($engine.Replace('-',''))" $verify
}
Run-Isolated 'polar-s31-8g-report' 'python3 /work/ram-study/stage3-1-6cc8034/summarize.py'
Write-Host 'IMPORTANT: assess ResidencyBeforeBatch (goal >= 0.95 per engine). Below 0.95 invalidates fully resident control claim, even when the RAM cap is 8 GiB.'

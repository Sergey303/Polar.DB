param([int[]] $Repeats = @(1,2,3))
$ErrorActionPreference = 'Stop'

# Source Git SHA and prepared database SHA are pinned; no database rebuild.
# A run is accepted only when both mincore probes are >= 99.5%, measured
# batch read_bytes == 0, and memory.events:max has NOT increased.
function Run-Isolated([string]$Name, [string]$Command) {
    Write-Host "=== $Name : 8 GiB, no swap ==="
    docker run --rm `
        --name $Name `
        --memory='8g' --memory-swap='8g' `
        --mount type=volume,source=polar-bench-data,target=/work `
        --workdir /work/Polar.DB `
        mcr.microsoft.com/dotnet/sdk:10.0 `
        bash -lc "apt-get update -qq && apt-get install -y -qq python3 git > /dev/null && $Command"
    if ($LASTEXITCODE -ne 0) {
        throw "Stopped at $Name; inspect saved metrics/logs under /work/ram-study/stage3-1-6cc8034/"
    }
}

$source='/work/ram-study/stage3-0fd84e3/prepared-20000000'
$sha='0fd84e3da854aa9f536a75861e7838af41955bdc'
$dll='/work/Polar.DB/benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'
foreach ($engine in @('sqlite','polar-db')) {
    $cmd="dotnet '$dll' --prepared-plan=uniform-v3 --prepared-stage=verify --prepared-root='$source' --prepared-source-sha='$sha' --benchmark-engine='$engine' --rows=20000000"
    Run-Isolated "polar-resident-preverify-$($engine.Replace('-',''))" $cmd
}

foreach ($rep in $Repeats) {
    $order=if ($rep % 2 -eq 1) { @('sqlite','polar-db') } else { @('polar-db','sqlite') }
    foreach ($engine in $order) {
        $name="polar-resident-8g-$($engine.Replace('-',''))-r$rep"
        $cmd="python3 -u /work/ram-study/stage3-1-6cc8034/resident_control_worker.py --gib 8 --engine $engine --rows 20000000 --repeat $rep"
        Run-Isolated $name $cmd
    }
}

foreach ($engine in @('sqlite','polar-db')) {
    $cmd="dotnet '$dll' --prepared-plan=uniform-v3 --prepared-stage=verify --prepared-root='$source' --prepared-source-sha='$sha' --benchmark-engine='$engine' --rows=20000000"
    Run-Isolated "polar-resident-postverify-$($engine.Replace('-',''))" $cmd
}
Run-Isolated 'polar-resident-8g-report' 'python3 /work/ram-study/stage3-1-6cc8034/summarize_resident.py'
Write-Host 'Complete: qualifying 8-GiB fully-resident uniform-v3 controls.'

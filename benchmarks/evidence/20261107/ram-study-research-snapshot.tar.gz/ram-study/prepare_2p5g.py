from pathlib import Path
source = Path('/work/ram-study/run-3g.py').read_text()
replacements = {
    '/work/ram-study/3g': '/work/ram-study/2p5g',
    'limit!=3*GIB': 'limit!=int(2.5*GIB)',
    '3 GiB cgroup memory': '2.5 GiB cgroup memory',
    'ram3g-': 'ram2p5g-',
    "profile=[('PkIntLookup',50000),('PkIntLookup',5000000),('PkStringLookup',5000000),('ExternalStringLookup',5000000)]": "profile=[('PkIntLookup',50000),('PkIntLookup',5000000)]",
}
for old, new in replacements.items():
    if old not in source:
        raise RuntimeError('Template mismatch: ' + old)
    source = source.replace(old, new)
output = Path('/work/ram-study/run-2p5g.py')
output.write_text(source)
print('Prepared', output)

#!/usr/bin/env python3
"""Compare 8/4/3 GiB independent coordinator medians, without conflating intra-run samples."""
import csv,json,statistics
from pathlib import Path
from collections import defaultdict
base=Path('/work/ram-study')
results={}
for mem in (8,4,3):
 file=base/f'{mem}g/runs.json'
 if not file.exists():continue
 meta=json.loads(file.read_text());data=defaultdict(list)
 for run in meta['runs']:
  if run['exitCode'] or not run.get('raw'):continue
  source=Path(run['raw']).parent/'samples.csv'
  groups=defaultdict(list)
  with source.open() as f:
   for row in csv.DictReader(f):
    if row['metric']!='lookup-batch-average' or row['phase']!='Hot after file and lookup warmup':continue
    groups[row['engine']].append(float(row['value']))
  for engine,values in groups.items():data[(run['project'],run['rows'],engine)].append(statistics.median(values))
 results[mem]=(meta,data)
print('LIMITS:',[(m,len(v[0]['runs']),v[0]['memoryMax'],v[0]['swapMax']) for m,v in results.items()])
print('Median of coordinator medians; warmed batch avg, unit microseconds for PK else milliseconds')
keys=set(k for _,d in results.values() for k in d)
for key in sorted(keys):
 scale=1000 if key[0].startswith('Pk') else 1;unit='us' if scale==1000 else 'ms'
 dat={m:(round(statistics.median(d[key])*scale,4),len(d[key])) if key in d else None for m,(_,d) in results.items()}
 print(f'{key[0]:22} {key[1]:8} {key[2]:16} ({unit})',dat)
for m,(meta,_) in results.items():
 r=meta['runs'];print(f'{m}GiB: {len(r)}/8 runs, success {sum(x["exitCode"]==0 for x in r)}, peakGiB {round(max(x["memoryPeakSampledBytes"] for x in r)/2**30,3)}, major faults {sum(x["memoryStatDelta"].get("pgmajfault",0) for x in r)}, max-cgroup events {sum(x["memoryEventsDelta"].get("max",0) for x in r)}, oomKills {sum(x["memoryEventsDelta"].get("oom_kill",0) for x in r)}')

param([int[]]$Repeats=@(1,2))
$ErrorActionPreference='Stop'
$vol='type=volume,source=polar-bench-data,target=/work'
$study='/work/ram-study/stage4-1-pinned'
$data='/work/ram-study/stage3-0fd84e3/prepared-20000000'
$src='0fd84e3da854aa9f536a75861e7838af41955bdc'
$dll='/work/Polar.DB/benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'

# Build the tools image once if Stage 4's cached one is absent.
$imageTag='polar-stage4-local:v1'
docker image inspect $imageTag *> $null
if ($LASTEXITCODE -ne 0) {
    $dir=Join-Path $env:TEMP 'polar-pinned-image-v1'
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    docker run --rm --mount $vol mcr.microsoft.com/dotnet/sdk:10.0 `
        cat /work/ram-study/stage4-confirmation/Dockerfile |
        Set-Content -Encoding ASCII (Join-Path $dir 'Dockerfile')
    if ($LASTEXITCODE -ne 0) { throw 'Cannot read Dockerfile for tools image' }
    docker build -t $imageTag $dir
    if ($LASTEXITCODE -ne 0) { throw 'Cannot build Docker image' }
}
$image=(docker image inspect --format '{{.Id}}' $imageTag).Trim()
if ($LASTEXITCODE -ne 0 -or !$image.StartsWith('sha256:')) { throw 'Cannot resolve tools image' }
Write-Host "Using image ID: $image"

function Run-Pinned([string]$name,[string]$action) {
    Write-Host "=== $name : 8 GiB, memlock 3 GiB, no swap ==="
    docker run --rm `
        --name $name `
        --memory='8g' --memory-swap='8g' `
        --ulimit memlock=3221225472:3221225472 `
        --mount $vol `
        --workdir /work/Polar.DB `
        $image `
        bash -lc $action
    if ($LASTEXITCODE -ne 0) {
        throw "FAILED: $name. Original artifacts preserved. See $study/metrics/"
    }
}

foreach ($e in @('sqlite','polar-db')) {
    $cmd="dotnet '$dll' --prepared-stage=verify --prepared-plan=uniform-v4 --prepared-root='$data' --prepared-source-sha='$src' --benchmark-engine=$e --rows=20000000"
    Run-Pinned "pinv4-preverify-$($e.Replace('-',''))" $cmd
}

$cases=@('sqlite:none','polar-db:none','polar-db:hashes',
         'polar-db:offsets','polar-db:payload','sqlite:data')
foreach ($r in $Repeats) {
    if ($r -notin @(1,2)) { throw 'Only repeat IDs 1 and 2 are supported' }
    $ordered=@($cases)
    if ($r -eq 2) { [array]::Reverse($ordered) }
    foreach ($item in $ordered) {
        $engine,$condition=$item.Split(':')
        $tag="pinv4-host-$($engine.Replace('-',''))-$condition-r$r"
        $cmd="python3 -u '$study/worker.py' --engine $engine --condition $condition --rep $r"
        Run-Pinned $tag $cmd
    }
}
foreach ($e in @('sqlite','polar-db')) {
    $cmd="dotnet '$dll' --prepared-stage=verify --prepared-plan=uniform-v4 --prepared-root='$data' --prepared-source-sha='$src' --benchmark-engine=$e --rows=20000000"
    Run-Pinned "pinv4-postverify-$($e.Replace('-',''))" $cmd
}
Run-Pinned 'pinv4-host-summary' "python3 '$study/summarize.py'"
Write-Host 'Pinned-cache engineering validation complete; Stage 4 results and manuscript untouched.'

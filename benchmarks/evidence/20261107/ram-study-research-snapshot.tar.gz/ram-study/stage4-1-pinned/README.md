# Stage 4.1 — pinned-page cache engineering acceptance

This is **not** a rerun, extension or reinterpretation of the scientific Stage 4 (48/48 runs, INCONCLUSIVE). It validates an engineering solution for the race between cache warming and the measured query: Linux read-only `mmap` + `mlock` of all prepared files before opening the engine, with selected `munlock` + `munmap` only after a successful baseline `mincore` snapshot and before `POSIX_FADV_DONTNEED`. All unselected files stay pinned across the query batch and latency phase.

Published Polar.DB `main`: `a11457ce502b416041ea7bde0b53d2dc047db491` (no engine changes). Old sealed 20M data SHA: `0fd84e3da854aa9f536a75861e7838af41955bdc`. The new `uniform-v4` sidecars were generated and verified separately for both engines. Old v3/v32 sidecars, archived datasets and all Stage 3/4 results unchanged.

## Run on the Windows host with Docker Desktop

The `run-host.ps1` script validates existing prepared files, executes exactly two independent repeats of each of six smoke scenarios (12 total) in a fresh **8-GiB no-swap container** with **3 GiB RLIMIT_MEMLOCK**, reverses order on repeat 2, post-verifies data SHA-256 and reports acceptance. It uses the existing cached `polar-stage4-local:v1` image if available and otherwise builds one small local image from the stage-4 Dockerfile. No packages are installed during measured runs. No database build. **Never rerun an existing ID**; a failed test is retained for diagnosis rather than being replaced.

```powershell
docker run --rm `
  --mount type=volume,source=polar-bench-data,target=/work `
  mcr.microsoft.com/dotnet/sdk:10.0 `
  cat /work/ram-study/stage4-1-pinned/run-host.ps1 |
  Set-Content -Encoding UTF8 .\polar-pinned-v4.ps1
if ($LASTEXITCODE -ne 0) { throw 'Failed to get pinned-cache script' }
powershell -NoProfile -ExecutionPolicy Bypass -File .\polar-pinned-v4.ps1
```

The worker asserts exact Git source SHA, v4 sidecar and 20M prepared database provenance; verified 8-GiB cgroup and zero swap; RLIMIT_MEMLOCK >=3GiB; checksum equality; initial `PinnedInitiallyBytes == sum(sealed file sizes)`; `PinnedDuringBatchBytes` equals that sum minus only the selected file; `mincore` unselected pages >=99.5% before AND after timed batch; selected file <=10% resident before batch; no memory.max hit/OOM. Records *all* batch `read_bytes` as a continuous metric; no threshold-based exclusion. Output is under `metrics/` and `raw/` here, never in Stage 4. A run that cannot pin due to host permissions or insufficient RAM exits with a clear message and is **not** counted as success.

The acceptance test validates that the experimental cache state remains stable at full 20M scale; it **does not** by itself confirm Stage 4's scientific effect or permit publication claims. Stage 4's preregistered `INCONCLUSIVE` status is final and remains unchanged. The main article stays untouched.

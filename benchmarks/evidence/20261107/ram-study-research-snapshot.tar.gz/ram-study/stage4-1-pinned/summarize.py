#!/usr/bin/env python3
"""Show engineering acceptance; never pool results with frozen Stage 4."""
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
cases={'sqlite':('none','data'),
       'polar-db':('none','hashes','offsets','payload')}
reports=[]
missing=[]
for r in (1,2):
    for engine,conditions in cases.items():
        for condition in conditions:
            tag=f'pinv4-20m-8g-{engine}-{condition}-r{r}'
            file=HERE/'metrics'/(tag+'.json')
            if not file.exists():
                missing.append(tag)
                continue
            d=json.loads(file.read_text())
            assert d['id']==tag and d['engine']==engine and d['condition']==condition and d['rep']==r
            reports.append(d)
            status='PASS' if d['passed'] else 'FAIL'
            print(status,tag,'peak GiB',d.get('cgroupPeakSampledGiB'),
                  'batch IO MB',round(d.get('details',{}).get('batchReadBytes',0)/1e6,3),
                  'issues',d['issues'])
print('PINNED engineering attempts',len(reports),'of 12;',
      'passes',sum(d['passed'] for d in reports),'failures',sum(not d['passed'] for d in reports),
      'missing',len(missing))
if missing:print('MISSING',', '.join(missing))
if len(reports)!=12 or not all(d['passed'] for d in reports):
    raise SystemExit('PINNED CACHE ENGINEERING ACCEPTANCE INCOMPLETE')
print('PASS: all 12 full-scale 8-GiB no-swap pinned-cache cases; no scientific confirmation claim')

# Stage 4.1 pinned cache — engineering acceptance report (2026-11-06)

## Decision: ENGINEERING ACCEPTED, not a scientific Stage-4 reclassification

The completed host exercise ran **12/12** predefined `uniform-v4` cases successfully at 20,000,000 rows in independently started **8 GiB memory/no swap** containers with 3 GiB `RLIMIT_MEMLOCK`. Two successful repeats each of `sqlite:none`, `sqlite:data`, `polar-db:none`, `polar-db:hashes`, `polar-db:offsets`, `polar-db:payload`. **Zero rejected, missing, OOM-killed or memory.max-hit runs.** Every result retains correct expected batch/latency checksums and the original uniform key-stream identity.

Published Git `main` source SHA: `a11457ce502b416041ea7bde0b53d2dc047db491` (clean). Prepared 20M dataset source SHA: `0fd84e3da854aa9f536a75861e7838af41955bdc`; independent v4 plan files were separately SHA-verified. The old databases were never rebuilt. Old Stage 3.*/4 evidence, frozen protocol and article are unchanged.

## Two successful engineering checks per condition

Batch arithmetic mean per lookup, in µs. **Diagnostic only; NOT a confirmatory scientific estimate.** I/O is process read_bytes during the batch, in decimal MB.

| Engine / treatment | r1 µs | r2 µs | r1/r2 batch read MB | Correct pin and pre/post residency? |
|---|---:|---:|---:|---|
| Polar.DB `none` | 10.316 | 13.042 | 0 / 0 | yes: all five files remain pinned, 100% resident |
| Polar.DB `hashes` (`f1.bin`) | 10.943 | 7.642 | 0 / 0 | yes: f1 evicted, other files pinned |
| Polar.DB `offsets` (`f2.bin`) | 215.009 | 203.616 | 93.274 / 93.274 | yes: f2 evicted, f0/f1 pinned |
| Polar.DB `payload` (`f0.bin`) | 230.092 | 223.315 | 81.142 / 81.142 | yes: f0 evicted, f1/f2 pinned |
| SQLite `none` | 22.960 | 17.518 | 0 / 0 | yes: entire database pinned, 100% resident |
| SQLite `data` | 230.950 | 241.470 | 46.850 / 46.850 | yes: database unmapped/unlocked and evicted |

Polar.DB explicitly successfully locked 2,300,000,084 file bytes initially; `none` retained that pin across the query, while the treatment conditions released exactly 80,000,008 (`f1`), 160,000,008 (`f2`) or 2,060,000,008 (`f0`) bytes before eviction. SQLite initially locked 2,053,685,248 bytes. All 12 raw JSON records were re-read and checked independently for query-expected checksums, version/provenance, pinned byte counts, per-file `mincore` state and process `read_bytes`; no violation was found. Process/cgroup sampled memory_current reflects cgroup accounting and does not independently quantify all globally resident file pages; the `mlock` call success and mincore samples are the relevant state indicators.

## Why this fixes the Stage-4 pre-measurement race

The preceding study performed one or more full sequential scans and checked `mincore` at a later step; another process could evict the pages in between. In v4 `PreparedPageLock` maps each sealed file read-only and calls Linux `mlock` **before the database opens or warms key structures**; unselected pages are not eligible for page-cache reclamation until query and latency measurement complete. Immediately before eviction, `mincore` validates all files resident; the chosen target is then `munlock`ed and `munmap`ped **outside measured time**, and `posix_fadvise(DONTNEED)` is applied to that file only. `mincore` before and after measured batch checks that the target and unselected file states match the plan. `mlock` can fail under host permissions/lockable memory limits, and the runner **fails closed** instead of silently accepting a weakened experiment.

## Remaining caveat and next step

The engineering race is **not reproduced in the 12 full-scale controlled attempts**, supporting the fix. This is not a formal proof that every environment will succeed. We have not repeated a separate independently preregistered 8-block scientific confirmation with v4; the published Stage 4 analysis correctly remains **INCONCLUSIVE (48 attempted, 40 qualified, only four of eight valid primary pairs)**. Do not pool the two studies or reuse Stage-4 IDs to claim a retroactive success.

If the scientific contribution requires confirmation of the `f2` vs `f1` performance difference, design a **new** prospectively locked experiment against `uniform-v4` with the same predeclared error logging and paired analysis, clean A/B run order, full SHA verification and enough independent blocks. No code changes to Polar.DB engine are necessary for this engineering fix. Existing manuscript unchanged.

Data: `metrics/pinv4-20m-8g-*.json`, `raw/pk-int-lookup/pinv4-20m-8g-*.json`; integrity check: `python3 summarize.py` and `--prepared-plan=uniform-v4 --prepared-stage=verify` for both engines.

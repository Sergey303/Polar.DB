#!/usr/bin/env python3
"""Guarded full-scale engineering acceptance for mlock-v1; not a science rerun."""
import argparse, json, os, resource, signal, subprocess, time
from pathlib import Path

BASE=Path('/work/ram-study/stage4-1-pinned')
REPO=Path('/work/Polar.DB')
DATA=Path('/work/ram-study/stage3-0fd84e3/prepared-20000000')
RUNNER='a11457ce502b416041ea7bde0b53d2dc047db491'
SOURCE='0fd84e3da854aa9f536a75861e7838af41955bdc'
KEYS='44106a815bb975ddbf956a475c5b6463832ce2bdaa139b59da6c18ffa50daf57'
GIB=1024**3
CG=Path('/sys/fs/cgroup')
CONDITIONS={'sqlite':('none','data'),
            'polar-db':('none','hashes','offsets','payload')}
TARGET={'sqlite':{'data':'data.sqlite'},'polar-db':{
    'hashes':'f1.bin','offsets':'f2.bin','payload':'f0.bin'}}


def number(name):return int((CG/name).read_text().strip())


def events():
    return {a:int(b) for a,b in (line.split() for line in
                                  (CG/'memory.events').read_text().splitlines())}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--engine',required=True,choices=CONDITIONS)
    ap.add_argument('--condition',required=True)
    ap.add_argument('--rep',required=True,type=int,choices=(1,2))
    args=ap.parse_args();e=args.engine;c=args.condition;r=args.rep
    if c not in CONDITIONS[e]:raise SystemExit('Invalid target')
    if number('memory.max')!=8*GIB or number('memory.swap.max')!=0:
        raise SystemExit('Refuse wrong 8-GiB, no-swap cgroup')
    if resource.getrlimit(resource.RLIMIT_MEMLOCK)[0]<3*GIB:
        raise SystemExit('Refuse low memlock limit (need >=3 GiB)')
    sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
    dirty=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=REPO,text=True).strip()
    if sha!=RUNNER or dirty:raise SystemExit('Refuse different/dirty runner')
    root=DATA/'pk-int-lookup/rows-20000000'
    ready=json.loads((root/(e+'.ready.json')).read_text())
    plan=json.loads((root/(e+'.uniform-v4.json')).read_text())
    assert ready['SourceSha']==SOURCE and ready['Rows']==20_000_000
    assert plan['ProtocolVersion']==4 and plan['RunnerSourceSha']==RUNNER
    assert plan['DatasetSourceSha']==SOURCE and plan['KeyStreamSha256']==KEYS
    tag=f'pinv4-20m-8g-{e}-{c}-r{r}'
    p=BASE/'metrics'/(tag+'.json');log=BASE/'metrics'/(tag+'.log')
    raw=BASE/'raw/pk-int-lookup'/(tag+'.json')
    if p.exists() or log.exists() or raw.exists():
        raise SystemExit('Refuse overwrite: '+tag)
    before=events();maxmem=number('memory.current')
    dll=REPO/'benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'
    cmd=['dotnet',str(dll),'--prepared-plan=uniform-v4','--prepared-stage=query',
         f'--prepared-root={DATA}',f'--prepared-source-sha={SOURCE}',
         f'--prepared-results-root={BASE / "raw"}',f'--benchmark-engine={e}',
         '--rows=20000000',f'--prepared-cache-treatment={c}',f'--benchmark-run-id={tag}']
    began=time.monotonic();failure=None
    with log.open('x') as sink:
        proc=subprocess.Popen(cmd,cwd=REPO,stdout=sink,stderr=subprocess.STDOUT,
                              start_new_session=True)
        while proc.poll() is None:
            maxmem=max(maxmem,number('memory.current'))
            if time.monotonic()-began>180:
                failure='timeout'
                try:os.killpg(proc.pid,signal.SIGTERM)
                except ProcessLookupError:pass
                break
            time.sleep(.06)
        try:code=proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL);code=proc.wait()
    changed=events();errs=[]
    if failure or code:errs.append(failure or f'process exit {code}')
    if changed.get('max',0)!=before.get('max',0):errs.append('memory.max hit')
    if changed.get('oom_kill',0)!=before.get('oom_kill',0):errs.append('OOM kill')
    details={}
    if raw.exists():
        d=json.loads(raw.read_text())
        if d['QueryRunnerSha']!=RUNNER or d['SourceSha']!=SOURCE or d['PlanKeyStreamSha256']!=KEYS:
            errs.append('provenance mismatch')
        if d['BatchChecksum']!=d['ExpectedBatch']['Checksum'] or d['LatencyChecksum']!=d['ExpectedLatency']['Checksum']:
            errs.append('checksum mismatch')
        files={f['Name']:f['Bytes'] for f in ready['Files']}
        target=TARGET[e].get(c)
        total=sum(files.values());remain=total-files[target] if target else total
        if d['PinnedCacheProtocol']!='mlock-v1' or d['PinnedInitiallyBytes']!=total or d['PinnedDuringBatchBytes']!=remain:
            errs.append('pinned-page counts do not match intended treatment')
        pre={f['Name']:f['Fraction'] for f in d['ResidencyBeforeBatch']['Files']}
        post={f['Name']:f['Fraction'] for f in d['ResidencyAfterBatch']['Files']}
        for name in files:
            if name==target:
                if pre[name]>.10:errs.append('selected file not evicted: '+name)
            elif pre[name]<.995 or post[name]<.995:
                errs.append('unselected file lost cache: '+name)
        s=d['Snapshots'];reads=s['AfterBatch']['ProcessIo']['read_bytes']-s['AfterCacheTreatment']['ProcessIo']['read_bytes']
        details={'pinnedInitialBytes':total,'pinnedDuringBatchBytes':remain,
                 'preBatchResident':pre,'postBatchResident':post,'batchReadBytes':reads,
                 'meanBatchUs':sum(d['BatchAverageMs'])*1000/len(d['BatchAverageMs'])}
    else:errs.append('missing raw result')
    report={'id':tag,'engine':e,'condition':c,'rep':r,'passed':not errs,
            'issues':errs,'exitCode':code,'elapsedSeconds':round(time.monotonic()-began,3),
            'cgroupPeakSampledGiB':round(maxmem/GIB,4),
            'cgroupEventsDelta':{k:changed.get(k,0)-v for k,v in before.items()},
            'details':details,'raw':str(raw) if raw.exists() else None}
    p.write_text(json.dumps(report,indent=2)+'\n')
    print('PINNED RESULT',json.dumps(report),flush=True)
    if errs:raise SystemExit(2)

if __name__=='__main__':main()

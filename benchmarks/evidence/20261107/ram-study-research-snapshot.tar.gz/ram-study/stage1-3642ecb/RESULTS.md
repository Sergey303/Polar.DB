# Stage 1 — verification of streaming generator at low RAM

## Scope

- Source: `3642ecb8d4b84bd75690411eef9815c24293797c` (`main`, Nov 6, 2026).
- Reference source before fix: `a49a08316fde4207853c0307fe63de0b84d30bd3`.
- Workload: 5,000,000 records, `PkIntLookup`, same logical rows and queries, worker per engine; Release .NET 10, cgroup memory+swap limits, swap=0.
- Five new `BenchmarkDatasetTests` passed; Release benchmark build succeeded.
- One worker run per RAM/engine cell, not a publication-grade independent series.

| Limit | Engine | Exit | Elapsed whole worker, s | Peak process VmHWM, MiB | Peak cgroup usage, GiB | memory.events:max | OOM kills |
|---|---|---:|---:|---:|---:|---:|---:|
| 2 GiB | SQLite | 0 | 17.586 | 70.2 | 1.098 | 0 | 0 |
| 2 GiB | Polar.DB | 0 | 8.240 | 277.3 | 0.900 | 0 | 0 |
| 3 GiB | SQLite | 0 | 19.494 | 70.1 | 1.091 | 0 | 0 |
| 3 GiB | Polar.DB | 0 | 8.146 | 277.1 | 0.883 | 0 | 0 |
| 4 GiB | SQLite | 0 | 19.794 | 68.9 | 1.932 | 0 | 0 |
| 4 GiB | Polar.DB | 0 | 7.437 | 276.9 | 1.691 | 0 | 0 |

Additional smoke tests at 4 GiB / 50,000 rows passed on both engines. Raw worker JSON for every run is under `benchmarks/results/raw/pk-int-lookup/s1-3642ecb-<limit>g-<engine>-5000000/`.

## Correctness

Both engines agree exactly on `batchRows`, `batchChecksum`, `latencyRows`, `latencyChecksum` for both phases and all RAM limits. These values also match the corresponding old `a49a083` runs, including old 2 GiB SQLite and old 3 GiB SQLite/Polar.DB runs. The fixture did not change its verified result semantics.

## Interpretation and caveats

1. On old `a49a083`, the 5m-row, 2 GiB Polar.DB worker aborted during setup with `Out of memory`; on `3642ecb` it completes. The streaming generator fix removed harness-side O(N) row retention and is consistent with the recovery. It does not establish a minimum RAM requirement for the engine itself.
2. Peak process VmHWM is a process measurement. Cgroup `memory.current` includes page cache, kernel and other tasks. In the 4 GiB runs the RDC agent shared the cgroup with benchmarks; therefore its container peaks are not directly comparable to the isolated 2/3 GiB siblings. Cgroup file and anon peaks were separately sampled and are not additive at one instant.
3. The SQLite raw database is larger on disk than the Polar.DB artifact for this workload. Lower total cgroup usage by Polar.DB in these single runs is consistent with less page-cache charge, but the attribution is not proven and OS cache ownership can differ.
4. Worker elapsed time includes data generation/build, opening, cold and warm querying, checksums and cleanup. Never interpret it as pure lookup latency, `Build` latency, or as a statistically supported speed ratio.
5. Neither driver is yet query-only. We have not established the performance/RAM boundary after a database is prebuilt and reopened.
6. These one-off tests support Stage 1's feasibility/correctness finding, not a new claim in the current article. The article is unchanged.

## Next stage

Create prebuilt datasets per engine, separately measure build and query-only execution using identical key streams. Measure per-engine process anonymous memory, cgroup file cache and query-stage physical I/O, with independent repetitions and fixed SHA. Keep all results outside the article until reviewed for a scientific contribution.

Audit: `python3 /work/ram-study/stage1_summarize.py`.

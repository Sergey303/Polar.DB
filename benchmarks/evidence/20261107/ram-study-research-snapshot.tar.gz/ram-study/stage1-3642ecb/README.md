# Generator RAM regression pilot (not publication series)

Source SHA: `3642ecb8d4b84bd75690411eef9815c24293797c`.
Comparison reference: old series SHA `a49a08316fde4207853c0307fe63de0b84d30bd3`.

- Rebuilt `PkIntLookup` in Release and ran `BenchmarkDatasetTests`: 5/5 pass.
- Use `/work/ram-study/stage1_3642ecb.py` with `--gib 2|3|4 --engine sqlite|polar-db --rows 5000000`.
- Run each 2 GiB and 3 GiB engine in **its own disposable Docker container**, never in the controlling 4 GiB RDC container. Docker must set `--memory=${g}g --memory-swap=${g}g`.
- The benchmark workers are isolated engine processes, not coordinators. Raw worker JSON lives under `benchmarks/results/raw/pk-int-lookup/s1-3642ecb-<g>g-<engine>-<rows>/`.
- Metrics: process VmHWM (sampled), cgroup memory.current (sampled, **includes file cache**), anon/file maxima (sampled), cgroup memory.events, refaults. These are descriptive, single attempts, and reflect build + queries + oracle; they are NOT query-only measurements.
- A cgroup peak from two different container runs is not a directly comparable per-engine process RSS. The shared Docker volume and Linux page cache introduce inter-run coupling.
- One baseline 4 GiB series passed both engine workers for 50,000 and 5,000,000 rows, and SQLite/Polar.DB checksums match in both cold and warm phases.
- Keep base article unchanged; this is a feasibility check of the streaming-generator fix, not a new publication claim.
- Audit using `python3 /work/ram-study/stage1_summarize.py`.

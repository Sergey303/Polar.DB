from pathlib import Path
source = Path('/work/ram-study/run-3g.py').read_text()
replacements = {
    '/work/ram-study/3g': '/work/ram-study/2g',
    '3*GIB': '2*GIB',
    '3 GiB cgroup memory': '2 GiB cgroup memory',
    'ram3g-': 'ram2g-',
}
for old, new in replacements.items():
    if old not in source:
        raise RuntimeError('Template mismatch: ' + old)
    source = source.replace(old, new)
output = Path('/work/ram-study/run-2g.py')
output.write_text(source)
print('Prepared', output)

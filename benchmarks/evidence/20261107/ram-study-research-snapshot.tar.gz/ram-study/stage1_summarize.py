#!/usr/bin/env python3
"""Audit immutable stage-1 engine workers and compare lookup checksums."""
from pathlib import Path
import json
P=Path('/work/ram-study/stage1-3642ecb')
for g in (2,3,4):
 print(f'=== {g} GiB ===')
 for rows in (50000,5000000):
  workers={}
  for engine in ('sqlite','polar-db'):
   name=f's1-3642ecb-{g}g-{engine}-{rows}'
   p=P/f'{g}g'/(name+'.json')
   if not p.is_file():
    print(rows,engine,'NOT RUN');continue
   d=json.loads(p.read_text());worker=d.get('workerJson')
   print(rows,engine,'exit',d['exitCode'],'elapsed',d['seconds'],'VmHWM GiB',d['processVmHWMMaxSampledGiB'],'cgroupMax GiB',d['cgroupPeakSampledGiB'],'anonMax GiB',d['cgroupAnonMaxSampledGiB'],'fileMax GiB',d['cgroupFileMaxSampledGiB'],'maxEvents',d['memoryEventsDelta'].get('max'),'oomKill',d['memoryEventsDelta'].get('oom_kill'), 'workerJSON',bool(worker))
   if worker:
    w=json.loads(Path(worker).read_text())
    workers[engine]=[(ph['name'],ph['engines'][0]['batchRows'],ph['engines'][0]['batchChecksum'],ph['engines'][0]['latencyRows'],ph['engines'][0]['latencyChecksum']) for ph in w['lookupRuns'][0]['phases']]
  if len(workers)==2:
   print('CORRECTNESS',rows,'MATCH' if workers['sqlite']==workers['polar-db'] else 'MISMATCH')

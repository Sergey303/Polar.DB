#!/usr/bin/env python3
"""Safely prepare one 20M benchmark dataset in the 4-GiB controller container.

Stop before memory reaches the container hard limit. No automatic cleanup of
failed data, preventing destruction of evidence and other benchmark artifacts.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

GIB=1024**3
ROOT=Path('/work/Polar.DB')
CG=Path('/sys/fs/cgroup')
BASE=Path('/work/ram-study/stage3-0fd84e3')
EXPECTED='0fd84e3da854aa9f536a75861e7838af41955bdc'


def number(path):
    try: return int(Path(path).read_text().strip())
    except (ValueError,OSError): return -1


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--engine',choices=('sqlite','polar-db'),required=True)
    ap.add_argument('--gib',type=int,choices=(8,),required=True)
    args=ap.parse_args()
    sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    if sha!=EXPECTED or number(CG/'memory.max')!=args.gib*GIB or number(CG/'memory.swap.max')!=0:
        sys.exit('REFUSE: expected clean SHA and 8-GiB no-swap preparation container')
    if subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True).strip():
        sys.exit('REFUSE: tracked source dirty')
    prepared=BASE/'prepared-20000000'
    db=prepared/'pk-int-lookup/rows-20000000'/args.engine
    manifest=prepared/'pk-int-lookup/rows-20000000'/(args.engine+'.ready.json')
    if db.exists() or manifest.exists(): sys.exit('REFUSE: prepared dataset already exists')
    disk=shutil.disk_usage(ROOT).free
    if disk<24*GIB: sys.exit('REFUSE: low disk reserve')
    log=BASE/'metrics'/f'prepare-20m-{args.engine}.log'
    report=BASE/'metrics'/f'prepare-20m-{args.engine}.json'
    log.parent.mkdir(parents=True,exist_ok=True)
    if log.exists() or report.exists():sys.exit('REFUSE: prior prepare log exists')
    exe=ROOT/'benchmarks/src/PkIntLookup/bin/Release/net10.0/PkIntLookup.dll'
    cmd=['dotnet',str(exe),'--prepared-stage=prepare',f'--prepared-root={prepared}',
         f'--benchmark-engine={args.engine}','--rows=20000000']
    peak=number(CG/'memory.current')
    max_rss=0
    reason=None
    started=time.monotonic()
    with log.open('x') as output:
        proc=subprocess.Popen(cmd,cwd=ROOT,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
        while proc.poll() is None:
            mem=number(CG/'memory.current')
            peak=max(peak,mem)
            try:
                for line in Path(f'/proc/{proc.pid}/status').read_text().splitlines():
                    if line.startswith('VmHWM:'): max_rss=max(max_rss,int(line.split()[1])*1024)
            except OSError:pass
            if mem > int((args.gib-.22)*GIB):reason='preparation memory safety cutoff'
            elif time.monotonic()-started>300:reason='300s timeout'
            elif disk-shutil.disk_usage(ROOT).free>6*GIB or shutil.disk_usage(ROOT).free < 16*GIB:
                reason='disk guard 6 GiB growth / 16 GiB reserve'
            if reason:
                try:os.killpg(proc.pid,signal.SIGTERM)
                except ProcessLookupError:pass
                break
            time.sleep(.10)
        try: code=proc.wait(timeout=4)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL)
            code=proc.wait()
    data={'engine':args.engine,'rows':20000000,'sha':sha,'exitCode':code,'failure':reason,
          'elapsedSeconds':round(time.monotonic()-started,3),
          'sampledCgroupPeakGiB':round(peak/GIB,4),
          'sampledProcessVmHWMMiB':round(max_rss/1048576,2),
          'manifest':str(manifest) if manifest.exists() else None,
          'log':str(log),'diskFreeGiB':round(shutil.disk_usage(ROOT).free/GIB,2)}
    report.write_text(json.dumps(data,indent=2)+'\n')
    print('RESULT',json.dumps(data),flush=True)
    if code or reason:sys.exit(1)

if __name__=='__main__':main()

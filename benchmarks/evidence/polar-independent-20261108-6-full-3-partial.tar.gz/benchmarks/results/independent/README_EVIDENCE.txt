# Independent Polar.DB replication evidence - 2026-11-08
Historical code SHA: abbb03cdc34cff1c11e7550494f65b03dad9afd1
Full series: 6 x 8 = 48 complete coordinator pairs
One incomplete build-external 5m series: 3 complete pairs of 8; other pairs rejected/not measured
Do not claim all eight series completed.
All files are unmodified source and analysis outputs from WSL2 ext4.
SERIES PkIntLookup rows=50000 pairs=8/8
SERIES PkIntLookup rows=5000000 pairs=8/8
SERIES ExternalIntLookup rows=50000 pairs=8/8
SERIES ExternalIntLookup rows=5000000 pairs=8/8
SERIES BuildExternalIndexesOnly rows=50000 pairs=8/8
SERIES BuildExternalIndexesOnly rows=5000000 pairs=3/8
SERIES ReopenOnly rows=50000 pairs=8/8
